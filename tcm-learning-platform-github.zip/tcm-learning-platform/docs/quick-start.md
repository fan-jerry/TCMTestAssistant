# 快速开始指南

本指南将帮助您快速部署和使用中医学习平台。

## ⚡ 一键部署

### 环境要求

- CentOS 7.9+ 服务器
- 2GB+ 内存
- 20GB+ 硬盘空间
- 已安装宝塔面板

### 部署步骤

```bash
# 1. 克隆项目
git clone https://github.com/yourusername/tcm-learning-platform.git
cd tcm-learning-platform

# 2. 安装环境依赖
chmod +x deployment/scripts/*.sh
sudo ./deployment/scripts/install_requirements.sh

# 3. 在宝塔面板中安装软件
# - Nginx 1.20+
# - MySQL 8.0+
# - Python项目管理器 3.9+
# - PM2管理器 4.5+

# 4. 自动部署
sudo ./deployment/scripts/deploy.sh

# 5. 启动服务
sudo ./deployment/scripts/start.sh
```

## 🔧 配置说明

### 数据库配置

部署脚本会自动创建数据库，默认配置：
- 数据库名：`tcm_learning`
- 用户名：`tcm_user`
- 密码：`tcm_123456`（请修改）

### 域名配置

1. 在宝塔面板中添加站点
2. 设置域名和SSL证书
3. 导入Nginx配置：`deployment/nginx/tcm-learning.conf`
4. 修改配置中的域名信息

### 服务管理

```bash
# 查看服务状态
./deployment/scripts/status.sh

# 启动服务
./deployment/scripts/start.sh

# 停止服务
./deployment/scripts/stop.sh

# 重启服务
./deployment/scripts/restart.sh
```

## 🌐 访问系统

部署完成后，您可以访问：

- **前端网站**: https://your-domain.com
- **API接口**: https://your-domain.com/api
- **健康检查**: https://your-domain.com/api/health
- **管理后台**: https://your-domain.com/admin

## 👤 默认账户

系统包含以下默认账户：

**管理员账户：**
- 用户名：`admin`
- 密码：`admin123`
- 权限：系统管理员

**编辑账户：**
- 用户名：`editor`
- 密码：`admin123`
- 权限：内容编辑

> ⚠️ **安全提醒**：首次登录后请立即修改默认密码！

## 📚 功能概览

### 前台功能

- 🌿 **中药材查询** - 搜索中药材信息
- 📚 **方剂学习** - 浏览经典方剂
- 🎯 **穴位定位** - 查看穴位位置和功效
- 📖 **古籍阅读** - 在线阅读中医经典
- ✅ **在线测试** - 参与知识测试
- 👤 **用户中心** - 管理个人信息和学习进度

### 后台功能

- 📝 **内容管理** - 发布和管理文章
- 👥 **用户管理** - 管理用户账户和权限
- 📊 **数据统计** - 查看访问和学习统计
- ⚙️ **系统设置** - 配置系统参数

## 🔍 故障排除

### 常见问题

**1. API服务无法访问**
```bash
# 检查服务状态
./deployment/scripts/status.sh

# 查看日志
pm2 logs tcm-learning-api

# 重启服务
./deployment/scripts/restart.sh
```

**2. 数据库连接失败**
```bash
# 测试数据库连接
mysql -u tcm_user -p tcm_learning

# 检查MySQL服务
systemctl status mysqld
```

**3. 前端页面无法访问**
```bash
# 检查Nginx配置
nginx -t

# 重启Nginx
systemctl restart nginx
```

### 获取帮助

- 📖 查看[完整文档](deployment.md)
- 🐛 [报告问题](https://github.com/yourusername/tcm-learning-platform/issues)
- 💬 [加入讨论](https://github.com/yourusername/tcm-learning-platform/discussions)

## 📞 技术支持

如需技术支持，请联系：
- 邮箱：support@tcm-learning.com
- QQ群：123456789

---

🎉 恭喜！您已成功部署中医学习平台！
