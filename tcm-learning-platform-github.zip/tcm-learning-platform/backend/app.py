#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中医学习平台生产环境API服务器
适用于CentOS 7.9 + 宝塔面板部署
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import pymysql
import redis
import json
import time
import uuid
import os
import logging
from datetime import datetime, timedelta
import hashlib
import jwt
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import re
from functools import wraps

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/www/wwwroot/tcm-learning/logs/api.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 创建Flask应用
app = Flask(__name__)

# 从配置文件加载配置
try:
    from config import Config
    app.config.from_object(Config)
except ImportError:
    # 默认配置
    app.config.update(
        SECRET_KEY='default-secret-key-change-in-production',
        MYSQL_HOST='localhost',
        MYSQL_PORT=3306,
        MYSQL_USER='tcm_user',
        MYSQL_PASSWORD='tcm_123456',
        MYSQL_DATABASE='tcm_learning',
        REDIS_HOST='localhost',
        REDIS_PORT=6379,
        REDIS_PASSWORD=None,
        UPLOAD_FOLDER='/www/wwwroot/tcm-learning/uploads',
        MAX_CONTENT_LENGTH=16 * 1024 * 1024  # 16MB
    )

# 配置CORS
CORS(app, 
     origins=["http://localhost:3000", "http://localhost:5173", "https://*"],
     supports_credentials=True,
     allow_headers=["Content-Type", "Authorization", "X-Requested-With"],
     methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"]
)

# 配置速率限制
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# JWT配置
JWT_SECRET = app.config['SECRET_KEY']
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# 数据库连接
def get_db_connection():
    """获取数据库连接"""
    try:
        connection = pymysql.connect(
            host=app.config['MYSQL_HOST'],
            port=app.config['MYSQL_PORT'],
            user=app.config['MYSQL_USER'],
            password=app.config['MYSQL_PASSWORD'],
            database=app.config['MYSQL_DATABASE'],
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )
        return connection
    except Exception as e:
        logger.error(f"数据库连接失败: {e}")
        return None

# Redis连接
def get_redis_connection():
    """获取Redis连接"""
    try:
        redis_client = redis.Redis(
            host=app.config['REDIS_HOST'],
            port=app.config['REDIS_PORT'],
            password=app.config['REDIS_PASSWORD'],
            decode_responses=True
        )
        redis_client.ping()
        return redis_client
    except Exception as e:
        logger.warning(f"Redis连接失败: {e}")
        return None

# 工具函数
def success_response(data=None, message="操作成功", code=200):
    """成功响应"""
    return jsonify({
        "code": code,
        "message": message,
        "data": data,
        "timestamp": datetime.now().isoformat()
    }), code

def error_response(message="操作失败", code=400, data=None):
    """错误响应"""
    return jsonify({
        "code": code,
        "message": message,
        "data": data,
        "timestamp": datetime.now().isoformat()
    }), code

def generate_token(user_id, username):
    """生成JWT令牌"""
    payload = {
        'user_id': user_id,
        'username': username,
        'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS),
        'iat': datetime.utcnow()
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def verify_token(token):
    """验证JWT令牌"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def require_auth(f):
    """认证装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = request.headers.get('Authorization')
        if token:
            token = token.replace('Bearer ', '')
            payload = verify_token(token)
            if payload:
                request.current_user = payload
                return f(*args, **kwargs)
        return error_response("认证失败", 401)
    return decorated_function

def validate_email(email):
    """验证邮箱格式"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    """验证手机号格式"""
    if not phone:
        return True  # 手机号可选
    pattern = r'^1[3-9]\d{9}$'
    return re.match(pattern, phone) is not None

def validate_username(username):
    """验证用户名格式"""
    if not username or len(username) < 3 or len(username) > 20:
        return False
    pattern = r'^[a-zA-Z0-9_]+$'
    return re.match(pattern, username) is not None

def validate_password(password):
    """验证密码强度"""
    if not password or len(password) < 8:
        return False
    # 至少包含大小写字母和数字
    if not re.search(r'[a-z]', password):
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'\d', password):
        return False
    return True

# API路由

@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查"""
    return success_response({
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat()
    })

@app.route('/api/auth/register', methods=['POST'])
@limiter.limit("5 per minute")
def register():
    """用户注册"""
    try:
        data = request.get_json()
        
        # 验证必填字段
        required_fields = ['username', 'email', 'password', 'confirmPassword', 'nickname']
        for field in required_fields:
            if not data.get(field):
                return error_response(f"{field}不能为空", 400)
        
        username = data['username']
        email = data['email']
        password = data['password']
        confirm_password = data['confirmPassword']
        nickname = data['nickname']
        phone = data.get('phone', '')
        
        # 验证数据格式
        if not validate_username(username):
            return error_response("用户名格式不正确（3-20字符，仅支持字母、数字、下划线）", 400)
        
        if not validate_email(email):
            return error_response("邮箱格式不正确", 400)
        
        if not validate_password(password):
            return error_response("密码强度不够（至少8位，包含大小写字母和数字）", 400)
        
        if password != confirm_password:
            return error_response("两次输入的密码不一致", 400)
        
        if len(nickname) < 2 or len(nickname) > 20:
            return error_response("昵称长度应在2-20字符之间", 400)
        
        if phone and not validate_phone(phone):
            return error_response("手机号格式不正确", 400)
        
        # 检查用户名和邮箱是否已存在
        connection = get_db_connection()
        if not connection:
            return error_response("数据库连接失败", 500)
        
        try:
            with connection.cursor() as cursor:
                # 检查用户名
                cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
                if cursor.fetchone():
                    return error_response("用户名已存在", 400)
                
                # 检查邮箱
                cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
                if cursor.fetchone():
                    return error_response("邮箱已被注册", 400)
                
                # 创建新用户
                password_hash = generate_password_hash(password)
                cursor.execute("""
                    INSERT INTO users (username, email, password_hash, nickname, phone, status, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """, (username, email, password_hash, nickname, phone, 1, datetime.now()))
                
                connection.commit()
                
                return success_response({
                    "message": "注册成功",
                    "username": username,
                    "email": email
                }, "注册成功")
                
        except Exception as e:
            connection.rollback()
            logger.error(f"注册失败: {e}")
            return error_response("注册失败，请重试", 500)
        finally:
            connection.close()
            
    except Exception as e:
        logger.error(f"注册请求处理失败: {e}")
        return error_response("请求处理失败", 500)

@app.route('/api/auth/login', methods=['POST'])
@limiter.limit("10 per minute")
def login():
    """用户登录"""
    try:
        data = request.get_json()
        
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return error_response("用户名和密码不能为空", 400)
        
        connection = get_db_connection()
        if not connection:
            return error_response("数据库连接失败", 500)
        
        try:
            with connection.cursor() as cursor:
                # 查询用户
                cursor.execute("""
                    SELECT id, username, email, nickname, password_hash, status
                    FROM users 
                    WHERE username = %s OR email = %s
                """, (username, username))
                
                user = cursor.fetchone()
                
                if not user or not check_password_hash(user['password_hash'], password):
                    return error_response("用户名或密码错误", 401)
                
                if user['status'] != 1:
                    return error_response("账户已被禁用", 403)
                
                # 生成令牌
                token = generate_token(user['id'], user['username'])
                
                # 更新最后登录时间
                cursor.execute("""
                    UPDATE users SET last_login_at = %s WHERE id = %s
                """, (datetime.now(), user['id']))
                connection.commit()
                
                # 返回用户信息和令牌
                user_info = {
                    'id': user['id'],
                    'username': user['username'],
                    'email': user['email'],
                    'nickname': user['nickname']
                }
                
                return success_response({
                    "user": user_info,
                    "token": token,
                    "refreshToken": token  # 简化处理，实际应使用不同的refresh token
                }, "登录成功")
                
        except Exception as e:
            logger.error(f"登录失败: {e}")
            return error_response("登录失败，请重试", 500)
        finally:
            connection.close()
            
    except Exception as e:
        logger.error(f"登录请求处理失败: {e}")
        return error_response("请求处理失败", 500)

@app.route('/api/auth/logout', methods=['POST'])
@require_auth
def logout():
    """用户登出"""
    return success_response(None, "登出成功")

@app.route('/api/auth/me', methods=['GET'])
@require_auth
def get_current_user():
    """获取当前用户信息"""
    try:
        user_id = request.current_user['user_id']
        
        connection = get_db_connection()
        if not connection:
            return error_response("数据库连接失败", 500)
        
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT id, username, email, nickname, avatar, phone, status, created_at
                    FROM users 
                    WHERE id = %s
                """, (user_id,))
                
                user = cursor.fetchone()
                
                if not user:
                    return error_response("用户不存在", 404)
                
                return success_response(user)
                
        except Exception as e:
            logger.error(f"获取用户信息失败: {e}")
            return error_response("获取用户信息失败", 500)
        finally:
            connection.close()
            
    except Exception as e:
        logger.error(f"获取用户信息请求处理失败: {e}")
        return error_response("请求处理失败", 500)

@app.route('/api/herbs', methods=['GET'])
def get_herbs():
    """获取中药材列表"""
    try:
        page = int(request.args.get('page', 1))
        size = int(request.args.get('size', 10))
        keyword = request.args.get('keyword', '')
        category = request.args.get('category', '')
        
        offset = (page - 1) * size
        
        connection = get_db_connection()
        if not connection:
            return error_response("数据库连接失败", 500)
        
        try:
            with connection.cursor() as cursor:
                # 构建查询条件
                where_conditions = ["1=1"]
                params = []
                
                if keyword:
                    where_conditions.append("(name LIKE %s OR pinyin LIKE %s OR efficacy LIKE %s)")
                    keyword_param = f"%{keyword}%"
                    params.extend([keyword_param, keyword_param, keyword_param])
                
                if category:
                    where_conditions.append("category_id = %s")
                    params.append(category)
                
                where_clause = " AND ".join(where_conditions)
                
                # 查询总数
                count_sql = f"SELECT COUNT(*) as total FROM herbs WHERE {where_clause}"
                cursor.execute(count_sql, params)
                total = cursor.fetchone()['total']
                
                # 查询数据
                data_sql = f"""
                    SELECT id, name, pinyin, english_name, nature, flavor, meridian, 
                           efficacy, indication, usage_dosage, category_id, view_count
                    FROM herbs 
                    WHERE {where_clause}
                    ORDER BY view_count DESC, id ASC
                    LIMIT %s OFFSET %s
                """
                cursor.execute(data_sql, params + [size, offset])
                herbs = cursor.fetchall()
                
                return success_response({
                    "records": herbs,
                    "total": total,
                    "size": size,
                    "current": page,
                    "pages": (total + size - 1) // size
                })
                
        except Exception as e:
            logger.error(f"获取中药材列表失败: {e}")
            return error_response("获取中药材列表失败", 500)
        finally:
            connection.close()
            
    except Exception as e:
        logger.error(f"获取中药材列表请求处理失败: {e}")
        return error_response("请求处理失败", 500)

@app.route('/api/herbs/<int:herb_id>', methods=['GET'])
def get_herb_detail(herb_id):
    """获取中药材详情"""
    try:
        connection = get_db_connection()
        if not connection:
            return error_response("数据库连接失败", 500)
        
        try:
            with connection.cursor() as cursor:
                # 获取中药材详情
                cursor.execute("""
                    SELECT * FROM herbs WHERE id = %s
                """, (herb_id,))
                
                herb = cursor.fetchone()
                
                if not herb:
                    return error_response("中药材不存在", 404)
                
                # 增加浏览次数
                cursor.execute("""
                    UPDATE herbs SET view_count = view_count + 1 WHERE id = %s
                """, (herb_id,))
                connection.commit()
                
                return success_response(herb)
                
        except Exception as e:
            logger.error(f"获取中药材详情失败: {e}")
            return error_response("获取中药材详情失败", 500)
        finally:
            connection.close()
            
    except Exception as e:
        logger.error(f"获取中药材详情请求处理失败: {e}")
        return error_response("请求处理失败", 500)

@app.route('/api/search', methods=['GET'])
def global_search():
    """全局搜索"""
    try:
        keyword = request.args.get('keyword', '')
        
        if not keyword:
            return error_response("搜索关键词不能为空", 400)
        
        connection = get_db_connection()
        if not connection:
            return error_response("数据库连接失败", 500)
        
        try:
            with connection.cursor() as cursor:
                results = {}
                
                # 搜索中药材
                cursor.execute("""
                    SELECT id, name, pinyin, efficacy, 'herb' as type
                    FROM herbs 
                    WHERE name LIKE %s OR pinyin LIKE %s OR efficacy LIKE %s
                    LIMIT 10
                """, (f"%{keyword}%", f"%{keyword}%", f"%{keyword}%"))
                results['herbs'] = cursor.fetchall()
                
                return success_response(results)
                
        except Exception as e:
            logger.error(f"全局搜索失败: {e}")
            return error_response("搜索失败", 500)
        finally:
            connection.close()
            
    except Exception as e:
        logger.error(f"全局搜索请求处理失败: {e}")
        return error_response("请求处理失败", 500)

# 文件上传
@app.route('/api/upload', methods=['POST'])
@require_auth
def upload_file():
    """文件上传"""
    try:
        if 'file' not in request.files:
            return error_response("没有文件被上传", 400)
        
        file = request.files['file']
        
        if file.filename == '':
            return error_response("没有选择文件", 400)
        
        if file:
            # 生成安全的文件名
            filename = secure_filename(file.filename)
            # 添加时间戳防止重名
            timestamp = str(int(time.time()))
            filename = f"{timestamp}_{filename}"
            
            # 确保上传目录存在
            upload_folder = app.config['UPLOAD_FOLDER']
            os.makedirs(upload_folder, exist_ok=True)
            
            # 保存文件
            file_path = os.path.join(upload_folder, filename)
            file.save(file_path)
            
            # 返回文件URL
            file_url = f"/uploads/{filename}"
            
            return success_response({
                "filename": filename,
                "url": file_url,
                "size": os.path.getsize(file_path)
            }, "文件上传成功")
            
    except Exception as e:
        logger.error(f"文件上传失败: {e}")
        return error_response("文件上传失败", 500)

# 静态文件服务
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    """提供上传文件访问"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# 错误处理
@app.errorhandler(404)
def not_found(error):
    return error_response("接口不存在", 404)

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"内部服务器错误: {error}")
    return error_response("内部服务器错误", 500)

@app.errorhandler(429)
def ratelimit_handler(e):
    return error_response("请求过于频繁，请稍后再试", 429)

# 请求日志中间件
@app.before_request
def log_request_info():
    """记录请求信息"""
    logger.info(f"{request.method} {request.url} - {request.remote_addr}")

@app.after_request
def log_response_info(response):
    """记录响应信息"""
    logger.info(f"Response: {response.status_code}")
    return response

# 主函数
if __name__ == '__main__':
    # 确保日志目录存在
    log_dir = '/www/wwwroot/tcm-learning/logs'
    os.makedirs(log_dir, exist_ok=True)
    
    # 确保上传目录存在
    upload_dir = app.config.get('UPLOAD_FOLDER', '/www/wwwroot/tcm-learning/uploads')
    os.makedirs(upload_dir, exist_ok=True)
    
    # 生产环境运行
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '127.0.0.1')
    
    logger.info(f"中医学习平台API服务器启动 - {host}:{port}")
    
    app.run(
        host=host,
        port=port,
        debug=False,
        threaded=True
    )
