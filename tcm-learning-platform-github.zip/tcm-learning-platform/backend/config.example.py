#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中医学习平台生产环境配置文件示例
复制此文件为 config.py 并修改相应配置
"""

import os

class Config:
    """基础配置"""
    
    # 应用基础配置
    SECRET_KEY = 'your-secret-key-here'  # 请修改为复杂的随机字符串
    DEBUG = False
    TESTING = False
    
    # 数据库配置
    MYSQL_HOST = 'localhost'
    MYSQL_PORT = 3306
    MYSQL_USER = 'tcm_user'
    MYSQL_PASSWORD = 'your_db_password'  # 请修改为实际密码
    MYSQL_DATABASE = 'tcm_learning'
    MYSQL_CHARSET = 'utf8mb4'
    
    # Redis配置（可选，用于缓存）
    REDIS_HOST = 'localhost'
    REDIS_PORT = 6379
    REDIS_PASSWORD = None  # 如果Redis设置了密码，请填写
    REDIS_DB = 0
    
    # 文件上传配置
    UPLOAD_FOLDER = '/www/wwwroot/tcm-learning/uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx'}
    
    # JWT令牌配置
    JWT_SECRET_KEY = 'your-jwt-secret-key'  # 请修改为复杂的随机字符串
    JWT_ACCESS_TOKEN_EXPIRES = 24 * 60 * 60  # 24小时（秒）
    JWT_REFRESH_TOKEN_EXPIRES = 30 * 24 * 60 * 60  # 30天（秒）
    
    # 邮件配置（用于发送验证码等）
    MAIL_SERVER = 'smtp.example.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'your-email@example.com'
    MAIL_PASSWORD = 'your-email-password'
    MAIL_DEFAULT_SENDER = 'your-email@example.com'
    
    # 支付配置（如需要）
    ALIPAY_APP_ID = ''
    ALIPAY_PRIVATE_KEY = ''
    ALIPAY_PUBLIC_KEY = ''
    ALIPAY_SANDBOX = True  # 生产环境请设置为False
    
    WECHAT_PAY_APP_ID = ''
    WECHAT_PAY_MCH_ID = ''
    WECHAT_PAY_API_KEY = ''
    
    # 第三方服务配置
    QINIU_ACCESS_KEY = ''  # 七牛云存储
    QINIU_SECRET_KEY = ''
    QINIU_BUCKET_NAME = ''
    QINIU_DOMAIN = ''
    
    # 短信服务配置（如阿里云短信）
    ALIYUN_ACCESS_KEY_ID = ''
    ALIYUN_ACCESS_KEY_SECRET = ''
    ALIYUN_SMS_SIGN_NAME = ''
    ALIYUN_SMS_TEMPLATE_CODE = ''
    
    # 安全配置
    SECURITY_PASSWORD_SALT = 'your-password-salt'  # 请修改
    WTF_CSRF_SECRET_KEY = 'your-csrf-secret'  # 请修改
    
    # 日志配置
    LOG_LEVEL = 'INFO'
    LOG_FILE_PATH = '/www/wwwroot/tcm-learning/logs/app.log'
    LOG_MAX_BYTES = 10 * 1024 * 1024  # 10MB
    LOG_BACKUP_COUNT = 5
    
    # 缓存配置
    CACHE_TYPE = 'redis'  # 可选: simple, redis, memcached
    CACHE_DEFAULT_TIMEOUT = 300  # 5分钟
    
    # API限流配置
    RATELIMIT_STORAGE_URL = 'redis://localhost:6379/1'
    
    # 跨域配置
    CORS_ORIGINS = [
        'http://localhost:3000',
        'http://localhost:5173',
        'https://your-domain.com',
        'https://www.your-domain.com'
    ]
    
    # 静态文件配置
    STATIC_FOLDER = '/www/wwwroot/tcm-learning/frontend'
    STATIC_URL_PATH = '/'
    
    # 多语言配置
    LANGUAGES = {
        'zh': 'Chinese',
        'en': 'English'
    }
    DEFAULT_LANGUAGE = 'zh'
    
    # 业务配置
    DEFAULT_USER_AVATAR = '/static/images/default_avatar.png'
    USER_REGISTRATION_ENABLED = True  # 是否允许用户注册
    EMAIL_VERIFICATION_REQUIRED = False  # 是否需要邮箱验证
    
    # 会员配置
    VIP_MONTHLY_PRICE = 29.9   # 月度会员价格
    VIP_YEARLY_PRICE = 299.0   # 年度会员价格
    VIP_TRIAL_DAYS = 7         # 试用天数
    
    # 内容配置
    ARTICLES_PER_PAGE = 20     # 每页文章数
    COMMENTS_PER_PAGE = 10     # 每页评论数
    MAX_COMMENT_LENGTH = 500   # 评论最大长度
    
    # 搜索配置
    SEARCH_RESULTS_PER_PAGE = 10
    SEARCH_HIGHLIGHT_ENABLED = True
    
    # 推荐算法配置
    RECOMMENDATION_BATCH_SIZE = 10
    RECOMMENDATION_REFRESH_HOURS = 24
    
    # 统计配置
    ANALYTICS_ENABLED = True
    ANALYTICS_RETENTION_DAYS = 90
    
    # 备份配置
    BACKUP_ENABLED = True
    BACKUP_RETENTION_DAYS = 30
    BACKUP_PATH = '/www/backup/tcm-learning'
    
    @staticmethod
    def init_app(app):
        """初始化应用配置"""
        pass

class DevelopmentConfig(Config):
    """开发环境配置"""
    DEBUG = True
    TESTING = True
    
    # 开发环境数据库
    MYSQL_HOST = 'localhost'
    MYSQL_DATABASE = 'tcm_learning_dev'
    
    # 开发环境日志
    LOG_LEVEL = 'DEBUG'
    
class ProductionConfig(Config):
    """生产环境配置"""
    DEBUG = False
    TESTING = False
    
    # 生产环境数据库
    MYSQL_HOST = 'localhost'
    MYSQL_DATABASE = 'tcm_learning'
    
    # 生产环境日志
    LOG_LEVEL = 'INFO'
    
    # 生产环境安全配置
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    @classmethod
    def init_app(cls, app):
        Config.init_app(app)
        
        # 生产环境特定初始化
        import logging
        from logging.handlers import RotatingFileHandler
        
        if not app.debug:
            # 设置日志处理器
            file_handler = RotatingFileHandler(
                cls.LOG_FILE_PATH,
                maxBytes=cls.LOG_MAX_BYTES,
                backupCount=cls.LOG_BACKUP_COUNT
            )
            file_handler.setFormatter(logging.Formatter(
                '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
            ))
            file_handler.setLevel(logging.INFO)
            app.logger.addHandler(file_handler)
            
            app.logger.setLevel(logging.INFO)
            app.logger.info('TCM Learning Platform startup')

class TestingConfig(Config):
    """测试环境配置"""
    TESTING = True
    DEBUG = True
    
    # 测试数据库
    MYSQL_DATABASE = 'tcm_learning_test'
    
    # 测试环境禁用CSRF
    WTF_CSRF_ENABLED = False

# 配置字典
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': ProductionConfig
}

# 根据环境变量选择配置
def get_config():
    """获取当前环境配置"""
    env = os.environ.get('FLASK_ENV', 'production')
    return config.get(env, config['default'])