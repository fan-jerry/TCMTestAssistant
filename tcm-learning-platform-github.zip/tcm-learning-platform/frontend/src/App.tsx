import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { HelmetProvider } from 'react-helmet-async';
import { AuthProvider } from '@/contexts/AuthContext';
import Layout from '@/components/layout/Layout';
import AdminLayout from '@/components/admin/AdminLayout';
import Home from '@/pages/Home';
import Herbs from '@/pages/Herbs';
import HerbDetail from '@/pages/HerbDetail';
import SearchResults from '@/pages/SearchResults';
import Login from '@/pages/Login';
import '@/i18n';
import './App.css';

// 创建 QueryClient 实例
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: (failureCount, error: any) => {
        if (error?.response?.status === 401) {
          return false;
        }
        return failureCount < 3;
      },
    },
  },
});

// 懒加载其他页面组件
const Register = React.lazy(() => import('@/pages/Register'));
const Formulas = React.lazy(() => import('@/pages/Formulas'));
const FormulaDetail = React.lazy(() => import('@/pages/FormulaDetail'));
const Acupoints = React.lazy(() => import('@/pages/Acupoints'));
const AcupointDetail = React.lazy(() => import('@/pages/AcupointDetail'));
const Resources = React.lazy(() => import('@/pages/Resources'));
const Quiz = React.lazy(() => import('@/pages/Quiz'));
const QuizTest = React.lazy(() => import('@/pages/QuizTest'));
const Profile = React.lazy(() => import('@/pages/Profile'));
const Search = React.lazy(() => import('@/pages/Search'));
const Theory = React.lazy(() => import('@/pages/Theory'));
const TheoryDetail = React.lazy(() => import('@/pages/TheoryDetail'));
const TheoryReader = React.lazy(() => import('@/pages/TheoryReader'));

// 管理页面
const AdminDashboard = React.lazy(() => import('@/pages/admin/AdminDashboard'));
const UserManagement = React.lazy(() => import('@/pages/admin/UserManagement'));
const ArticleManagement = React.lazy(() => import('@/pages/admin/ArticleManagement'));
const DataManagement = React.lazy(() => import('@/pages/admin/DataManagement'));

function App() {
  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <Router>
          <div className="App">
            <Routes>
              {/* 不需要布局的页面 */}
              <Route path="/login" element={<Login />} />
              
              {/* 需要布局的页面 */}
              <Route path="/" element={<Layout />}>
                <Route index element={<Home />} />
                <Route path="herbs" element={<Herbs />} />
                <Route
                  path="register"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <Register />
                    </React.Suspense>
                  }
                />
                <Route
                  path="formulas"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <Formulas />
                    </React.Suspense>
                  }
                />
                <Route
                  path="acupoints"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <Acupoints />
                    </React.Suspense>
                  }
                />
                <Route
                  path="resources"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <Resources />
                    </React.Suspense>
                  }
                />
                <Route
                  path="quiz"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <Quiz />
                    </React.Suspense>
                  }
                />
                <Route
                  path="profile"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <Profile />
                    </React.Suspense>
                  }
                />
                <Route path="search" element={<SearchResults />} />
                <Route
                  path="theory"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <Theory />
                    </React.Suspense>
                  }
                />
                
                {/* 详情页面 */}
                <Route path="herbs/:id" element={<HerbDetail />} />
                <Route
                  path="formulas/:id"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <FormulaDetail />
                    </React.Suspense>
                  }
                />
                <Route
                  path="acupoints/:id"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <AcupointDetail />
                    </React.Suspense>
                  }
                />
                <Route
                  path="theory/:id"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <TheoryDetail />
                    </React.Suspense>
                  }
                />
                <Route
                  path="theory/:id/read"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <TheoryReader />
                    </React.Suspense>
                  }
                />
                <Route
                  path="quiz/test/:id"
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <QuizTest />
                    </React.Suspense>
                  }
                />
                <Route path="articles/:id" element={<div>文章详情页</div>} />
                
                {/* 其他页面 */}
                <Route path="about" element={<div>关于我们</div>} />
                <Route path="contact" element={<div>联系我们</div>} />
                <Route path="privacy" element={<div>隐私政策</div>} />
                <Route path="terms" element={<div>服务条款</div>} />
                
                {/* 404 页面 */}
                <Route path="*" element={<div className="text-center py-20"><h1 className="text-4xl font-bold mb-4">404</h1><p>页面未找到</p></div>} />
              </Route>
              
              {/* 管理系统路由 */}
              <Route path="/admin" element={<AdminLayout />}>
                <Route 
                  index 
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <AdminDashboard />
                    </React.Suspense>
                  } 
                />
                <Route 
                  path="users" 
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <UserManagement />
                    </React.Suspense>
                  } 
                />
                <Route 
                  path="articles" 
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <ArticleManagement />
                    </React.Suspense>
                  } 
                />
                <Route 
                  path="data" 
                  element={
                    <React.Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div></div>}>
                      <DataManagement />
                    </React.Suspense>
                  } 
                />
              </Route>
            </Routes>
          </div>
          </Router>
        </AuthProvider>
      </QueryClientProvider>
    </HelmetProvider>
  );
}

export default App;
