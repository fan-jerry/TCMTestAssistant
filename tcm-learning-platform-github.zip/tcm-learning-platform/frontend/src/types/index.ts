// 用户相关类型
export interface User {
  id: number;
  username: string;
  email: string;
  nickname: string;
  phone?: string;
  avatar?: string;
  membership?: Membership;
  roles: Role[];
  createdAt: string;
  updatedAt: string;
}

export interface Membership {
  id: number;
  type: 'FREE' | 'PREMIUM' | 'VIP';
  name: string;
  startDate: string;
  endDate: string;
  status: 'ACTIVE' | 'EXPIRED' | 'SUSPENDED';
}

export interface Role {
  id: number;
  name: string;
  description: string;
  permissions: Permission[];
}

export interface Permission {
  id: number;
  name: string;
  resource: string;
  action: string;
}

// 中药材相关类型
export interface Herb {
  id: number;
  name: string;
  pinyin: string;
  englishName?: string;
  category: string;
  nature: string;
  taste: string;
  meridian: string;
  functions: string;
  indications: string;
  usage: string;
  precautions?: string;
  image?: string;
  isPremium: boolean;
  createdAt: string;
  updatedAt: string;
}

// 方剂相关类型
export interface Formula {
  id: number;
  name: string;
  pinyin: string;
  englishName?: string;
  category: string;
  source: string;
  composition: FormulaHerb[];
  functions: string;
  indications: string;
  preparation: string;
  dosage: string;
  precautions?: string;
  clinicalApplications?: string;
  isPremium: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FormulaHerb {
  herb: Herb;
  dosage: string;
  unit: string;
}

// 穴位相关类型
export interface Acupoint {
  id: number;
  name: string;
  pinyin: string;
  englishName?: string;
  meridian: string;
  location: string;
  functions: string;
  indications: string;
  needleMethod?: string;
  precautions?: string;
  image?: string;
  isPremium: boolean;
  createdAt: string;
  updatedAt: string;
}

// 文章相关类型
export interface Article {
  id: number;
  title: string;
  content: string;
  summary: string;
  category: string;
  tags: string[];
  author: string;
  thumbnail?: string;
  isPremium: boolean;
  viewCount: number;
  likeCount: number;
  isPublished: boolean;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// 学习资源相关类型
export interface LearningResource {
  id: number;
  title: string;
  description: string;
  type: 'VIDEO' | 'AUDIO' | 'DOCUMENT' | 'INTERACTIVE';
  url: string;
  thumbnail?: string;
  duration?: number;
  size?: number;
  category: string;
  tags: string[];
  isPremium: boolean;
  viewCount: number;
  downloadCount: number;
  createdAt: string;
  updatedAt: string;
}

// 测试相关类型
export interface Quiz {
  id: number;
  title: string;
  description: string;
  category: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
  timeLimit?: number;
  questions: Question[];
  isPremium: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Question {
  id: number;
  content: string;
  type: 'SINGLE_CHOICE' | 'MULTIPLE_CHOICE' | 'TRUE_FALSE' | 'FILL_BLANK';
  options?: QuestionOption[];
  correctAnswer: string;
  explanation?: string;
  points: number;
}

export interface QuestionOption {
  id: string;
  content: string;
}

export interface QuizResult {
  id: number;
  quiz: Quiz;
  user: User;
  score: number;
  totalScore: number;
  answers: QuizAnswer[];
  startTime: string;
  endTime: string;
  duration: number;
  createdAt: string;
}

export interface QuizAnswer {
  questionId: number;
  answer: string;
  isCorrect: boolean;
  points: number;
}

// API响应类型
export interface ApiResponse<T> {
  code: number;
  message: string;
  data: T;
  timestamp: string;
  traceId: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  pagination: {
    currentPage: number;
    perPage: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

// 认证相关类型
export interface LoginRequest {
  username: string;
  password: string;
  captcha: string;
  remember?: boolean;
}

export interface LoginResponse {
  user: User;
  token: string;
  refreshToken: string;
  expiresIn: number;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  phone?: string;
  nickname: string;
}

// 搜索相关类型
export interface SearchRequest {
  keyword: string;
  type?: 'ALL' | 'HERB' | 'FORMULA' | 'ACUPOINT' | 'ARTICLE';
  category?: string;
  page?: number;
  perPage?: number;
}

export interface SearchResult {
  type: 'HERB' | 'FORMULA' | 'ACUPOINT' | 'ARTICLE';
  id: number;
  title: string;
  content: string;
  image?: string;
  url: string;
}

// 学习进度相关类型
export interface LearningProgress {
  id: number;
  user: User;
  resourceType: 'HERB' | 'FORMULA' | 'ACUPOINT' | 'ARTICLE' | 'VIDEO';
  resourceId: number;
  progress: number; // 0-100
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED';
  lastAccessTime: string;
  createdAt: string;
  updatedAt: string;
}

// 收藏相关类型
export interface Favorite {
  id: number;
  user: User;
  resourceType: 'HERB' | 'FORMULA' | 'ACUPOINT' | 'ARTICLE';
  resourceId: number;
  resourceTitle: string;
  createdAt: string;
}

// 学习笔记相关类型
export interface StudyNote {
  id: number;
  user: User;
  resourceType: 'HERB' | 'FORMULA' | 'ACUPOINT' | 'ARTICLE' | 'THEORY';
  resourceId: number;
  title: string;
  content: string;
  tags: string[];
  isPrivate: boolean;
  createdAt: string;
  updatedAt: string;
}

// 中医理论相关类型
export interface Theory {
  id: number;
  title: string;
  subtitle?: string;
  author: string;
  dynasty?: string;
  cover?: string;
  summary: string;
  content: string;
  chapters: TheoryChapter[];
  category: string;
  tags: string[];
  difficulty: 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED';
  readingTime: number;
  viewCount: number;
  likeCount: number;
  isPremium: boolean;
  isPublished: boolean;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TheoryChapter {
  id: number;
  title: string;
  order: number;
  content: string;
  annotations?: TheoryAnnotation[];
}

export interface TheoryAnnotation {
  id: number;
  text: string;
  explanation: string;
  position: {
    start: number;
    end: number;
  };
}

// 阅读记录类型
export interface ReadingProgress {
  id: number;
  user: User;
  theory: Theory;
  currentChapter: number;
  readingPercentage: number;
  lastReadPosition: number;
  notes: StudyNote[];
  bookmarks: ReadingBookmark[];
  lastAccessTime: string;
  createdAt: string;
  updatedAt: string;
}

export interface ReadingBookmark {
  id: number;
  chapterId: number;
  position: number;
  note?: string;
  createdAt: string;
}

// 评论系统类型
export interface Comment {
  id: number;
  user: User;
  resourceType: 'THEORY' | 'ARTICLE' | 'HERB' | 'FORMULA' | 'ACUPOINT';
  resourceId: number;
  content: string;
  parentId?: number;
  replies?: Comment[];
  likeCount: number;
  isLiked: boolean;
  createdAt: string;
  updatedAt: string;
}

// 扩展现有类型
export interface QuizCategory {
  id: number;
  name: string;
  description: string;
  parentId?: number;
  children?: QuizCategory[];
  order: number;
  questionCount: number;
}

export interface QuizSetting {
  categoryIds: number[];
  questionCount: number;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'MIXED';
  timeLimit?: number;
  showAnswer: boolean;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
}
