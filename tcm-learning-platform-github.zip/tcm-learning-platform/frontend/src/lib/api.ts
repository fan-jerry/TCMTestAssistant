import axios, { AxiosInstance, AxiosResponse, AxiosError } from 'axios';
import { ApiResponse } from '@/types';

class ApiClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8888/api',
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    // 请求拦截器
    this.client.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('token');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // 响应拦截器
    this.client.interceptors.response.use(
      (response: AxiosResponse<ApiResponse<any>>) => {
        return response;
      },
      (error: AxiosError<ApiResponse<any>>) => {
        if (error.response?.status === 401) {
          // Token过期，清除本地存储的认证信息
          localStorage.removeItem('token');
          localStorage.removeItem('refreshToken');
          localStorage.removeItem('user');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  // 通用请求方法
  async request<T>(
    method: 'GET' | 'POST' | 'PUT' | 'DELETE',
    url: string,
    data?: any,
    config?: any
  ): Promise<T> {
    try {
      const response = await this.client.request<ApiResponse<T>>({
        method,
        url,
        data,
        ...config,
      });
      return response.data.data;
    } catch (error) {
      throw this.handleError(error as AxiosError<ApiResponse<any>>);
    }
  }

  private handleError(error: AxiosError<ApiResponse<any>>): Error {
    if (error.response?.data?.message) {
      return new Error(error.response.data.message);
    }
    if (error.message) {
      return new Error(error.message);
    }
    return new Error('网络请求失败');
  }

  // GET请求
  get<T>(url: string, config?: any): Promise<T> {
    return this.request<T>('GET', url, undefined, config);
  }

  // POST请求
  post<T>(url: string, data?: any, config?: any): Promise<T> {
    return this.request<T>('POST', url, data, config);
  }

  // PUT请求
  put<T>(url: string, data?: any, config?: any): Promise<T> {
    return this.request<T>('PUT', url, data, config);
  }

  // DELETE请求
  delete<T>(url: string, config?: any): Promise<T> {
    return this.request<T>('DELETE', url, undefined, config);
  }

  // 分页请求
  async paginated<T>(
    url: string,
    params?: any
  ): Promise<{ items: T[]; pagination: any }> {
    const response = await this.client.get<ApiResponse<{ records: T[]; total: number; size: number; current: number; pages: number }>>(
      url,
      { params }
    );
    const data = response.data.data;
    return {
      items: data.records,
      pagination: {
        total: data.total,
        pageSize: data.size,
        current: data.current,
        pages: data.pages
      }
    };
  }

  // 上传文件
  async upload<T>(url: string, file: File, onProgress?: (progress: number) => void): Promise<T> {
    const formData = new FormData();
    formData.append('file', file);

    const response = await this.client.post<ApiResponse<T>>(url, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (progressEvent) => {
        if (onProgress && progressEvent.total) {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          onProgress(progress);
        }
      },
    });

    return response.data.data;
  }
}

// 创建API客户端实例
export const apiClient = new ApiClient();

// 认证相关API
export const authApi = {
  login: (data: any) => apiClient.post('/auth/login', data),
  register: (data: any) => apiClient.post('/auth/register', data),
  logout: () => apiClient.post('/auth/logout'),
  me: () => apiClient.get('/auth/me'),
  refreshToken: () => apiClient.post('/auth/refresh'),
  forgotPassword: (email: string) => apiClient.post('/auth/forgot-password', { email }),
  resetPassword: (data: any) => apiClient.post('/auth/reset-password', data),
  verifyEmail: (token: string) => apiClient.post('/auth/verify-email', { token }),
};

// 用户相关API
export const userApi = {
  getProfile: () => apiClient.get('/user/profile'),
  updateProfile: (data: any) => apiClient.put('/user/profile', data),
  changePassword: (data: any) => apiClient.put('/user/change-password', data),
  uploadAvatar: (file: File) => apiClient.upload('/user/avatar', file),
};

// 中药材相关API
export const herbApi = {
  list: (params?: any) => apiClient.paginated('/herbs', params),
  get: (id: number) => apiClient.get(`/herbs/${id}`),
  search: (keyword: string, params?: any) => apiClient.get('/herbs/search', { params: { keyword, ...params } }),
  categories: () => apiClient.get('/herbs/categories'),
};

// 方剂相关API
export const formulaApi = {
  list: (params?: any) => apiClient.paginated('/formulas', params),
  get: (id: number) => apiClient.get(`/formulas/${id}`),
  search: (keyword: string, params?: any) => apiClient.get('/formulas/search', { params: { keyword, ...params } }),
  categories: () => apiClient.get('/formulas/categories'),
};

// 穴位相关API
export const acupointApi = {
  list: (params?: any) => apiClient.paginated('/acupoints', params),
  get: (id: number) => apiClient.get(`/acupoints/${id}`),
  search: (keyword: string, params?: any) => apiClient.get('/acupoints/search', { params: { keyword, ...params } }),
  meridians: () => apiClient.get('/acupoints/meridians'),
};

// 文章相关API
export const articleApi = {
  list: (params?: any) => apiClient.paginated('/articles', params),
  get: (id: number) => apiClient.get(`/articles/${id}`),
  search: (keyword: string, params?: any) => apiClient.get('/articles/search', { params: { keyword, ...params } }),
  categories: () => apiClient.get('/articles/categories'),
  like: (id: number) => apiClient.post(`/articles/${id}/like`),
  unlike: (id: number) => apiClient.delete(`/articles/${id}/like`),
};

// 学习资源相关API
export const resourceApi = {
  list: (params?: any) => apiClient.paginated('/resources', params),
  get: (id: number) => apiClient.get(`/resources/${id}`),
  search: (keyword: string, params?: any) => apiClient.get('/resources/search', { params: { keyword, ...params } }),
  categories: () => apiClient.get('/resources/categories'),
  download: (id: number) => apiClient.post(`/resources/${id}/download`),
};

// 测试相关API
export const quizApi = {
  list: (params?: any) => apiClient.paginated('/quizzes', params),
  get: (id: number) => apiClient.get(`/quizzes/${id}`),
  submit: (id: number, answers: any[]) => apiClient.post(`/quizzes/${id}/submit`, { answers }),
  results: (params?: any) => apiClient.paginated('/quiz-results', params),
  getResult: (id: number) => apiClient.get(`/quiz-results/${id}`),
};

// 收藏相关API
export const favoriteApi = {
  list: (params?: any) => apiClient.paginated('/favorites', params),
  add: (resourceType: string, resourceId: number) => 
    apiClient.post('/favorites', { resourceType, resourceId }),
  remove: (id: number) => apiClient.delete(`/favorites/${id}`),
  check: (resourceType: string, resourceId: number) => 
    apiClient.get('/favorites/check', { params: { resourceType, resourceId } }),
};

// 学习进度相关API
export const progressApi = {
  list: (params?: any) => apiClient.paginated('/learning-progress', params),
  update: (resourceType: string, resourceId: number, progress: number) =>
    apiClient.put('/learning-progress', { resourceType, resourceId, progress }),
  stats: () => apiClient.get('/learning-progress/stats'),
};

// 学习笔记相关API
export const noteApi = {
  list: (params?: any) => apiClient.paginated('/study-notes', params),
  get: (id: number) => apiClient.get(`/study-notes/${id}`),
  create: (data: any) => apiClient.post('/study-notes', data),
  update: (id: number, data: any) => apiClient.put(`/study-notes/${id}`, data),
  delete: (id: number) => apiClient.delete(`/study-notes/${id}`),
};

// 中医理论相关API
export const theoryApi = {
  list: (params?: any) => apiClient.paginated('/theories', params),
  get: (id: number) => apiClient.get(`/theories/${id}`),
  getChapter: (theoryId: number, chapterId: number) => 
    apiClient.get(`/theories/${theoryId}/chapters/${chapterId}`),
  search: (keyword: string, params?: any) => 
    apiClient.get('/theories/search', { params: { keyword, ...params } }),
  categories: () => apiClient.get('/theories/categories'),
  like: (id: number) => apiClient.post(`/theories/${id}/like`),
  unlike: (id: number) => apiClient.delete(`/theories/${id}/like`),
};

// 阅读进度相关API
export const readingProgressApi = {
  get: (theoryId: number) => apiClient.get(`/reading-progress/${theoryId}`),
  update: (theoryId: number, data: any) => 
    apiClient.put(`/reading-progress/${theoryId}`, data),
  addBookmark: (theoryId: number, data: any) => 
    apiClient.post(`/reading-progress/${theoryId}/bookmarks`, data),
  removeBookmark: (theoryId: number, bookmarkId: number) => 
    apiClient.delete(`/reading-progress/${theoryId}/bookmarks/${bookmarkId}`),
};

// 评论相关API
export const commentApi = {
  list: (resourceType: string, resourceId: number, params?: any) => 
    apiClient.paginated('/comments', { ...params, resourceType, resourceId }),
  create: (data: any) => apiClient.post('/comments', data),
  update: (id: number, data: any) => apiClient.put(`/comments/${id}`, data),
  delete: (id: number) => apiClient.delete(`/comments/${id}`),
  like: (id: number) => apiClient.post(`/comments/${id}/like`),
  unlike: (id: number) => apiClient.delete(`/comments/${id}/like`),
};

// 增强测试相关API
export const enhancedQuizApi = {
  ...quizApi,
  categories: () => apiClient.get('/quiz-categories'),
  generateQuiz: (settings: any) => apiClient.post('/quizzes/generate', settings),
  getQuizBySettings: (settings: any) => apiClient.post('/quizzes/by-settings', settings),
};

// 搜索相关API
export const searchApi = {
  global: (keyword: string, params?: any) => 
    apiClient.get('/search', { params: { keyword, ...params } }),
  suggestions: (keyword: string) => 
    apiClient.get('/search/suggestions', { params: { keyword } }),
  hot: () => apiClient.get('/search/hot-keywords'),
};

export default apiClient;
