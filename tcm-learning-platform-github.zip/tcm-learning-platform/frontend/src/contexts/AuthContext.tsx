import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, LoginRequest, LoginResponse, RegisterRequest } from '@/types';
import { authApi } from '@/lib/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (data: LoginRequest) => Promise<void>;
  register: (data: RegisterRequest) => Promise<void>;
  logout: () => void;
  refreshToken: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // 初始化时检查本地存储的认证信息
    const storedToken = localStorage.getItem('token');
    const storedUser = localStorage.getItem('user');

    if (storedToken && storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setToken(storedToken);
        setUser(parsedUser);
      } catch (error) {
        console.error('解析用户信息失败:', error);
        // 清除无效的本地存储
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        localStorage.removeItem('refreshToken');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (data: LoginRequest): Promise<void> => {
    try {
      setIsLoading(true);
      const response = await authApi.login(data) as LoginResponse;
      
      const { user: userData, token: userToken, refreshToken } = response;
      
      // 保存到状态
      setUser(userData);
      setToken(userToken);
      
      // 保存到本地存储
      localStorage.setItem('token', userToken);
      localStorage.setItem('user', JSON.stringify(userData));
      localStorage.setItem('refreshToken', refreshToken);
    } catch (error) {
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: RegisterRequest): Promise<void> => {
    try {
      setIsLoading(true);
      await authApi.register(data);
      // 注册成功后，不自动登录，让用户手动登录
    } catch (error) {
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    // 调用后端登出接口
    authApi.logout().catch(console.error);
    
    // 清除状态
    setUser(null);
    setToken(null);
    
    // 清除本地存储
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('refreshToken');
  };

  const refreshToken = async (): Promise<void> => {
    try {
      const response = await authApi.refreshToken() as LoginResponse;
      const { user: userData, token: userToken, refreshToken: newRefreshToken } = response;
      
      // 更新状态
      setUser(userData);
      setToken(userToken);
      
      // 更新本地存储
      localStorage.setItem('token', userToken);
      localStorage.setItem('user', JSON.stringify(userData));
      localStorage.setItem('refreshToken', newRefreshToken);
    } catch (error) {
      // 刷新token失败，执行登出
      logout();
      throw error;
    }
  };

  const value: AuthContextType = {
    user,
    token,
    isAuthenticated: !!user && !!token,
    isLoading,
    login,
    register,
    logout,
    refreshToken,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// 高阶组件：要求认证
export const withAuth = <P extends object>(
  Component: React.ComponentType<P>
): React.FC<P> => {
  return (props: P) => {
    const { isAuthenticated, isLoading } = useAuth();

    if (isLoading) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      );
    }

    if (!isAuthenticated) {
      // 重定向到登录页面
      window.location.href = '/login';
      return null;
    }

    return <Component {...props} />;
  };
};

// Hook: 检查用户权限
export const usePermission = (permission: string): boolean => {
  const { user } = useAuth();
  
  if (!user) return false;
  
  // 检查用户是否有指定权限
  return user.roles.some(role =>
    role.permissions.some(p => p.name === permission)
  );
};

// Hook: 检查会员状态
export const useMembership = () => {
  const { user } = useAuth();
  
  const membership = user?.membership;
  const isFree = !membership || membership.type === 'FREE';
  const isPremium = membership?.type === 'PREMIUM';
  const isVip = membership?.type === 'VIP';
  const isActive = membership?.status === 'ACTIVE';
  
  return {
    membership,
    isFree,
    isPremium,
    isVip,
    isActive,
    hasAccess: (requiredLevel: 'FREE' | 'PREMIUM' | 'VIP') => {
      if (!isActive) return requiredLevel === 'FREE';
      
      const levels = { FREE: 0, PREMIUM: 1, VIP: 2 };
      const userLevel = levels[membership?.type || 'FREE'];
      const required = levels[requiredLevel];
      
      return userLevel >= required;
    }
  };
};
