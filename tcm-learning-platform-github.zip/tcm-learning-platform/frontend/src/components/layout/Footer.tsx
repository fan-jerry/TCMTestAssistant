import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  BookOpen,
  Mail,
  Phone,
  MapPin,
  Github,
  Twitter,
  Facebook,
  Linkedin,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

const Footer: React.FC = () => {
  const { t } = useTranslation();

  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { key: 'home', path: '/', label: t('nav.home') },
    { key: 'herbs', path: '/herbs', label: t('nav.herbs') },
    { key: 'formulas', path: '/formulas', label: t('nav.formulas') },
    { key: 'acupoints', path: '/acupoints', label: t('nav.acupoints') },
    { key: 'resources', path: '/resources', label: t('nav.resources') },
    { key: 'quiz', path: '/quiz', label: t('nav.quiz') },
  ];

  const legalLinks = [
    { key: 'privacy', path: '/privacy', label: t('footer.privacyPolicy') },
    { key: 'terms', path: '/terms', label: t('footer.termsOfService') },
    { key: 'sitemap', path: '/sitemap', label: t('footer.sitemap') },
    { key: 'about', path: '/about', label: t('nav.about') },
  ];

  const socialLinks = [
    { icon: Github, href: '#', label: 'GitHub' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
  ];

  return (
    <footer className="bg-background border-t">
      <div className="container mx-auto px-4 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand and Description */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
                <BookOpen className="h-4 w-4" />
              </div>
              <span className="text-xl font-bold text-primary">中医学习平台</span>
            </div>
            <p className="text-muted-foreground mb-6 max-w-md">
              {t('footer.description')}
            </p>
            
            {/* Contact Information */}
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span>contact@tcm-learning.com</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span>+86 400-123-4567</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span>北京市朝阳区中医药大学</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-2 mt-6">
              <span className="text-sm text-muted-foreground mr-2">{t('footer.followUs')}:</span>
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <Button
                    key={index}
                    variant="ghost"
                    size="sm"
                    asChild
                    className="h-8 w-8 p-0"
                  >
                    <a
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={social.label}
                    >
                      <Icon className="h-4 w-4" />
                    </a>
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">{t('footer.quickLinks')}</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.key}>
                  <Link
                    to={link.path}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Information */}
          <div>
            <h3 className="font-semibold mb-4">{t('footer.legalInfo')}</h3>
            <ul className="space-y-2">
              {legalLinks.map((link) => (
                <li key={link.key}>
                  <Link
                    to={link.path}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Newsletter Signup */}
            <div className="mt-6">
              <h4 className="font-medium mb-2">订阅最新资讯</h4>
              <div className="flex">
                <input
                  type="email"
                  placeholder="输入邮箱地址"
                  className="flex-1 px-3 py-2 text-sm bg-background border border-input rounded-l-md focus:outline-none focus:ring-2 focus:ring-ring"
                />
                <Button size="sm" className="rounded-l-none">
                  订阅
                </Button>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-sm text-muted-foreground">
            {t('footer.copyright').replace('2025', currentYear.toString())}
          </div>
          
          {/* Additional Links */}
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <Link to="/help" className="hover:text-foreground transition-colors">
              帮助中心
            </Link>
            <span>|</span>
            <Link to="/feedback" className="hover:text-foreground transition-colors">
              意见反馈
            </Link>
            <span>|</span>
            <Link to="/cooperation" className="hover:text-foreground transition-colors">
              商务合作
            </Link>
          </div>
        </div>

        {/* ICP and Additional Legal Info */}
        <div className="mt-4 text-center">
          <div className="text-xs text-muted-foreground space-y-1">
            <p>京ICP备12345678号-1 | 京公网安备11010802012345号</p>
            <p>网络文化经营许可证：京网文(2025)1234-567号</p>
            <p>增值电信业务经营许可证：京B2-20251234</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
