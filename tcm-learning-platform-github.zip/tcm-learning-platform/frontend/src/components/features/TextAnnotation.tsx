import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface Annotation {
  id: number;
  text: string;
  explanation: string;
}

interface TextAnnotationProps {
  content: string;
  annotations: Annotation[];
  className?: string;
  vertical?: boolean;
  onAnnotationClick?: (annotation: Annotation) => void;
}

const TextAnnotation: React.FC<TextAnnotationProps> = ({
  content,
  annotations,
  className,
  vertical = false,
  onAnnotationClick,
}) => {
  const { t } = useTranslation();
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  // Sort annotations by position in the text
  const sortedAnnotations = [...annotations].sort((a, b) => {
    const posA = content.indexOf(a.text);
    const posB = content.indexOf(b.text);
    return posA - posB;
  });

  // Split the content into segments with annotations
  const renderContent = () => {
    if (!sortedAnnotations.length) return content;

    let lastIndex = 0;
    const result: React.ReactNode[] = [];

    sortedAnnotations.forEach((annotation, idx) => {
      const startIndex = content.indexOf(annotation.text, lastIndex);
      
      if (startIndex === -1) return;
      
      // Add text before the annotation
      if (startIndex > lastIndex) {
        result.push(
          <span key={`text-${idx}`} className="whitespace-pre-wrap">
            {content.substring(lastIndex, startIndex)}
          </span>
        );
      }
      
      // Add the annotated text
      const endIndex = startIndex + annotation.text.length;
      result.push(
        <TooltipProvider key={`annotation-${annotation.id}`}>
          <Tooltip>
            <TooltipTrigger asChild>
              <span
                className={cn(
                  "annotation-text cursor-pointer border-b border-dashed border-yellow-500",
                  hoveredId === annotation.id && "bg-yellow-100 dark:bg-yellow-900/30"
                )}
                onMouseEnter={() => setHoveredId(annotation.id)}
                onMouseLeave={() => setHoveredId(null)}
                onClick={() => onAnnotationClick && onAnnotationClick(annotation)}
              >
                {annotation.text}
              </span>
            </TooltipTrigger>
            <TooltipContent 
              side={vertical ? "left" : "top"} 
              className="max-w-[300px] text-sm" 
              sideOffset={5}
            >
              <div className="space-y-1">
                <p className="font-medium">{annotation.text}</p>
                <p className="text-muted-foreground">{annotation.explanation}</p>
              </div>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
      
      lastIndex = endIndex;
    });
    
    // Add any remaining text
    if (lastIndex < content.length) {
      result.push(
        <span key="text-end" className="whitespace-pre-wrap">
          {content.substring(lastIndex)}
        </span>
      );
    }
    
    return result;
  };

  return (
    <div ref={contentRef} className={cn("text-annotation", className)}>
      {renderContent()}
    </div>
  );
};

export default TextAnnotation;