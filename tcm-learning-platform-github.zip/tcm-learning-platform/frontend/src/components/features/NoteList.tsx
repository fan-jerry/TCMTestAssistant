import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Heart, MessageSquare, Share2, Edit, Clock, User, Lock, Unlock, Bookmark } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import NoteEditor, { Note } from './NoteEditor';

interface NoteListProps {
  contentId: number;
  contentType: 'theory' | 'herb' | 'formula' | 'acupoint';
  contentTitle: string;
  notes: Array<{
    id: number;
    user: {
      id: number;
      username: string;
      nickname: string;
      avatar?: string;
    };
    title: string;
    content: string;
    isPublic: boolean;
    status: 'draft' | 'published';
    likeCount: number;
    createdAt: string;
    updatedAt: string;
  }>;
  myNotes?: Array<{
    id: number;
    title: string;
    content: string;
    isPublic: boolean;
    status: 'draft' | 'published';
    likeCount: number;
    createdAt: string;
    updatedAt: string;
  }>;
  onCreateNote?: (note: Note) => void;
  onUpdateNote?: (note: Note) => void;
  onDeleteNote?: (noteId: number) => void;
  onLikeNote?: (noteId: number) => void;
}

const NoteList: React.FC<NoteListProps> = ({
  contentId,
  contentType,
  contentTitle,
  notes,
  myNotes = [],
  onCreateNote,
  onUpdateNote,
  onDeleteNote,
  onLikeNote
}) => {
  const { t } = useTranslation();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState<'public' | 'mine'>('public');
  const [isCreating, setIsCreating] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);
  
  const handleCreateNote = () => {
    if (!isAuthenticated) {
      toast({
        title: t('common.needLogin'),
        description: t('common.pleaseLoginFirst'),
        variant: 'destructive'
      });
      return;
    }
    
    setIsCreating(true);
    setActiveTab('mine');
  };
  
  const handleEditNote = (noteId: number) => {
    setEditingNoteId(noteId);
    setActiveTab('mine');
  };
  
  const handleSaveNote = (note: Note) => {
    if (note.id) {
      // Update existing note
      if (onUpdateNote) onUpdateNote(note);
    } else {
      // Create new note
      if (onCreateNote) onCreateNote(note);
    }
    
    setIsCreating(false);
    setEditingNoteId(null);
  };
  
  const handleCancelEdit = () => {
    setIsCreating(false);
    setEditingNoteId(null);
  };
  
  const handleDeleteNote = (noteId: number) => {
    if (onDeleteNote) onDeleteNote(noteId);
    setEditingNoteId(null);
  };
  
  const handleLikeNote = (noteId: number) => {
    if (!isAuthenticated) {
      toast({
        title: t('common.needLogin'),
        description: t('common.pleaseLoginFirst'),
        variant: 'destructive'
      });
      return;
    }
    
    if (onLikeNote) onLikeNote(noteId);
  };
  
  // Format date to readable string
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  return (
    <div className="w-full space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold">{t('note.notes')}</h3>
        <Button 
          onClick={handleCreateNote} 
          variant="outline"
          size="sm"
          disabled={isCreating}
        >
          {t('note.createNote')}
        </Button>
      </div>
      
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'public' | 'mine')}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="public">
            <MessageSquare className="h-4 w-4 mr-2" />
            {t('note.publicNotes')}
          </TabsTrigger>
          <TabsTrigger value="mine">
            <Bookmark className="h-4 w-4 mr-2" />
            {t('note.myNotes')}
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="public" className="mt-4 space-y-4">
          {notes.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>{t('note.noPublicNotes')}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {notes.map((note) => (
                <Card key={note.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={note.user.avatar} alt={note.user.nickname} />
                          <AvatarFallback>{note.user.nickname.substring(0, 2)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-base">{note.title}</CardTitle>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <User className="h-3.5 w-3.5 mr-1" />
                            <span>{note.user.nickname}</span>
                            <span className="mx-1">•</span>
                            <Clock className="h-3.5 w-3.5 mr-1" />
                            <span>{formatDate(note.updatedAt || note.createdAt)}</span>
                          </div>
                        </div>
                      </div>
                      <Badge variant="secondary" className="flex items-center">
                        <Unlock className="h-3 w-3 mr-1" />
                        {t('note.public')}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="prose prose-sm max-w-none dark:prose-invert">
                      {note.content}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-1 flex justify-between">
                    <div className="flex space-x-4">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleLikeNote(note.id)}
                        className="text-muted-foreground hover:text-primary"
                      >
                        <Heart className="h-4 w-4 mr-1" />
                        {note.likeCount}
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="text-muted-foreground hover:text-primary"
                      >
                        <Share2 className="h-4 w-4 mr-1" />
                        {t('common.share')}
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="mine" className="mt-4 space-y-4">
          {isCreating && (
            <div className="mb-6">
              <h4 className="text-base font-medium mb-2">{t('note.newNote')}</h4>
              <NoteEditor
                contentId={contentId}
                contentType={contentType}
                contentTitle={contentTitle}
                onSave={handleSaveNote}
                onCancel={handleCancelEdit}
              />
              <Separator className="my-6" />
            </div>
          )}
          
          {editingNoteId !== null && myNotes.some(note => note.id === editingNoteId) && (
            <div className="mb-6">
              <h4 className="text-base font-medium mb-2">{t('note.editNote')}</h4>
              <NoteEditor
                contentId={contentId}
                contentType={contentType}
                contentTitle={contentTitle}
                initialNote={myNotes.find(note => note.id === editingNoteId) as any}
                onSave={handleSaveNote}
                onCancel={handleCancelEdit}
                onDelete={handleDeleteNote}
              />
              <Separator className="my-6" />
            </div>
          )}
          
          {!isAuthenticated ? (
            <div className="text-center py-8 text-muted-foreground">
              <Lock className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>{t('common.pleaseLoginToViewNotes')}</p>
            </div>
          ) : myNotes.length === 0 && !isCreating ? (
            <div className="text-center py-8 text-muted-foreground">
              <Bookmark className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>{t('note.noPersonalNotes')}</p>
              <Button 
                onClick={handleCreateNote} 
                variant="outline"
                size="sm"
                className="mt-2"
              >
                {t('note.createFirstNote')}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {myNotes
                .filter(note => note.id !== editingNoteId)
                .map((note) => (
                <Card key={note.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-base">{note.title}</CardTitle>
                      <div className="flex space-x-2">
                        <Badge variant={note.status === 'draft' ? 'outline' : 'secondary'}>
                          {note.status === 'draft' ? t('note.draft') : t('note.published')}
                        </Badge>
                        <Badge variant={note.isPublic ? 'secondary' : 'outline'} className="flex items-center">
                          {note.isPublic ? (
                            <><Unlock className="h-3 w-3 mr-1" />{t('note.public')}</>
                          ) : (
                            <><Lock className="h-3 w-3 mr-1" />{t('note.private')}</>
                          )}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <Clock className="h-3.5 w-3.5 inline mr-1" />
                      <span>{formatDate(note.updatedAt || note.createdAt)}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="prose prose-sm max-w-none dark:prose-invert">
                      {note.content}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-1 flex justify-between">
                    <div className="flex space-x-4">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-muted-foreground"
                      >
                        <Heart className="h-4 w-4 mr-1" />
                        {note.likeCount}
                      </Button>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleEditNote(note.id)}
                      className="text-muted-foreground hover:text-primary"
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      {t('common.edit')}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default NoteList;