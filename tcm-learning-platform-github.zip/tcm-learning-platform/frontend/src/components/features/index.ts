// Export all feature components
export { default as VerticalText } from './VerticalText';
export { default as TextAnnotation } from './TextAnnotation';
export { default as NoteEditor } from './NoteEditor';
export { default as NoteList } from './NoteList';
export { default as ReadingProgress } from './ReadingProgress';

// Export types
export type { Note } from './NoteEditor';