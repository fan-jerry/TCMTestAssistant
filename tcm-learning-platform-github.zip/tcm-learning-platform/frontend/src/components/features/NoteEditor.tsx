import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Save, X, Send, Bookmark, BookmarkCheck, Lock, Unlock, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

export interface Note {
  id: number | null;
  contentId: number;
  contentType: 'theory' | 'herb' | 'formula' | 'acupoint';
  title: string;
  content: string;
  position?: string;
  isPublic: boolean;
  status: 'draft' | 'published';
}

interface NoteEditorProps {
  contentId: number;
  contentType: 'theory' | 'herb' | 'formula' | 'acupoint';
  contentTitle: string;
  position?: string;
  initialNote?: Note;
  onSave?: (note: Note) => void;
  onCancel?: () => void;
  onDelete?: (noteId: number) => void;
}

const NoteEditor: React.FC<NoteEditorProps> = ({
  contentId,
  contentType,
  contentTitle,
  position,
  initialNote,
  onSave,
  onCancel,
  onDelete
}) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();
  
  const [note, setNote] = useState<Note>({
    id: initialNote?.id || null,
    contentId,
    contentType,
    title: initialNote?.title || `${t('note.about')} ${contentTitle}`,
    content: initialNote?.content || '',
    position: position || initialNote?.position,
    isPublic: initialNote?.isPublic ?? false,
    status: initialNote?.status || 'draft'
  });
  
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  useEffect(() => {
    // Update note if initialNote changes
    if (initialNote) {
      setNote({
        id: initialNote.id,
        contentId,
        contentType,
        title: initialNote.title,
        content: initialNote.content,
        position: initialNote.position || position,
        isPublic: initialNote.isPublic,
        status: initialNote.status
      });
    }
  }, [initialNote, contentId, contentType, position]);
  
  const handleSave = async (publish: boolean = false) => {
    if (!isAuthenticated) {
      toast({
        title: t('common.needLogin'),
        description: t('common.pleaseLoginFirst'),
        variant: 'destructive'
      });
      return;
    }
    
    setIsSaving(true);
    try {
      // Update status if publishing
      const updatedNote = {
        ...note,
        status: publish ? 'published' : note.status
      };
      
      // API call would go here
      // const response = await api.saveNote(updatedNote);
      // setNote({ ...updatedNote, id: response.id });
      
      // For now, just simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      toast({
        title: publish ? t('note.published') : t('note.saved'),
        description: publish 
          ? t('note.publishedSuccessfully') 
          : t('note.savedSuccessfully'),
      });
      
      if (onSave) onSave(updatedNote);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: t('note.errorSaving'),
        variant: 'destructive'
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleDelete = async () => {
    if (!note.id) return;
    
    setIsDeleting(true);
    try {
      // API call would go here
      // await api.deleteNote(note.id);
      
      // For now, just simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      toast({
        title: t('note.deleted'),
        description: t('note.deletedSuccessfully'),
      });
      
      if (onDelete) onDelete(note.id);
    } catch (error) {
      toast({
        title: t('common.error'),
        description: t('note.errorDeleting'),
        variant: 'destructive'
      });
    } finally {
      setIsDeleting(false);
    }
  };
  
  const handleCancel = () => {
    if (onCancel) onCancel();
  };
  
  return (
    <Card className="w-full">
      <CardContent className="pt-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <input
              className="text-lg font-medium bg-transparent border-none focus:outline-none w-full"
              value={note.title}
              onChange={(e) => setNote({ ...note, title: e.target.value })}
              placeholder={t('note.title')}
            />
          </div>
          
          <Textarea
            value={note.content}
            onChange={(e) => setNote({ ...note, content: e.target.value })}
            placeholder={t('note.content')}
            className="min-h-[200px] resize-y"
          />
          
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">{t('note.visibility')}:</span>
              <ToggleGroup type="single" value={note.isPublic ? 'public' : 'private'}>
                <ToggleGroupItem 
                  value="private" 
                  aria-label={t('note.private')}
                  onClick={() => setNote({ ...note, isPublic: false })}
                >
                  <Lock className="h-4 w-4 mr-1" />
                  {t('note.private')}
                </ToggleGroupItem>
                <ToggleGroupItem 
                  value="public" 
                  aria-label={t('note.public')}
                  onClick={() => setNote({ ...note, isPublic: true })}
                >
                  <Unlock className="h-4 w-4 mr-1" />
                  {t('note.public')}
                </ToggleGroupItem>
              </ToggleGroup>
            </div>
            
            <div className="text-sm text-muted-foreground">
              {note.id ? (
                <span>{t('note.lastEdited')}: {new Date().toLocaleString()}</span>
              ) : (
                <span>{t('note.newNote')}</span>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between pt-2 pb-4 px-6">
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={handleCancel} disabled={isSaving || isDeleting}>
            <X className="h-4 w-4 mr-1" />
            {t('common.cancel')}
          </Button>
          
          {note.id && (
            <Button variant="destructive" size="sm" onClick={handleDelete} disabled={isSaving || isDeleting}>
              {isDeleting ? t('common.deleting') : t('common.delete')}
            </Button>
          )}
        </div>
        
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handleSave(false)} 
            disabled={isSaving || isDeleting || !note.content.trim()}
          >
            <Save className="h-4 w-4 mr-1" />
            {isSaving && note.status === 'draft' ? t('common.saving') : t('common.saveDraft')}
          </Button>
          
          <Button 
            variant="default" 
            size="sm"
            onClick={() => handleSave(true)} 
            disabled={isSaving || isDeleting || !note.content.trim()}
          >
            <Send className="h-4 w-4 mr-1" />
            {isSaving && note.status === 'published' ? t('common.publishing') : t('common.publish')}
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default NoteEditor;