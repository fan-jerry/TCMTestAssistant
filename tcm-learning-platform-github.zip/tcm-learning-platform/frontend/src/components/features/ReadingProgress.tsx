import React from 'react';
import { useTranslation } from 'react-i18next';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface ReadingProgressProps {
  progress: number; // 0-100
  className?: string;
  showPercentage?: boolean;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
  colorScheme?: 'default' | 'success' | 'warning';
  orientation?: 'horizontal' | 'vertical';
}

const ReadingProgress: React.FC<ReadingProgressProps> = ({
  progress,
  className,
  showPercentage = true,
  showText = true,
  size = 'md',
  colorScheme = 'default',
  orientation = 'horizontal',
}) => {
  const { t } = useTranslation();
  const roundedProgress = Math.round(progress);
  
  // Define height/width based on size
  const getSize = () => {
    switch (size) {
      case 'sm': return orientation === 'horizontal' ? 'h-1' : 'w-1';
      case 'lg': return orientation === 'horizontal' ? 'h-3' : 'w-3';
      default: return orientation === 'horizontal' ? 'h-2' : 'w-2';
    }
  };
  
  // Define color based on scheme
  const getColor = () => {
    switch (colorScheme) {
      case 'success': return 'bg-green-500';
      case 'warning': return 'bg-amber-500';
      default: return '';
    }
  };
  
  // Get status text based on progress
  const getStatusText = () => {
    if (progress < 1) return t('reading.notStarted');
    if (progress < 25) return t('reading.justStarted');
    if (progress < 75) return t('reading.inProgress');
    if (progress < 100) return t('reading.nearlyComplete');
    return t('reading.completed');
  };
  
  return (
    <div className={cn(
      'flex items-center gap-2',
      orientation === 'vertical' && 'flex-col h-full',
      className
    )}>
      <div className={cn(
        'relative flex-1 w-full',
        orientation === 'vertical' && 'h-full'
      )}>
        {orientation === 'horizontal' ? (
          <Progress 
            value={roundedProgress} 
            className={cn(getSize(), 'w-full')}
            indicatorClassName={getColor()}
          />
        ) : (
          <div className="relative h-full w-2 bg-secondary rounded-full overflow-hidden">
            <div 
              className={cn("absolute bottom-0 w-full transition-all rounded-full", getColor() || "bg-primary")}
              style={{ height: `${roundedProgress}%` }}
            />
          </div>
        )}
      </div>
      
      {(showPercentage || showText) && (
        <div className={cn(
          'text-xs text-muted-foreground flex',
          orientation === 'vertical' ? 'flex-col items-center' : 'items-center gap-1'
        )}>
          {showPercentage && (
            <span className="font-medium">{roundedProgress}%</span>
          )}
          {showText && showPercentage && (
            <span className="mx-1">•</span>
          )}
          {showText && (
            <span>{getStatusText()}</span>
          )}
        </div>
      )}
    </div>
  );
};

export default ReadingProgress;