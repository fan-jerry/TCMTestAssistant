import React from 'react';
import { cn } from '@/lib/utils';

interface VerticalTextProps {
  children: React.ReactNode;
  className?: string;
  fontSize?: number;
  lineHeight?: number;
  letterSpacing?: number;
  direction?: 'ltr' | 'rtl';
  showGridLines?: boolean;
}

const VerticalText: React.FC<VerticalTextProps> = ({
  children,
  className,
  fontSize = 18,
  lineHeight = 1.8,
  letterSpacing = 0.1,
  direction = 'rtl',
  showGridLines = false,
}) => {
  return (
    <div
      className={cn(
        'vertical-text select-text',
        direction === 'rtl' ? 'vertical-rl' : 'vertical-lr',
        showGridLines && 'bg-grid',
        className
      )}
      style={{
        writingMode: direction === 'rtl' ? 'vertical-rl' : 'vertical-lr',
        fontSize: `${fontSize}px`,
        lineHeight: lineHeight,
        letterSpacing: `${letterSpacing}em`,
        textAlign: 'justify',
        ...({ textJustify: 'inter-ideograph' } as any),
      }}
    >
      {children}
    </div>
  );
};

export default VerticalText;