import React from 'react';
import { Helmet } from 'react-helmet-async';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: string;
  locale?: string;
  siteName?: string;
  author?: string;
  publishedTime?: string;
  modifiedTime?: string;
  section?: string;
  tags?: string[];
  noIndex?: boolean;
  canonical?: string;
  alternateLanguages?: Array<{
    hreflang: string;
    href: string;
  }>;
  structuredData?: object;
}

const SEO: React.FC<SEOProps> = ({
  title = '中医学习平台 - 传承千年智慧，学习中医精髓',
  description = '专业的中医学习平台，提供中药材数据库、方剂大全、针灸穴位、学习资源等丰富内容。传承千年中医智慧，助您深入理解传统中医药文化。',
  keywords = '中医,中药,方剂,针灸,穴位,学习平台,传统医学,TCM,中医药,中医教育',
  image = 'https://tcm-learning.com/images/og-image.jpg',
  url = 'https://tcm-learning.com',
  type = 'website',
  locale = 'zh_CN',
  siteName = '中医学习平台',
  author = '中医学习平台',
  publishedTime,
  modifiedTime,
  section,
  tags = [],
  noIndex = false,
  canonical,
  alternateLanguages = [
    { hreflang: 'zh-CN', href: 'https://tcm-learning.com' },
    { hreflang: 'en-US', href: 'https://tcm-learning.com/en' },
  ],
  structuredData,
}) => {
  const fullTitle = title.includes('中医学习平台') ? title : `${title} - 中医学习平台`;
  const fullUrl = url.startsWith('http') ? url : `https://tcm-learning.com${url}`;
  const fullImage = image.startsWith('http') ? image : `https://tcm-learning.com${image}`;

  return (
    <Helmet>
      {/* 基础 Meta 标签 */}
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      <meta name="author" content={author} />
      
      {/* SEO 控制 */}
      {noIndex ? (
        <meta name="robots" content="noindex, nofollow" />
      ) : (
        <meta name="robots" content="index, follow" />
      )}
      
      {/* 规范链接 */}
      {canonical && <link rel="canonical" href={canonical} />}
      
      {/* 语言替代版本 */}
      {alternateLanguages.map((lang) => (
        <link key={lang.hreflang} rel="alternate" hrefLang={lang.hreflang} href={lang.href} />
      ))}
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content={type} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={fullImage} />
      <meta property="og:url" content={fullUrl} />
      <meta property="og:site_name" content={siteName} />
      <meta property="og:locale" content={locale} />
      
      {/* 文章特定的 Open Graph 标签 */}
      {type === 'article' && (
        <>
          {publishedTime && <meta property="article:published_time" content={publishedTime} />}
          {modifiedTime && <meta property="article:modified_time" content={modifiedTime} />}
          {author && <meta property="article:author" content={author} />}
          {section && <meta property="article:section" content={section} />}
          {tags.map((tag) => (
            <meta key={tag} property="article:tag" content={tag} />
          ))}
        </>
      )}
      
      {/* Twitter Cards */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={fullImage} />
      <meta name="twitter:url" content={fullUrl} />
      
      {/* 其他 Meta 标签 */}
      <meta name="format-detection" content="telephone=no" />
      <meta name="theme-color" content="#059669" />
      
      {/* 结构化数据 */}
      {structuredData && (
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      )}
    </Helmet>
  );
};

export default SEO;
