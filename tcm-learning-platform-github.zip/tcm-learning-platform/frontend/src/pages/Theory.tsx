import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Search,
  Filter,
  Grid,
  List,
  BookOpen,
  User,
  Calendar,
  Clock,
  Star,
  Eye,
  Heart,
  Download,
  ChevronDown,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';

const Theory: React.FC = () => {
  const { t } = useTranslation();
  const { isAuthenticated } = useAuth();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [currentPage, setCurrentPage] = useState(1);

  // 分类数据
  const categories = [
    { value: 'all', label: '全部分类' },
    { value: 'classic', label: '古典经典' },
    { value: 'modern', label: '现代理论' },
    { value: 'basic', label: '基础理论' },
    { value: 'clinical', label: '临床实践' },
    { value: 'diagnosis', label: '诊断学' },
    { value: 'treatment', label: '治疗学' },
  ];

  const difficulties = [
    { value: 'all', label: '全部难度' },
    { value: 'BEGINNER', label: '入门' },
    { value: 'INTERMEDIATE', label: '进阶' },
    { value: 'ADVANCED', label: '高级' },
  ];

  // 模拟理论书籍数据
  const theories = [
    {
      id: 1,
      title: '黄帝内经',
      subtitle: '素问 · 灵枢',
      author: '黄帝',
      dynasty: '先秦',
      cover: '/images/theories/huangdi-neijing.jpg',
      summary: '中医理论的奠基之作，阐述了中医学的基本理论，包括阴阳五行、脏腑经络、病因病机、诊断治疗等内容。',
      category: 'classic',
      difficulty: 'ADVANCED',
      readingTime: 720,
      viewCount: 12580,
      likeCount: 892,
      chapters: 162,
      isPremium: false,
      isPublished: true,
      publishedAt: '2024-01-01',
      tags: ['经典', '基础理论', '阴阳五行'],
    },
    {
      id: 2,
      title: '伤寒论',
      subtitle: '伤寒杂病论',
      author: '张仲景',
      dynasty: '东汉',
      cover: '/images/theories/shanghan-lun.jpg',
      summary: '辨证论治的典范，详细论述了外感热病的诊断和治疗方法，确立了六经辨证的理论体系。',
      category: 'classic',
      difficulty: 'ADVANCED',
      readingTime: 480,
      viewCount: 9876,
      likeCount: 765,
      chapters: 113,
      isPremium: true,
      isPublished: true,
      publishedAt: '2024-01-02',
      tags: ['伤寒', '辨证论治', '方剂'],
    },
    {
      id: 3,
      title: '本草纲目',
      subtitle: '明代本草集大成者',
      author: '李时珍',
      dynasty: '明代',
      cover: '/images/theories/bencao-gangmu.jpg',
      summary: '集历代本草学之大成，收录药物1892种，详细记载了各种药物的性味归经、功效主治。',
      category: 'classic',
      difficulty: 'INTERMEDIATE',
      readingTime: 960,
      viewCount: 15420,
      likeCount: 1123,
      chapters: 52,
      isPremium: false,
      isPublished: true,
      publishedAt: '2024-01-03',
      tags: ['本草', '药物学', '李时珍'],
    },
    {
      id: 4,
      title: '针灸甲乙经',
      subtitle: '针灸学经典',
      author: '皇甫谧',
      dynasty: '晋代',
      cover: '/images/theories/zhenjiu-jiayijing.jpg',
      summary: '中国现存最早的针灸学专著，系统总结了针灸学理论和临床经验。',
      category: 'classic',
      difficulty: 'INTERMEDIATE',
      readingTime: 360,
      viewCount: 7890,
      likeCount: 567,
      chapters: 128,
      isPremium: true,
      isPublished: true,
      publishedAt: '2024-01-04',
      tags: ['针灸', '经络', '穴位'],
    },
    {
      id: 5,
      title: '中医基础理论',
      subtitle: '现代中医教材',
      author: '王永炎',
      dynasty: '现代',
      cover: '/images/theories/tcm-basic-theory.jpg',
      summary: '现代中医基础理论教材，系统阐述了中医学的基本概念、基本理论和基本知识。',
      category: 'basic',
      difficulty: 'BEGINNER',
      readingTime: 240,
      viewCount: 23450,
      likeCount: 1567,
      chapters: 20,
      isPremium: false,
      isPublished: true,
      publishedAt: '2024-01-05',
      tags: ['基础理论', '教材', '现代'],
    },
    {
      id: 6,
      title: '中医诊断学',
      subtitle: '现代诊断理论与实践',
      author: '朱文锋',
      dynasty: '现代',
      cover: '/images/theories/tcm-diagnosis.jpg',
      summary: '现代中医诊断学教材，详细介绍了中医诊断的基本方法和临床应用。',
      category: 'diagnosis',
      difficulty: 'INTERMEDIATE',
      readingTime: 320,
      viewCount: 18760,
      likeCount: 1234,
      chapters: 24,
      isPremium: true,
      isPublished: true,
      publishedAt: '2024-01-06',
      tags: ['诊断学', '四诊', '辨证'],
    },
  ];

  // 过滤逻辑
  const filteredTheories = theories.filter(theory => {
    const matchesSearch = theory.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         theory.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         theory.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || theory.category === selectedCategory;
    const matchesDifficulty = selectedDifficulty === 'all' || theory.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesCategory && matchesDifficulty;
  });

  // 排序逻辑
  const sortedTheories = [...filteredTheories].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.title.localeCompare(b.title);
      case 'author':
        return a.author.localeCompare(b.author);
      case 'viewCount':
        return b.viewCount - a.viewCount;
      case 'likeCount':
        return b.likeCount - a.likeCount;
      case 'publishedAt':
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
      default:
        return 0;
    }
  });

  // 书籍卡片组件（古籍风格）
  const TheoryCard: React.FC<{ theory: any }> = ({ theory }) => (
    <Card className="h-full hover:shadow-lg transition-all duration-300 group relative overflow-hidden">
      {/* 古典装饰边框 */}
      <div className="absolute inset-0 border-2 border-amber-200/50 rounded-lg m-1 pointer-events-none group-hover:border-amber-300/70 transition-colors" />
      
      <CardHeader className="pb-3">
        <div className="flex items-start space-x-4">
          {/* 书籍封面 */}
          <div className="relative">
            <div className="w-20 h-28 bg-gradient-to-b from-amber-50 to-amber-100 rounded-md border border-amber-200 flex items-center justify-center shadow-md">
              {theory.cover ? (
                <img src={theory.cover} alt={theory.title} className="w-full h-full object-cover rounded-md" />
              ) : (
                <BookOpen className="h-8 w-8 text-amber-600" />
              )}
            </div>
            {theory.isPremium && (
              <Badge variant="secondary" className="absolute -top-2 -right-2 bg-amber-500 text-white text-xs">
                会员
              </Badge>
            )}
          </div>
          
          {/* 书籍信息 */}
          <div className="flex-1 min-w-0">
            <CardTitle className="text-lg font-bold text-gray-800 mb-1 group-hover:text-amber-700 transition-colors">
              {theory.title}
            </CardTitle>
            {theory.subtitle && (
              <p className="text-sm text-gray-600 mb-2">{theory.subtitle}</p>
            )}
            <div className="flex items-center space-x-4 text-xs text-gray-500 mb-2">
              <span className="flex items-center">
                <User className="h-3 w-3 mr-1" />
                {theory.author}
              </span>
              {theory.dynasty && (
                <span className="flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  {theory.dynasty}
                </span>
              )}
            </div>
            <div className="flex flex-wrap gap-1 mb-2">
              {theory.tags.slice(0, 3).map((tag: string, index: number) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <CardDescription className="text-sm text-gray-600 mb-4 line-clamp-3">
          {theory.summary}
        </CardDescription>
        
        {/* 统计信息 */}
        <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
          <div className="flex items-center space-x-3">
            <span className="flex items-center">
              <Eye className="h-3 w-3 mr-1" />
              {theory.viewCount.toLocaleString()}
            </span>
            <span className="flex items-center">
              <Heart className="h-3 w-3 mr-1" />
              {theory.likeCount}
            </span>
            <span className="flex items-center">
              <BookOpen className="h-3 w-3 mr-1" />
              {theory.chapters}章
            </span>
          </div>
          <span className="flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            {Math.floor(theory.readingTime / 60)}小时
          </span>
        </div>
        
        {/* 操作按钮 */}
        <div className="flex space-x-2">
          <Button asChild className="flex-1" size="sm">
            <Link to={`/theory/${theory.id}`}>
              <BookOpen className="h-4 w-4 mr-1" />
              阅读详情
            </Link>
          </Button>
          {isAuthenticated && (
            <Button variant="outline" size="sm" className="px-3">
              <Heart className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );

  // 列表视图组件
  const TheoryListItem: React.FC<{ theory: any }> = ({ theory }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-22 bg-gradient-to-b from-amber-50 to-amber-100 rounded border border-amber-200 flex items-center justify-center flex-shrink-0">
            {theory.cover ? (
              <img src={theory.cover} alt={theory.title} className="w-full h-full object-cover rounded" />
            ) : (
              <BookOpen className="h-6 w-6 text-amber-600" />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-1">{theory.title}</h3>
                <p className="text-sm text-gray-600 mb-2">{theory.author} · {theory.dynasty}</p>
                <p className="text-sm text-gray-600 line-clamp-2 mb-2">{theory.summary}</p>
                <div className="flex items-center space-x-4 text-xs text-gray-500">
                  <span>{theory.viewCount.toLocaleString()} 阅读</span>
                  <span>{theory.likeCount} 点赞</span>
                  <span>{theory.chapters} 章节</span>
                  <span>{Math.floor(theory.readingTime / 60)} 小时</span>
                </div>
              </div>
              
              <div className="flex flex-col items-end space-y-2">
                {theory.isPremium && (
                  <Badge variant="secondary" className="bg-amber-500 text-white">会员</Badge>
                )}
                <Button asChild size="sm">
                  <Link to={`/theory/${theory.id}`}>阅读</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 页面标题 */}
      <div className="mb-8 text-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-2 text-gray-800">{t('theory.title')}</h1>
        <p className="text-xl text-muted-foreground">
          {t('theory.subtitle')}
        </p>
      </div>

      {/* 搜索和筛选 */}
      <div className="mb-6">
        <div className="flex flex-col lg:flex-row gap-4 mb-4">
          {/* 搜索框 */}
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder={t('theory.searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* 筛选器 */}
          <div className="flex gap-2">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="选择分类" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="难度" />
              </SelectTrigger>
              <SelectContent>
                {difficulties.map((difficulty) => (
                  <SelectItem key={difficulty.value} value={difficulty.value}>
                    {difficulty.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="w-[120px]">
                  <Filter className="h-4 w-4 mr-2" />
                  排序
                  <ChevronDown className="h-4 w-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>排序方式</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setSortBy('name')}>
                  按名称排序
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('author')}>
                  按作者排序
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('viewCount')}>
                  按阅读量排序
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('likeCount')}>
                  按点赞数排序
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('publishedAt')}>
                  按发布时间排序
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* 视图切换 */}
            <div className="flex border border-border rounded-md">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-r-none"
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* 分类标签 */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
            {categories.map((category) => (
              <TabsTrigger key={category.value} value={category.value} className="text-xs">
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      {/* 理论书籍列表 */}
      <div className="mb-8">
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedTheories.map((theory) => (
              <TheoryCard key={theory.id} theory={theory} />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {sortedTheories.map((theory) => (
              <TheoryListItem key={theory.id} theory={theory} />
            ))}
          </div>
        )}

        {sortedTheories.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">暂无相关理论文献</h3>
            <p className="text-muted-foreground">请尝试调整筛选条件或搜索关键词</p>
          </div>
        )}
      </div>

      {/* 分页 */}
      {sortedTheories.length > 0 && (
        <div className="flex justify-center">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious href="#" />
              </PaginationItem>
              <PaginationItem>
                <PaginationLink href="#" isActive>1</PaginationLink>
              </PaginationItem>
              <PaginationItem>
                <PaginationLink href="#">2</PaginationLink>
              </PaginationItem>
              <PaginationItem>
                <PaginationLink href="#">3</PaginationLink>
              </PaginationItem>
              <PaginationItem>
                <PaginationNext href="#" />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}
    </div>
  );
};

export default Theory;
