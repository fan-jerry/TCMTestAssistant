import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import {
  ArrowLeft,
  Bookmark,
  Heart,
  Share2,
  MessageSquare,
  AlertCircle,
  MapPin,
  Target,
  Stethoscope,
  Activity,
  Eye,
  Zap,
  Navigation,
  Timer,
  Users,
  Book,
  Star,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface Acupoint {
  id: number;
  name: string;
  pinyin: string;
  englishName: string;
  code: string;
  meridian: string;
  meridianType: string;
  location: string;
  anatomicalLocation: string;
  positioning: string;
  functions: string;
  indications: string;
  needleMethod: {
    direction: string;
    depth: string;
    angle: string;
    manipulation: string;
  };
  precautions: string;
  clinicalApplications: string[];
  relatedAcupoints: string[];
  isPremium: boolean;
  viewCount: number;
  likeCount: number;
  image: string;
}

const AcupointDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [isFavorited, setIsFavorited] = useState(false);
  const [acupoint, setAcupoint] = useState<Acupoint | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchAcupointDetail(parseInt(id));
    }
  }, [id]);

  const fetchAcupointDetail = async (acupointId: number) => {
    try {
      setLoading(true);
      const response = await fetch('/data/acupoints.json');
      const data = await response.json();
      const foundAcupoint = data.find((item: Acupoint) => item.id === acupointId);
      
      if (foundAcupoint) {
        setAcupoint(foundAcupoint);
      } else {
        throw new Error('穴位未找到');
      }
    } catch (error) {
      console.error('加载穴位详情失败:', error);
      toast({
        variant: "destructive",
        title: "加载失败",
        description: "无法加载穴位详情，请稍后重试",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFavorite = async () => {
    if (!isAuthenticated) {
      toast({
        variant: "destructive",
        title: "请先登录",
        description: "登录后即可收藏穴位",
      });
      return;
    }

    try {
      // 模拟收藏操作
      setIsFavorited(!isFavorited);
      toast({
        title: isFavorited ? "取消收藏" : "收藏成功",
        description: isFavorited ? "已从收藏中移除" : "已添加到收藏夹",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "操作失败",
        description: "请稍后重试",
      });
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${acupoint?.name} - 穴位详情`,
          text: `${acupoint?.name}穴位详情 - ${acupoint?.functions}`,
          url: window.location.href,
        });
      } catch (error) {
        console.log('分享失败');
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "链接已复制",
        description: "分享链接已复制到剪贴板",
      });
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!acupoint) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center py-20">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-2xl font-semibold mb-2">穴位未找到</h2>
          <p className="text-muted-foreground mb-4">请检查链接是否正确</p>
          <Button onClick={() => navigate('/acupoints')}>
            返回穴位列表
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 返回按钮 */}
      <div className="mb-6">
        <Button
          variant="ghost"
          onClick={() => navigate('/acupoints')}
          className="gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          返回穴位列表
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 主内容区域 */}
        <div className="lg:col-span-2 space-y-6">
          {/* 穴位基本信息 */}
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <div className={cn("w-16 h-16 rounded-xl flex items-center justify-center text-white", acupoint.image)}>
                      <Target className="w-8 h-8" />
                    </div>
                    <div>
                      <CardTitle className="text-2xl md:text-3xl font-bold mb-1">
                        {acupoint.name}
                        {acupoint.isPremium && (
                          <Badge variant="secondary" className="ml-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                            VIP
                          </Badge>
                        )}
                      </CardTitle>
                      <p className="text-lg text-muted-foreground">{acupoint.pinyin}</p>
                      <p className="text-sm text-muted-foreground italic">{acupoint.englishName}</p>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="outline" className="gap-1">
                      <MapPin className="w-3 h-3" />
                      {acupoint.code}
                    </Badge>
                    <Badge variant="outline">{acupoint.meridian}</Badge>
                    <Badge variant="outline">{acupoint.meridianType}</Badge>
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      <span>浏览 {acupoint.viewCount.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      <span>收藏 {acupoint.likeCount}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col gap-2">
                  <Button
                    variant={isFavorited ? "default" : "outline"}
                    size="sm"
                    onClick={handleFavorite}
                    className="gap-2"
                  >
                    <Heart className={cn("w-4 h-4", isFavorited && "fill-current")} />
                    {isFavorited ? '已收藏' : '收藏'}
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleShare} className="gap-2">
                    <Share2 className="w-4 h-4" />
                    分享
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* 详细信息标签页 */}
          <Tabs defaultValue="location" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="location" className="text-xs">定位方法</TabsTrigger>
              <TabsTrigger value="functions" className="text-xs">功能主治</TabsTrigger>
              <TabsTrigger value="needling" className="text-xs">针灸方法</TabsTrigger>
              <TabsTrigger value="clinical" className="text-xs">临床应用</TabsTrigger>
              <TabsTrigger value="precautions" className="text-xs">注意事项</TabsTrigger>
            </TabsList>

            <TabsContent value="location" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5" />
                    穴位定位
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Navigation className="w-4 h-4" />
                      精确定位
                    </h4>
                    <p className="text-muted-foreground leading-relaxed">{acupoint.location}</p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Activity className="w-4 h-4" />
                      解剖位置
                    </h4>
                    <p className="text-muted-foreground leading-relaxed">{acupoint.anatomicalLocation}</p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2">
                      <Target className="w-4 h-4" />
                      取穴方法
                    </h4>
                    <p className="text-muted-foreground leading-relaxed">{acupoint.positioning}</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="functions" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Stethoscope className="w-5 h-5" />
                    功能主治
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">主要功效</h4>
                    <p className="text-muted-foreground leading-relaxed">{acupoint.functions}</p>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h4 className="font-semibold mb-2">适应症</h4>
                    <p className="text-muted-foreground leading-relaxed">{acupoint.indications}</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="needling" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5" />
                    针灸方法
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium">针刺方向</TableCell>
                        <TableCell>{acupoint.needleMethod.direction}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">针刺深度</TableCell>
                        <TableCell>{acupoint.needleMethod.depth}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">针刺角度</TableCell>
                        <TableCell>{acupoint.needleMethod.angle}</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">手法操作</TableCell>
                        <TableCell>{acupoint.needleMethod.manipulation}</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="clinical" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    临床应用
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {acupoint.clinicalApplications.map((application, index) => (
                      <div key={index} className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                        <Star className="w-4 h-4 text-primary" />
                        <span className="text-sm">{application}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="precautions" className="space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>注意事项</AlertTitle>
                <AlertDescription className="mt-2">
                  {acupoint.precautions}
                </AlertDescription>
              </Alert>
            </TabsContent>
          </Tabs>
        </div>

        {/* 侧边栏 */}
        <div className="space-y-6">
          {/* 相关穴位 */}
          {acupoint.relatedAcupoints.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">相关穴位</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {acupoint.relatedAcupoints.map((relatedName, index) => (
                    <div key={index} className="flex items-center gap-2 p-2 hover:bg-muted/50 rounded-lg transition-colors">
                      <Target className="w-4 h-4 text-primary" />
                      <span className="text-sm">{relatedName}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* 学习建议 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Book className="w-5 h-5" />
                学习建议
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <h4 className="font-medium text-sm">初学者</h4>
                <p className="text-xs text-muted-foreground">
                  先掌握穴位的准确定位，可以通过触摸和标记来熟悉穴位位置
                </p>
              </div>
              <Separator />
              <div className="space-y-2">
                <h4 className="font-medium text-sm">进阶练习</h4>
                <p className="text-xs text-muted-foreground">
                  学习不同针刺角度和深度的临床应用，掌握补泻手法
                </p>
              </div>
              <Separator />
              <div className="space-y-2">
                <h4 className="font-medium text-sm">临床应用</h4>
                <p className="text-xs text-muted-foreground">
                  结合患者症状选择合适的配穴，注意禁忌症和注意事项
                </p>
              </div>
            </CardContent>
          </Card>

          {/* 快速操作 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">快速操作</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start gap-2">
                <MessageSquare className="w-4 h-4" />
                添加学习笔记
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start gap-2">
                <Bookmark className="w-4 h-4" />
                加入学习计划
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start gap-2" asChild>
                <Link to="/quiz">
                  <Timer className="w-4 h-4" />
                  相关穴位测试
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AcupointDetail;
