import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Eye,
  EyeOff,
  LogIn,
  Mail,
  Lock,
  ArrowLeft,
  BookOpen,
  Shield,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const loginSchema = z.object({
  username: z.string().min(1, '请输入用户名或邮箱'),
  password: z.string().min(1, '请输入密码'),
  captcha: z.string().min(4, '请输入验证码'),
  remember: z.boolean().optional(),
});

type LoginFormData = z.infer<typeof loginSchema>;

const Login: React.FC = () => {
  const { t } = useTranslation();
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [captchaUrl, setCaptchaUrl] = useState('/api/auth/captcha?' + Date.now());
  const [error, setError] = useState<string | null>(null);

  const from = (location.state as any)?.from?.pathname || '/';

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      remember: false,
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    try {
      setIsLoading(true);
      setError(null);
      
      await login({
        username: data.username,
        password: data.password,
        captcha: data.captcha,
        remember: data.remember,
      });
      
      toast.success(t('auth.loginSuccess'));
      navigate(from, { replace: true });
    } catch (error: any) {
      setError(error.message || '登录失败，请重试');
      // 登录失败后刷新验证码
      refreshCaptcha();
    } finally {
      setIsLoading(false);
    }
  };

  const refreshCaptcha = () => {
    setCaptchaUrl('/api/auth/captcha?' + Date.now());
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-cyan-50 p-4">
      <div className="w-full max-w-4xl grid lg:grid-cols-2 gap-8 lg:gap-0">
        {/* Left Side - Branding */}
        <div className="hidden lg:flex flex-col justify-center p-12 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-l-lg">
          <div className="max-w-md">
            <div className="flex items-center space-x-2 mb-8">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary-foreground text-primary">
                <BookOpen className="h-6 w-6" />
              </div>
              <span className="text-2xl font-bold">中医学习平台</span>
            </div>
            
            <h1 className="text-3xl font-bold mb-4">
              {t('auth.welcome')}
            </h1>
            
            <p className="text-lg opacity-90 mb-8">
              传承千年中医智慧，开启您的专业学习之旅。与数万名学员一起探索传统医学的奥秘。
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/20">
                  <BookOpen className="h-4 w-4" />
                </div>
                <span>海量中医药知识库</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/20">
                  <Shield className="h-4 w-4" />
                </div>
                <span>专业权威的学习内容</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/20">
                  <LogIn className="h-4 w-4" />
                </div>
                <span>个性化学习进度跟踪</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="flex flex-col justify-center p-8 lg:p-12 bg-white lg:rounded-r-lg shadow-xl">
          <div className="w-full max-w-md mx-auto">
            {/* Mobile Header */}
            <div className="lg:hidden text-center mb-8">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
                  <BookOpen className="h-4 w-4" />
                </div>
                <span className="text-xl font-bold text-primary">中医学习平台</span>
              </div>
              <h1 className="text-2xl font-bold">{t('auth.welcome')}</h1>
            </div>

            <Card className="border-0 shadow-none lg:border lg:shadow-sm">
              <CardHeader className="space-y-1 pb-6">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">{t('auth.loginTitle')}</CardTitle>
                  <Button variant="ghost" size="sm" asChild>
                    <Link to="/">
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      返回首页
                    </Link>
                  </Button>
                </div>
                <CardDescription>
                  输入您的账号信息以登录系统
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-6">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  {/* Username/Email Field */}
                  <div className="space-y-2">
                    <Label htmlFor="username">{t('auth.username')}</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="username"
                        type="text"
                        placeholder="输入用户名或邮箱"
                        className="pl-10"
                        {...register('username')}
                        autoComplete="username"
                      />
                    </div>
                    {errors.username && (
                      <p className="text-sm text-destructive">{errors.username.message}</p>
                    )}
                  </div>

                  {/* Password Field */}
                  <div className="space-y-2">
                    <Label htmlFor="password">{t('auth.password')}</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="输入密码"
                        className="pl-10 pr-10"
                        {...register('password')}
                        autoComplete="current-password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    {errors.password && (
                      <p className="text-sm text-destructive">{errors.password.message}</p>
                    )}
                  </div>

                  {/* Captcha Field */}
                  <div className="space-y-2">
                    <Label htmlFor="captcha">{t('auth.captcha')}</Label>
                    <div className="flex gap-2">
                      <Input
                        id="captcha"
                        type="text"
                        placeholder="输入验证码"
                        className="flex-1"
                        {...register('captcha')}
                        autoComplete="off"
                      />
                      <div className="flex-shrink-0">
                        <img
                          src={captchaUrl}
                          alt="验证码"
                          className="h-10 w-24 border rounded cursor-pointer"
                          onClick={refreshCaptcha}
                          title="点击刷新验证码"
                        />
                      </div>
                    </div>
                    {errors.captcha && (
                      <p className="text-sm text-destructive">{errors.captcha.message}</p>
                    )}
                  </div>

                  {/* Remember Me & Forgot Password */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="remember"
                        checked={watch('remember')}
                        onCheckedChange={(checked) => setValue('remember', checked as boolean)}
                      />
                      <Label
                        htmlFor="remember"
                        className="text-sm font-normal cursor-pointer"
                      >
                        {t('auth.remember')}
                      </Label>
                    </div>
                    <Link
                      to="/forgot-password"
                      className="text-sm text-primary hover:underline"
                    >
                      {t('auth.forgotPassword')}
                    </Link>
                  </div>

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        登录中...
                      </>
                    ) : (
                      <>
                        <LogIn className="h-4 w-4 mr-2" />
                        {t('common.login')}
                      </>
                    )}
                  </Button>
                </form>

                {/* Register Link */}
                <div className="mt-6 text-center">
                  <p className="text-sm text-muted-foreground">
                    {t('auth.noAccount')}{' '}
                    <Link
                      to="/register"
                      className="text-primary hover:underline font-medium"
                    >
                      {t('auth.registerNow')}
                    </Link>
                  </p>
                </div>

                {/* Social Login - Optional */}
                <div className="mt-6">
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white px-2 text-muted-foreground">
                        或使用以下方式登录
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    <Button variant="outline" className="w-full" disabled>
                      微信登录
                    </Button>
                    <Button variant="outline" className="w-full" disabled>
                      手机登录
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
