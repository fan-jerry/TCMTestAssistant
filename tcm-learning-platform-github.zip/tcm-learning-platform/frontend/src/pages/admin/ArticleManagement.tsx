import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Trash2,
  Eye,
  Calendar,
  User,
  Tag,
  ChevronDown,
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  Globe,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

interface Article {
  id: number;
  title: string;
  summary: string;
  category: string;
  tags: string[];
  author: string;
  status: 'draft' | 'published' | 'archived';
  isPremium: boolean;
  viewCount: number;
  likeCount: number;
  commentCount: number;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
}

interface Category {
  id: number;
  name: string;
  description: string;
  parentId?: number;
  children?: Category[];
  articleCount: number;
  order: number;
}

const ArticleManagement: React.FC = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedArticles, setSelectedArticles] = useState<number[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  // 模拟数据
  const articles: Article[] = [
    {
      id: 1,
      title: '中医四诊：望闻问切的现代应用',
      summary: '深入解析中医四诊方法在现代临床中的应用与发展',
      category: '中医诊断',
      tags: ['四诊', '诊断学', '临床应用'],
      author: '张仲景',
      status: 'published',
      isPremium: false,
      viewCount: 12580,
      likeCount: 368,
      commentCount: 45,
      publishedAt: '2024-01-15T10:30:00Z',
      createdAt: '2024-01-14T08:00:00Z',
      updatedAt: '2024-01-15T10:30:00Z',
    },
    {
      id: 2,
      title: '针灸治疗失眠的临床研究',
      summary: '综述针灸治疗失眠的机理与临床疗效观察',
      category: '针灸学',
      tags: ['针灸', '失眠', '临床研究'],
      author: '皇甫谧',
      status: 'published',
      isPremium: true,
      viewCount: 8965,
      likeCount: 234,
      commentCount: 28,
      publishedAt: '2024-01-14T14:20:00Z',
      createdAt: '2024-01-13T16:00:00Z',
      updatedAt: '2024-01-14T14:20:00Z',
    },
    {
      id: 3,
      title: '中药配伍禁忌与现代药理学',
      summary: '从现代药理学角度分析中药配伍禁忌的科学依据',
      category: '中药学',
      tags: ['中药', '配伍', '药理学'],
      author: '李时珍',
      status: 'draft',
      isPremium: false,
      viewCount: 0,
      likeCount: 0,
      commentCount: 0,
      createdAt: '2024-01-13T16:45:00Z',
      updatedAt: '2024-01-13T18:20:00Z',
    },
    {
      id: 4,
      title: '中医养生保健的现代意义',
      summary: '探讨传统中医养生理念在现代生活中的应用价值',
      category: '养生保健',
      tags: ['养生', '保健', '现代应用'],
      author: '华佗',
      status: 'archived',
      isPremium: false,
      viewCount: 5420,
      likeCount: 156,
      commentCount: 18,
      publishedAt: '2023-12-20T09:15:00Z',
      createdAt: '2023-12-18T14:30:00Z',
      updatedAt: '2023-12-20T09:15:00Z',
    },
  ];

  const categories: Category[] = [
    {
      id: 1,
      name: '中医基础',
      description: '中医基础理论和概念',
      articleCount: 25,
      order: 1,
      children: [
        { id: 11, name: '阴阳五行', description: '阴阳学说与五行理论', parentId: 1, articleCount: 8, order: 1 },
        { id: 12, name: '脏腑学说', description: '五脏六腑理论', parentId: 1, articleCount: 12, order: 2 },
        { id: 13, name: '经络学说', description: '经络系统理论', parentId: 1, articleCount: 5, order: 3 },
      ]
    },
    {
      id: 2,
      name: '中药学',
      description: '中药材和方剂相关内容',
      articleCount: 35,
      order: 2,
      children: [
        { id: 21, name: '单味中药', description: '各类中药材介绍', parentId: 2, articleCount: 20, order: 1 },
        { id: 22, name: '方剂学', description: '经典方剂解析', parentId: 2, articleCount: 15, order: 2 },
      ]
    },
    {
      id: 3,
      name: '针灸学',
      description: '针灸理论与实践',
      articleCount: 18,
      order: 3,
    },
    {
      id: 4,
      name: '中医诊断',
      description: '中医诊断方法和技巧',
      articleCount: 22,
      order: 4,
    },
    {
      id: 5,
      name: '养生保健',
      description: '中医养生和保健知识',
      articleCount: 15,
      order: 5,
    },
  ];

  // 过滤和搜索逻辑
  const filteredArticles = useMemo(() => {
    return articles.filter(article => {
      const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           article.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           article.author.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
      const matchesStatus = selectedStatus === 'all' || article.status === selectedStatus;
      
      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [articles, searchQuery, selectedCategory, selectedStatus]);

  const paginatedArticles = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredArticles.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredArticles, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredArticles.length / itemsPerPage);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedArticles(paginatedArticles.map(article => article.id));
    } else {
      setSelectedArticles([]);
    }
  };

  const handleSelectArticle = (articleId: number, checked: boolean) => {
    if (checked) {
      setSelectedArticles(prev => [...prev, articleId]);
    } else {
      setSelectedArticles(prev => prev.filter(id => id !== articleId));
    }
  };

  const handleBatchAction = (action: string) => {
    const count = selectedArticles.length;
    toast({
      title: "批量操作",
      description: `已${action} ${count} 篇文章`,
    });
    setSelectedArticles([]);
  };

  const handleDeleteArticle = (articleId: number) => {
    toast({
      title: "删除成功",
      description: "文章已删除",
    });
  };

  const getStatusBadge = (status: Article['status']) => {
    switch (status) {
      case 'published':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">已发布</Badge>;
      case 'draft':
        return <Badge variant="secondary">草稿</Badge>;
      case 'archived':
        return <Badge variant="outline">已归档</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题和操作 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">CMS文章管理</h1>
          <p className="text-gray-600 mt-1">管理网站文章内容和发布</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" asChild>
            <Link to="/admin/articles/categories">
              <Tag className="w-4 h-4 mr-2" />
              分类管理
            </Link>
          </Button>
          <Button asChild>
            <Link to="/admin/articles/new">
              <Plus className="w-4 h-4 mr-2" />
              新建文章
            </Link>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="articles" className="w-full">
        <TabsList>
          <TabsTrigger value="articles">文章列表</TabsTrigger>
          <TabsTrigger value="categories">分类管理</TabsTrigger>
        </TabsList>

        <TabsContent value="articles" className="space-y-4">
          {/* 搜索和过滤 */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="搜索文章标题、摘要、作者..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="选择分类" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部分类</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.name}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="状态" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="published">已发布</SelectItem>
                    <SelectItem value="draft">草稿</SelectItem>
                    <SelectItem value="archived">已归档</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* 批量操作 */}
          {selectedArticles.length > 0 && (
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">
                    已选择 {selectedArticles.length} 篇文章
                  </span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleBatchAction('发布')}
                    >
                      批量发布
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleBatchAction('归档')}
                    >
                      批量归档
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleBatchAction('删除')}
                      className="text-red-600 hover:text-red-700"
                    >
                      批量删除
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* 文章列表 */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b bg-gray-50">
                    <tr>
                      <th className="text-left p-4 w-12">
                        <Checkbox
                          checked={paginatedArticles.length > 0 && selectedArticles.length === paginatedArticles.length}
                          onCheckedChange={handleSelectAll}
                        />
                      </th>
                      <th className="text-left p-4">文章信息</th>
                      <th className="text-left p-4">分类</th>
                      <th className="text-left p-4">作者</th>
                      <th className="text-left p-4">状态</th>
                      <th className="text-left p-4">数据</th>
                      <th className="text-left p-4">时间</th>
                      <th className="text-left p-4 w-20">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedArticles.map((article) => (
                      <tr key={article.id} className="border-b hover:bg-gray-50">
                        <td className="p-4">
                          <Checkbox
                            checked={selectedArticles.includes(article.id)}
                            onCheckedChange={(checked) => handleSelectArticle(article.id, checked as boolean)}
                          />
                        </td>
                        <td className="p-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium text-gray-900 line-clamp-1">
                                {article.title}
                              </h4>
                              {article.isPremium && (
                                <Badge variant="secondary" className="text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                                  VIP
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-600 line-clamp-2">
                              {article.summary}
                            </p>
                            <div className="flex flex-wrap gap-1">
                              {article.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge variant="outline">{article.category}</Badge>
                        </td>
                        <td className="p-4 text-sm text-gray-600">
                          {article.author}
                        </td>
                        <td className="p-4">
                          {getStatusBadge(article.status)}
                        </td>
                        <td className="p-4">
                          <div className="space-y-1 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Eye className="w-3 h-3" />
                              {article.viewCount.toLocaleString()}
                            </div>
                            <div className="flex items-center gap-4">
                              <span className="flex items-center gap-1">
                                <Globe className="w-3 h-3" />
                                {article.likeCount}
                              </span>
                              <span className="flex items-center gap-1">
                                <FileText className="w-3 h-3" />
                                {article.commentCount}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td className="p-4 text-sm text-gray-600">
                          <div className="space-y-1">
                            {article.publishedAt && (
                              <div className="flex items-center gap-1">
                                <CheckCircle className="w-3 h-3 text-green-500" />
                                {formatDate(article.publishedAt)}
                              </div>
                            )}
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {formatDate(article.updatedAt)}
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <Link to={`/admin/articles/${article.id}/edit`}>
                                  <Edit className="w-4 h-4 mr-2" />
                                  编辑
                                </Link>
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Eye className="w-4 h-4 mr-2" />
                                预览
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <DropdownMenuItem
                                    className="text-red-600 focus:text-red-600"
                                    onSelect={(e) => e.preventDefault()}
                                  >
                                    <Trash2 className="w-4 h-4 mr-2" />
                                    删除
                                  </DropdownMenuItem>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>确认删除</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      确定要删除文章《{article.title}》吗？此操作不可撤销。
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>取消</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDeleteArticle(article.id)}
                                      className="bg-red-600 hover:bg-red-700"
                                    >
                                      删除
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* 分页 */}
              {totalPages > 1 && (
                <div className="p-4 border-t">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">
                      显示 {(currentPage - 1) * itemsPerPage + 1} 到{' '}
                      {Math.min(currentPage * itemsPerPage, filteredArticles.length)} 条，
                      共 {filteredArticles.length} 条
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage(currentPage - 1)}
                      >
                        上一页
                      </Button>
                      <span className="text-sm">
                        {currentPage} / {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage(currentPage + 1)}
                      >
                        下一页
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          {/* 分类管理内容 */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>文章分类</CardTitle>
              <Button size="sm">
                <Plus className="w-4 h-4 mr-2" />
                新建分类
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {categories.map((category) => (
                  <div key={category.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <h4 className="font-medium">{category.name}</h4>
                        <Badge variant="outline">{category.articleCount} 篇文章</Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          编辑
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-600">
                          删除
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{category.description}</p>
                    
                    {category.children && category.children.length > 0 && (
                      <div className="ml-4 space-y-2">
                        {category.children.map((child) => (
                          <div key={child.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <div className="flex items-center gap-3">
                              <span className="text-sm">{child.name}</span>
                              <Badge variant="outline" className="text-xs">{child.articleCount} 篇</Badge>
                            </div>
                            <div className="flex items-center gap-1">
                              <Button variant="ghost" size="sm">
                                编辑
                              </Button>
                              <Button variant="ghost" size="sm" className="text-red-600">
                                删除
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ArticleManagement;
