import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Lock,
  Unlock,
  Trash2,
  UserPlus,
  Crown,
  Shield,
  Calendar,
  Mail,
  Phone,
  TrendingUp,
  Users,
  UserCheck,
  UserX,
  Eye,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { useToast } from '@/hooks/use-toast';

interface User {
  id: number;
  username: string;
  email: string;
  nickname: string;
  phone?: string;
  avatar?: string;
  status: 'active' | 'inactive' | 'banned';
  membership: 'FREE' | 'PREMIUM' | 'VIP';
  roles: string[];
  lastLoginAt?: string;
  createdAt: string;
  learningStats: {
    studyDays: number;
    completedCourses: number;
    testsPassed: number;
    totalScore: number;
  };
}

interface Role {
  id: number;
  name: string;
  description: string;
  permissions: string[];
  userCount: number;
}

const UserManagement: React.FC = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedMembership, setSelectedMembership] = useState('all');
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [showUserDialog, setShowUserDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  // 模拟数据
  const users: User[] = [
    {
      id: 1,
      username: 'zhangsan',
      email: 'zhangsan@example.com',
      nickname: '张三',
      phone: '13800138000',
      avatar: '/avatars/zhangsan.jpg',
      status: 'active',
      membership: 'VIP',
      roles: ['用户', 'VIP会员'],
      lastLoginAt: '2024-01-15T10:30:00Z',
      createdAt: '2023-06-15T08:00:00Z',
      learningStats: {
        studyDays: 120,
        completedCourses: 15,
        testsPassed: 48,
        totalScore: 4560,
      },
    },
    {
      id: 2,
      username: 'lisi',
      email: 'lisi@example.com',
      nickname: '李四',
      phone: '13900139000',
      status: 'active',
      membership: 'PREMIUM',
      roles: ['用户', '高级会员'],
      lastLoginAt: '2024-01-14T16:20:00Z',
      createdAt: '2023-08-20T14:30:00Z',
      learningStats: {
        studyDays: 85,
        completedCourses: 8,
        testsPassed: 25,
        totalScore: 2340,
      },
    },
    {
      id: 3,
      username: 'wangwu',
      email: 'wangwu@example.com',
      nickname: '王五',
      status: 'inactive',
      membership: 'FREE',
      roles: ['用户'],
      lastLoginAt: '2023-12-25T09:15:00Z',
      createdAt: '2023-03-10T12:45:00Z',
      learningStats: {
        studyDays: 25,
        completedCourses: 2,
        testsPassed: 8,
        totalScore: 560,
      },
    },
    {
      id: 4,
      username: 'admin',
      email: 'admin@example.com',
      nickname: '管理员',
      phone: '13700137000',
      status: 'active',
      membership: 'VIP',
      roles: ['管理员', 'VIP会员'],
      lastLoginAt: '2024-01-15T11:00:00Z',
      createdAt: '2023-01-01T00:00:00Z',
      learningStats: {
        studyDays: 365,
        completedCourses: 50,
        testsPassed: 150,
        totalScore: 15000,
      },
    },
    {
      id: 5,
      username: 'zhaoliu',
      email: 'zhaoliu@example.com',
      nickname: '赵六',
      status: 'banned',
      membership: 'FREE',
      roles: ['用户'],
      lastLoginAt: '2024-01-01T15:30:00Z',
      createdAt: '2023-11-05T10:20:00Z',
      learningStats: {
        studyDays: 10,
        completedCourses: 0,
        testsPassed: 2,
        totalScore: 120,
      },
    },
  ];

  const roles: Role[] = [
    {
      id: 1,
      name: '管理员',
      description: '系统管理员，拥有所有权限',
      permissions: ['用户管理', '内容管理', '系统设置', '数据管理'],
      userCount: 1,
    },
    {
      id: 2,
      name: '编辑',
      description: '内容编辑者，可以管理内容',
      permissions: ['内容管理', '文章发布'],
      userCount: 3,
    },
    {
      id: 3,
      name: 'VIP会员',
      description: '高级会员，享有所有学习权限',
      permissions: ['高级内容访问', '专属课程', '优先支持'],
      userCount: 156,
    },
    {
      id: 4,
      name: '高级会员',
      description: '付费会员，享有部分高级功能',
      permissions: ['部分高级内容', '课程下载'],
      userCount: 423,
    },
    {
      id: 5,
      name: '用户',
      description: '普通用户，基础学习权限',
      permissions: ['基础内容访问', '测试功能'],
      userCount: 12000,
    },
  ];

  // 用户增长数据
  const userGrowthData = [
    { name: '1月', newUsers: 245, totalUsers: 8456 },
    { name: '2月', newUsers: 312, totalUsers: 8768 },
    { name: '3月', newUsers: 425, totalUsers: 9193 },
    { name: '4月', newUsers: 567, totalUsers: 9760 },
    { name: '5月', newUsers: 689, totalUsers: 10449 },
    { name: '6月', newUsers: 756, totalUsers: 11205 },
    { name: '7月', newUsers: 834, totalUsers: 12039 },
    { name: '8月', newUsers: 912, totalUsers: 12951 },
  ];

  // 会员分布数据
  const membershipData = [
    { name: '免费用户', value: 70, count: 8820 },
    { name: '高级会员', value: 25, count: 3150 },
    { name: 'VIP会员', value: 5, count: 630 },
  ];

  const COLORS = ['#8884d8', '#82ca9d', '#ffc658'];

  // 过滤和搜索逻辑
  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const matchesSearch = user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           user.nickname.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = selectedStatus === 'all' || user.status === selectedStatus;
      const matchesMembership = selectedMembership === 'all' || user.membership === selectedMembership;
      
      return matchesSearch && matchesStatus && matchesMembership;
    });
  }, [users, searchQuery, selectedStatus, selectedMembership]);

  const paginatedUsers = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredUsers.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredUsers, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedUsers(paginatedUsers.map(user => user.id));
    } else {
      setSelectedUsers([]);
    }
  };

  const handleSelectUser = (userId: number, checked: boolean) => {
    if (checked) {
      setSelectedUsers(prev => [...prev, userId]);
    } else {
      setSelectedUsers(prev => prev.filter(id => id !== userId));
    }
  };

  const handleBatchAction = (action: string) => {
    const count = selectedUsers.length;
    toast({
      title: "批量操作",
      description: `已${action} ${count} 个用户`,
    });
    setSelectedUsers([]);
  };

  const handleUserAction = (userId: number, action: string) => {
    const user = users.find(u => u.id === userId);
    toast({
      title: "操作成功",
      description: `已${action}用户 ${user?.nickname}`,
    });
  };

  const getStatusBadge = (status: User['status']) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">活跃</Badge>;
      case 'inactive':
        return <Badge variant="secondary">不活跃</Badge>;
      case 'banned':
        return <Badge variant="destructive">已封禁</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getMembershipBadge = (membership: User['membership']) => {
    switch (membership) {
      case 'VIP':
        return <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">VIP</Badge>;
      case 'PREMIUM':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">高级会员</Badge>;
      case 'FREE':
        return <Badge variant="outline">免费用户</Badge>;
      default:
        return <Badge variant="secondary">{membership}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getTotalStats = () => {
    const total = users.length;
    const active = users.filter(u => u.status === 'active').length;
    const vip = users.filter(u => u.membership === 'VIP').length;
    const premium = users.filter(u => u.membership === 'PREMIUM').length;

    return { total, active, vip, premium };
  };

  const stats = getTotalStats();

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">用户管理</h1>
          <p className="text-gray-600 mt-1">管理系统用户和权限</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" asChild>
            <span>
              <Shield className="w-4 h-4 mr-2" />
              角色管理
            </span>
          </Button>
          <Button>
            <UserPlus className="w-4 h-4 mr-2" />
            新增用户
          </Button>
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">总用户数</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">活跃用户</p>
                <p className="text-2xl font-bold">{stats.active}</p>
              </div>
              <UserCheck className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">VIP用户</p>
                <p className="text-2xl font-bold">{stats.vip}</p>
              </div>
              <Crown className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">付费用户</p>
                <p className="text-2xl font-bold">{stats.premium + stats.vip}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="users" className="w-full">
        <TabsList>
          <TabsTrigger value="users">用户列表</TabsTrigger>
          <TabsTrigger value="roles">角色权限</TabsTrigger>
          <TabsTrigger value="statistics">用户统计</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          {/* 搜索和过滤 */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="搜索用户名、邮箱、昵称..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="状态" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="active">活跃</SelectItem>
                    <SelectItem value="inactive">不活跃</SelectItem>
                    <SelectItem value="banned">已封禁</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedMembership} onValueChange={setSelectedMembership}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="会员类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部类型</SelectItem>
                    <SelectItem value="VIP">VIP</SelectItem>
                    <SelectItem value="PREMIUM">高级会员</SelectItem>
                    <SelectItem value="FREE">免费用户</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* 批量操作 */}
          {selectedUsers.length > 0 && (
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">
                    已选择 {selectedUsers.length} 个用户
                  </span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleBatchAction('启用')}
                    >
                      批量启用
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleBatchAction('禁用')}
                    >
                      批量禁用
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleBatchAction('删除')}
                      className="text-red-600 hover:text-red-700"
                    >
                      批量删除
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* 用户列表 */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b bg-gray-50">
                    <tr>
                      <th className="text-left p-4 w-12">
                        <Checkbox
                          checked={paginatedUsers.length > 0 && selectedUsers.length === paginatedUsers.length}
                          onCheckedChange={handleSelectAll}
                        />
                      </th>
                      <th className="text-left p-4">用户信息</th>
                      <th className="text-left p-4">会员类型</th>
                      <th className="text-left p-4">状态</th>
                      <th className="text-left p-4">学习统计</th>
                      <th className="text-left p-4">注册时间</th>
                      <th className="text-left p-4">最后登录</th>
                      <th className="text-left p-4 w-20">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedUsers.map((user) => (
                      <tr key={user.id} className="border-b hover:bg-gray-50">
                        <td className="p-4">
                          <Checkbox
                            checked={selectedUsers.includes(user.id)}
                            onCheckedChange={(checked) => handleSelectUser(user.id, checked as boolean)}
                          />
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={user.avatar} alt={user.nickname} />
                              <AvatarFallback>{user.nickname.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{user.nickname}</div>
                              <div className="text-sm text-gray-500">{user.username}</div>
                              <div className="flex items-center gap-2 text-xs text-gray-400">
                                <Mail className="w-3 h-3" />
                                {user.email}
                                {user.phone && (
                                  <>
                                    <Phone className="w-3 h-3 ml-2" />
                                    {user.phone}
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          {getMembershipBadge(user.membership)}
                        </td>
                        <td className="p-4">
                          {getStatusBadge(user.status)}
                        </td>
                        <td className="p-4">
                          <div className="space-y-1 text-sm">
                            <div>学习 {user.learningStats.studyDays} 天</div>
                            <div>完成 {user.learningStats.completedCourses} 课程</div>
                            <div>通过 {user.learningStats.testsPassed} 测试</div>
                            <div>总分 {user.learningStats.totalScore}</div>
                          </div>
                        </td>
                        <td className="p-4 text-sm text-gray-600">
                          {formatDate(user.createdAt)}
                        </td>
                        <td className="p-4 text-sm text-gray-600">
                          {user.lastLoginAt ? formatDate(user.lastLoginAt) : '从未登录'}
                        </td>
                        <td className="p-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem 
                                onClick={() => {
                                  setSelectedUser(user);
                                  setShowUserDialog(true);
                                }}
                              >
                                <Eye className="w-4 h-4 mr-2" />
                                查看详情
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                编辑用户
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                {user.status === 'active' ? (
                                  <>
                                    <Lock className="w-4 h-4 mr-2" />
                                    禁用用户
                                  </>
                                ) : (
                                  <>
                                    <Unlock className="w-4 h-4 mr-2" />
                                    启用用户
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <DropdownMenuItem
                                    className="text-red-600 focus:text-red-600"
                                    onSelect={(e) => e.preventDefault()}
                                  >
                                    <Trash2 className="w-4 h-4 mr-2" />
                                    删除用户
                                  </DropdownMenuItem>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>确认删除</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      确定要删除用户 {user.nickname} 吗？此操作不可撤销。
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>取消</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleUserAction(user.id, '删除')}
                                      className="bg-red-600 hover:bg-red-700"
                                    >
                                      删除
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* 分页 */}
              {totalPages > 1 && (
                <div className="p-4 border-t">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">
                      显示 {(currentPage - 1) * itemsPerPage + 1} 到{' '}
                      {Math.min(currentPage * itemsPerPage, filteredUsers.length)} 条，
                      共 {filteredUsers.length} 条
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage(currentPage - 1)}
                      >
                        上一页
                      </Button>
                      <span className="text-sm">
                        {currentPage} / {totalPages}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage(currentPage + 1)}
                      >
                        下一页
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>角色权限管理</CardTitle>
              <Button size="sm">
                <UserPlus className="w-4 h-4 mr-2" />
                新建角色
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {roles.map((role) => (
                  <div key={role.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <h4 className="font-medium text-lg">{role.name}</h4>
                        <Badge variant="outline">{role.userCount} 用户</Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          编辑
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-600">
                          删除
                        </Button>
                      </div>
                    </div>
                    <p className="text-gray-600 mb-3">{role.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {role.permissions.map((permission) => (
                        <Badge key={permission} variant="secondary" className="text-xs">
                          {permission}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="statistics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 用户增长趋势 */}
            <Card>
              <CardHeader>
                <CardTitle>用户增长趋势</CardTitle>
                <CardDescription>过去8个月的用户增长情况</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={userGrowthData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="newUsers" 
                      stroke="#8884d8" 
                      strokeWidth={2} 
                      name="新增用户" 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="totalUsers" 
                      stroke="#82ca9d" 
                      strokeWidth={2} 
                      name="总用户数" 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* 会员分布 */}
            <Card>
              <CardHeader>
                <CardTitle>会员分布</CardTitle>
                <CardDescription>不同会员类型的用户分布</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={membershipData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {membershipData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* 月度新增用户 */}
          <Card>
            <CardHeader>
              <CardTitle>月度新增用户</CardTitle>
              <CardDescription>每月新注册用户数量统计</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={userGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="newUsers" fill="#8884d8" name="新增用户" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 用户详情对话框 */}
      <Dialog open={showUserDialog} onOpenChange={setShowUserDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>用户详情</DialogTitle>
            <DialogDescription>
              查看用户的详细信息和学习统计
            </DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={selectedUser.avatar} alt={selectedUser.nickname} />
                  <AvatarFallback className="text-lg">{selectedUser.nickname.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-lg font-semibold">{selectedUser.nickname}</h3>
                  <p className="text-gray-600">@{selectedUser.username}</p>
                  <div className="flex items-center gap-2 mt-2">
                    {getMembershipBadge(selectedUser.membership)}
                    {getStatusBadge(selectedUser.status)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">邮箱</Label>
                  <p className="text-sm text-gray-600">{selectedUser.email}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">手机</Label>
                  <p className="text-sm text-gray-600">{selectedUser.phone || '未填写'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">注册时间</Label>
                  <p className="text-sm text-gray-600">{formatDate(selectedUser.createdAt)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">最后登录</Label>
                  <p className="text-sm text-gray-600">
                    {selectedUser.lastLoginAt ? formatDate(selectedUser.lastLoginAt) : '从未登录'}
                  </p>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium mb-3 block">学习统计</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{selectedUser.learningStats.studyDays}</div>
                    <div className="text-sm text-gray-600">学习天数</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{selectedUser.learningStats.completedCourses}</div>
                    <div className="text-sm text-gray-600">完成课程</div>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{selectedUser.learningStats.testsPassed}</div>
                    <div className="text-sm text-gray-600">通过测试</div>
                  </div>
                  <div className="text-center p-3 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{selectedUser.learningStats.totalScore}</div>
                    <div className="text-sm text-gray-600">总分</div>
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">用户角色</Label>
                <div className="flex flex-wrap gap-2">
                  {selectedUser.roles.map((role) => (
                    <Badge key={role} variant="outline">
                      {role}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUserDialog(false)}>
              关闭
            </Button>
            <Button>
              编辑用户
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UserManagement;
