import React from 'react';
import { Link } from 'react-router-dom';
import {
  Users,
  FileText,
  BookOpen,
  Target,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Activity,
  Eye,
  Heart,
  MessageSquare,
  Download,
  Plus,
  ArrowUpRight,
  Calendar,
  Clock,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

const AdminDashboard: React.FC = () => {
  // 模拟数据
  const stats = {
    totalUsers: 12580,
    activeUsers: 3240,
    totalArticles: 156,
    totalViews: 89650,
    revenue: 25400,
    revenueGrowth: 12.5,
    userGrowth: 8.3,
    articleGrowth: 15.2,
    viewGrowth: 23.1,
  };

  const userGrowthData = [
    { name: '1月', users: 2400, active: 800 },
    { name: '2月', users: 3200, active: 1200 },
    { name: '3月', users: 4100, active: 1800 },
    { name: '4月', users: 5300, active: 2100 },
    { name: '5月', users: 6800, active: 2800 },
    { name: '6月', users: 8900, active: 3240 },
  ];

  const contentData = [
    { name: '中医理论', value: 45, count: 45 },
    { name: '中药材', value: 30, count: 30 },
    { name: '方剂', value: 25, count: 25 },
    { name: '针灸', value: 35, count: 35 },
    { name: '养生', value: 21, count: 21 },
  ];

  const revenueData = [
    { name: '1月', revenue: 8500, orders: 45 },
    { name: '2月', revenue: 12300, orders: 67 },
    { name: '3月', revenue: 15600, orders: 89 },
    { name: '4月', revenue: 18900, orders: 102 },
    { name: '5月', revenue: 22100, orders: 115 },
    { name: '6月', revenue: 25400, orders: 128 },
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  const recentArticles = [
    {
      id: 1,
      title: '中医四诊：望闻问切的现代应用',
      author: '张仲景',
      views: 1250,
      likes: 89,
      publishedAt: '2024-01-15',
      status: 'published'
    },
    {
      id: 2,
      title: '针灸治疗失眠的临床研究',
      author: '皇甫谧',
      views: 980,
      likes: 67,
      publishedAt: '2024-01-14',
      status: 'published'
    },
    {
      id: 3,
      title: '中药配伍禁忌与现代药理学',
      author: '李时珍',
      views: 1420,
      likes: 102,
      publishedAt: '2024-01-13',
      status: 'draft'
    },
  ];

  const quickActions = [
    {
      title: '发布文章',
      description: '快速发布新的CMS文章',
      icon: FileText,
      action: '/admin/articles/new',
      color: 'bg-blue-500'
    },
    {
      title: '导入数据',
      description: '批量导入中医数据',
      icon: Download,
      action: '/admin/data/import',
      color: 'bg-green-500'
    },
    {
      title: '用户管理',
      description: '管理系统用户',
      icon: Users,
      action: '/admin/users',
      color: 'bg-purple-500'
    },
    {
      title: '系统设置',
      description: '配置系统参数',
      icon: Target,
      action: '/admin/settings',
      color: 'bg-orange-500'
    },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">管理仪表盘</h1>
          <p className="text-gray-600 mt-1">中医学习平台数据概览</p>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Calendar className="w-4 h-4" />
          {new Date().toLocaleDateString('zh-CN', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })}
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">总用户数</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 mr-1 text-green-500" />
              +{stats.userGrowth}% 较上月
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">活跃用户</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeUsers.toLocaleString()}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 mr-1 text-green-500" />
              +{stats.userGrowth}% 较上月
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">文章总数</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalArticles}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 mr-1 text-green-500" />
              +{stats.articleGrowth}% 较上月
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">总浏览量</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalViews.toLocaleString()}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 mr-1 text-green-500" />
              +{stats.viewGrowth}% 较上月
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 用户增长趋势 */}
        <Card>
          <CardHeader>
            <CardTitle>用户增长趋势</CardTitle>
            <CardDescription>过去6个月的用户增长情况</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={userGrowthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="users" stackId="1" stroke="#8884d8" fill="#8884d8" name="总用户" />
                <Area type="monotone" dataKey="active" stackId="1" stroke="#82ca9d" fill="#82ca9d" name="活跃用户" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 内容分布 */}
        <Card>
          <CardHeader>
            <CardTitle>内容分布</CardTitle>
            <CardDescription>各类别内容数量分布</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={contentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {contentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 最近文章 */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>最近文章</CardTitle>
              <CardDescription>最新发布和编辑的文章</CardDescription>
            </div>
            <Link to="/admin/articles">
              <Button variant="outline" size="sm">
                查看全部
                <ArrowUpRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentArticles.map((article) => (
                <div key={article.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-medium">{article.title}</h4>
                      <Badge variant={article.status === 'published' ? 'default' : 'secondary'}>
                        {article.status === 'published' ? '已发布' : '草稿'}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>作者: {article.author}</span>
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {article.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <Heart className="w-3 h-3" />
                        {article.likes}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {article.publishedAt}
                      </span>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    编辑
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 快捷操作 */}
        <Card>
          <CardHeader>
            <CardTitle>快捷操作</CardTitle>
            <CardDescription>常用功能快速入口</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Link key={index} to={action.action}>
                    <div className="flex items-center gap-3 p-3 border rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                      <div className={`w-10 h-10 rounded-lg ${action.color} flex items-center justify-center`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">{action.title}</div>
                        <div className="text-sm text-gray-500">{action.description}</div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 收益趋势 */}
      <Card>
        <CardHeader>
          <CardTitle>收益趋势</CardTitle>
          <CardDescription>过去6个月的收益变化</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="revenue" stroke="#8884d8" strokeWidth={2} name="收益 (元)" />
              <Line type="monotone" dataKey="orders" stroke="#82ca9d" strokeWidth={2} name="订单数" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;
