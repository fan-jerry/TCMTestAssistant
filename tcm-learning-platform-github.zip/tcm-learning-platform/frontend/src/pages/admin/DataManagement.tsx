import React, { useState, useCallback } from 'react';
import {
  Upload,
  Download,
  FileSpreadsheet,
  FileText,
  Database,
  AlertCircle,
  CheckCircle,
  XCircle,
  BarChart3,
  RefreshCw,
  FileType,
  Trash2,
  Eye,
  Calendar,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import * as XLSX from 'xlsx';

interface ImportRecord {
  id: number;
  fileName: string;
  fileType: string;
  fileSize: number;
  status: 'processing' | 'completed' | 'failed';
  progress: number;
  totalRecords: number;
  successCount: number;
  errorCount: number;
  errors: string[];
  importedAt: string;
  dataType: string;
}

interface ExportTemplate {
  id: number;
  name: string;
  description: string;
  dataType: string;
  fields: string[];
  sampleData: any[];
}

interface DataStatistics {
  herbs: number;
  formulas: number;
  acupoints: number;
  questions: number;
  articles: number;
  users: number;
}

const DataManagement: React.FC = () => {
  const { toast } = useToast();
  const [dragActive, setDragActive] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [isImporting, setIsImporting] = useState(false);
  const [selectedDataType, setSelectedDataType] = useState('herbs');
  const [importedData, setImportedData] = useState<any[]>([]);
  const [previewDialog, setPreviewDialog] = useState(false);

  // 模拟数据
  const importRecords: ImportRecord[] = [
    {
      id: 1,
      fileName: 'herbs_data.xlsx',
      fileType: 'Excel',
      fileSize: 2547892,
      status: 'completed',
      progress: 100,
      totalRecords: 580,
      successCount: 575,
      errorCount: 5,
      errors: ['第23行：药材名称不能为空', '第45行：性味格式错误'],
      importedAt: '2024-01-15T10:30:00Z',
      dataType: '中药材',
    },
    {
      id: 2,
      fileName: 'formulas_data.json',
      fileType: 'JSON',
      fileSize: 1234567,
      status: 'completed',
      progress: 100,
      totalRecords: 120,
      successCount: 118,
      errorCount: 2,
      errors: ['方剂组成格式错误'],
      importedAt: '2024-01-14T14:20:00Z',
      dataType: '方剂',
    },
    {
      id: 3,
      fileName: 'acupoints_import.xlsx',
      fileType: 'Excel',
      fileSize: 987654,
      status: 'failed',
      progress: 45,
      totalRecords: 200,
      successCount: 89,
      errorCount: 111,
      errors: ['文件格式不匹配', '必填字段缺失'],
      importedAt: '2024-01-13T16:45:00Z',
      dataType: '穴位',
    },
  ];

  const exportTemplates: ExportTemplate[] = [
    {
      id: 1,
      name: '中药材导入模板',
      description: '用于批量导入中药材数据的Excel模板',
      dataType: 'herbs',
      fields: ['名称', '拼音', '英文名', '分类', '性味', '归经', '功效', '主治', '用法用量'],
      sampleData: [
        { '名称': '人参', '拼音': 'rén shēn', '英文名': 'Ginseng', '分类': '补气药', '性味': '甘、微苦，微温', '归经': '脾、肺、心、肾经', '功效': '大补元气，复脉固脱', '主治': '气虚欲脱，脾虚食少', '用法用量': '3-9g' },
        { '名称': '当归', '拼音': 'dāng guī', '英文名': 'Angelica Sinensis', '分类': '补血药', '性味': '甘、辛，温', '归经': '肝、心、脾经', '功效': '补血活血，调经止痛', '主治': '血虚萎黄，月经不调', '用法用量': '6-12g' },
      ]
    },
    {
      id: 2,
      name: '方剂导入模板',
      description: '用于批量导入方剂数据的Excel模板',
      dataType: 'formulas',
      fields: ['方剂名', '拼音', '英文名', '分类', '出处', '组成', '功效', '主治', '用法'],
      sampleData: [
        { '方剂名': '桂枝汤', '拼音': 'guì zhī tāng', '英文名': 'Cinnamon Twig Decoction', '分类': '解表剂', '出处': '《伤寒论》', '组成': '桂枝9g,白芍9g,生姜9g,大枣12枚,炙甘草6g', '功效': '解肌发表，调和营卫', '主治': '外感风寒表虚证', '用法': '水煎服' },
      ]
    },
    {
      id: 3,
      name: '穴位导入模板',
      description: '用于批量导入穴位数据的Excel模板',
      dataType: 'acupoints',
      fields: ['穴位名', '拼音', '英文名', '编码', '所属经络', '定位', '功效', '主治', '操作'],
      sampleData: [
        { '穴位名': '百会', '拼音': 'bǎi huì', '英文名': 'Baihui', '编码': 'GV20', '所属经络': '督脉', '定位': '头部，前发际正中直上7寸', '功效': '升阳举陷，益气固脱', '主治': '头痛，眩晕，脱肛', '操作': '平刺0.5-0.8寸' },
      ]
    },
  ];

  const dataStatistics: DataStatistics = {
    herbs: 580,
    formulas: 118,
    acupoints: 89,
    questions: 555,
    articles: 156,
    users: 12580,
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileUpload = async (file: File) => {
    if (!file) return;

    const fileType = file.name.split('.').pop()?.toLowerCase();
    if (!['xlsx', 'xls', 'json', 'csv'].includes(fileType || '')) {
      toast({
        variant: "destructive",
        title: "文件格式错误",
        description: "请上传 Excel (.xlsx, .xls)、JSON 或 CSV 格式的文件",
      });
      return;
    }

    setIsImporting(true);
    setImportProgress(0);

    try {
      let data: any[] = [];

      if (fileType === 'json') {
        const text = await file.text();
        data = JSON.parse(text);
      } else if (['xlsx', 'xls', 'csv'].includes(fileType)) {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        data = XLSX.utils.sheet_to_json(worksheet);
      }

      setImportedData(data);

      // 模拟导入进度
      for (let i = 0; i <= 100; i += 10) {
        await new Promise(resolve => setTimeout(resolve, 100));
        setImportProgress(i);
      }

      toast({
        title: "导入成功",
        description: `成功导入 ${data.length} 条记录`,
      });

      setPreviewDialog(true);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "导入失败",
        description: "文件解析错误，请检查文件格式",
      });
    } finally {
      setIsImporting(false);
      setImportProgress(0);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0]);
    }
  };

  const downloadTemplate = (template: ExportTemplate) => {
    const ws = XLSX.utils.json_to_sheet(template.sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "数据模板");
    XLSX.writeFile(wb, `${template.name}.xlsx`);
    
    toast({
      title: "下载成功",
      description: `${template.name} 已下载`,
    });
  };

  const exportData = (dataType: string, format: string) => {
    // 模拟导出功能
    const fileName = `${dataType}_export_${new Date().toISOString().split('T')[0]}.${format}`;
    
    toast({
      title: "导出成功",
      description: `数据已导出为 ${fileName}`,
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusBadge = (status: ImportRecord['status']) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">完成</Badge>;
      case 'processing':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">处理中</Badge>;
      case 'failed':
        return <Badge variant="destructive">失败</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-3xl font-bold">数据管理</h1>
        <p className="text-gray-600 mt-1">数据导入导出和批量管理</p>
      </div>

      {/* 数据统计 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">中药材</p>
                <p className="text-2xl font-bold">{dataStatistics.herbs}</p>
              </div>
              <Database className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">方剂</p>
                <p className="text-2xl font-bold">{dataStatistics.formulas}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">穴位</p>
                <p className="text-2xl font-bold">{dataStatistics.acupoints}</p>
              </div>
              <Database className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">题目</p>
                <p className="text-2xl font-bold">{dataStatistics.questions}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">文章</p>
                <p className="text-2xl font-bold">{dataStatistics.articles}</p>
              </div>
              <FileText className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">用户</p>
                <p className="text-2xl font-bold">{dataStatistics.users}</p>
              </div>
              <Database className="h-8 w-8 text-indigo-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="import" className="w-full">
        <TabsList>
          <TabsTrigger value="import">数据导入</TabsTrigger>
          <TabsTrigger value="export">数据导出</TabsTrigger>
          <TabsTrigger value="templates">导入模板</TabsTrigger>
          <TabsTrigger value="history">操作记录</TabsTrigger>
        </TabsList>

        <TabsContent value="import" className="space-y-6">
          {/* 文件上传区域 */}
          <Card>
            <CardHeader>
              <CardTitle>批量导入数据</CardTitle>
              <CardDescription>
                支持 Excel (.xlsx, .xls)、JSON 和 CSV 格式文件
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Select value={selectedDataType} onValueChange={setSelectedDataType}>
                  <SelectTrigger className="w-64">
                    <SelectValue placeholder="选择数据类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="herbs">中药材</SelectItem>
                    <SelectItem value="formulas">方剂</SelectItem>
                    <SelectItem value="acupoints">穴位</SelectItem>
                    <SelectItem value="questions">题目</SelectItem>
                    <SelectItem value="articles">文章</SelectItem>
                  </SelectContent>
                </Select>

                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    dragActive ? 'border-primary bg-primary/5' : 'border-gray-300'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <div className="space-y-2">
                    <p className="text-lg font-medium">拖拽文件到此处或点击上传</p>
                    <p className="text-sm text-gray-500">
                      支持 .xlsx, .xls, .json, .csv 格式，最大 10MB
                    </p>
                  </div>
                  <input
                    type="file"
                    accept=".xlsx,.xls,.json,.csv"
                    onChange={handleFileInputChange}
                    className="hidden"
                    id="fileInput"
                  />
                  <label htmlFor="fileInput" className="cursor-pointer">
                    <Button className="mt-4">
                      选择文件
                    </Button>
                  </label>
                </div>

                {isImporting && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>导入进度</span>
                      <span>{importProgress}%</span>
                    </div>
                    <Progress value={importProgress} className="w-full" />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* 导入注意事项 */}
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>导入注意事项</AlertTitle>
            <AlertDescription className="mt-2 space-y-1">
              <p>• 请确保数据格式与模板一致</p>
              <p>• 必填字段不能为空</p>
              <p>• 建议先下载导入模板进行数据整理</p>
              <p>• 导入前请备份现有数据</p>
            </AlertDescription>
          </Alert>
        </TabsContent>

        <TabsContent value="export" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>数据导出</CardTitle>
              <CardDescription>
                导出系统中的数据，支持多种格式
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">数据类型</label>
                    <Select defaultValue="herbs">
                      <SelectTrigger>
                        <SelectValue placeholder="选择数据类型" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="herbs">中药材</SelectItem>
                        <SelectItem value="formulas">方剂</SelectItem>
                        <SelectItem value="acupoints">穴位</SelectItem>
                        <SelectItem value="questions">题目</SelectItem>
                        <SelectItem value="articles">文章</SelectItem>
                        <SelectItem value="users">用户</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">导出格式</label>
                    <div className="grid grid-cols-3 gap-2">
                      <Button
                        variant="outline"
                        onClick={() => exportData('herbs', 'xlsx')}
                        className="flex flex-col items-center gap-2 h-20"
                      >
                        <FileSpreadsheet className="h-6 w-6" />
                        <span className="text-xs">Excel</span>
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => exportData('herbs', 'json')}
                        className="flex flex-col items-center gap-2 h-20"
                      >
                        <FileType className="h-6 w-6" />
                        <span className="text-xs">JSON</span>
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => exportData('herbs', 'csv')}
                        className="flex flex-col items-center gap-2 h-20"
                      >
                        <FileText className="h-6 w-6" />
                        <span className="text-xs">CSV</span>
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">导出字段</label>
                    <div className="space-y-2 max-h-40 overflow-y-auto border rounded-lg p-3">
                      {['名称', '分类', '性味', '归经', '功效', '主治', '用法用量', '注意事项'].map((field) => (
                        <div key={field} className="flex items-center space-x-2">
                          <Checkbox id={field} defaultChecked />
                          <label htmlFor={field} className="text-sm">{field}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {exportTemplates.map((template) => (
              <Card key={template.id}>
                <CardHeader>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium mb-2">包含字段：</p>
                      <div className="flex flex-wrap gap-1">
                        {template.fields.slice(0, 4).map((field) => (
                          <Badge key={field} variant="outline" className="text-xs">
                            {field}
                          </Badge>
                        ))}
                        {template.fields.length > 4 && (
                          <Badge variant="outline" className="text-xs">
                            +{template.fields.length - 4}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => downloadTemplate(template)}
                      className="w-full"
                      size="sm"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      下载模板
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>导入记录</CardTitle>
              <CardDescription>查看数据导入的历史记录和状态</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {importRecords.map((record) => (
                  <div key={record.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <FileSpreadsheet className="h-5 w-5 text-gray-400" />
                        <div>
                          <h4 className="font-medium">{record.fileName}</h4>
                          <p className="text-sm text-gray-500">
                            {record.dataType} • {formatFileSize(record.fileSize)}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(record.status)}
                        <span className="text-sm text-gray-500">
                          {formatDate(record.importedAt)}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                      <div className="text-center p-3 bg-gray-50 rounded">
                        <p className="text-2xl font-bold text-blue-600">{record.totalRecords}</p>
                        <p className="text-sm text-gray-600">总记录数</p>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded">
                        <p className="text-2xl font-bold text-green-600">{record.successCount}</p>
                        <p className="text-sm text-gray-600">成功导入</p>
                      </div>
                      <div className="text-center p-3 bg-red-50 rounded">
                        <p className="text-2xl font-bold text-red-600">{record.errorCount}</p>
                        <p className="text-sm text-gray-600">导入失败</p>
                      </div>
                    </div>

                    {record.status === 'processing' && (
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>处理进度</span>
                          <span>{record.progress}%</span>
                        </div>
                        <Progress value={record.progress} className="w-full" />
                      </div>
                    )}

                    {record.errors.length > 0 && (
                      <div className="mt-3">
                        <p className="text-sm font-medium text-red-600 mb-2">错误信息：</p>
                        <div className="space-y-1">
                          {record.errors.slice(0, 3).map((error, index) => (
                            <p key={index} className="text-sm text-red-600 bg-red-50 p-2 rounded">
                              {error}
                            </p>
                          ))}
                          {record.errors.length > 3 && (
                            <p className="text-sm text-gray-500">
                              还有 {record.errors.length - 3} 个错误...
                            </p>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-2 mt-3">
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-2" />
                        查看详情
                      </Button>
                      {record.status === 'failed' && (
                        <Button variant="outline" size="sm">
                          <RefreshCw className="w-4 h-4 mr-2" />
                          重新导入
                        </Button>
                      )}
                      <Button variant="outline" size="sm" className="text-red-600">
                        <Trash2 className="w-4 h-4 mr-2" />
                        删除记录
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* 数据预览对话框 */}
      <Dialog open={previewDialog} onOpenChange={setPreviewDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>数据预览</DialogTitle>
            <DialogDescription>
              预览导入的数据，确认无误后可提交导入
            </DialogDescription>
          </DialogHeader>
          <div className="overflow-auto max-h-96">
            {importedData.length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-gray-50">
                      {Object.keys(importedData[0]).map((key) => (
                        <th key={key} className="border border-gray-300 p-2 text-left text-sm font-medium">
                          {key}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {importedData.slice(0, 10).map((row, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        {Object.values(row).map((value, cellIndex) => (
                          <td key={cellIndex} className="border border-gray-300 p-2 text-sm">
                            {String(value)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
                {importedData.length > 10 && (
                  <p className="text-center text-sm text-gray-500 mt-2">
                    还有 {importedData.length - 10} 条记录未显示...
                  </p>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreviewDialog(false)}>
              取消
            </Button>
            <Button onClick={() => {
              setPreviewDialog(false);
              toast({
                title: "导入完成",
                description: `成功导入 ${importedData.length} 条记录到${selectedDataType}`,
              });
            }}>
              确认导入
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DataManagement;
