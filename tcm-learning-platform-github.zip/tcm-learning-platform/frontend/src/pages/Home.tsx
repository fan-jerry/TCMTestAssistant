import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Search,
  Book,
  MapPin,
  GraduationCap,
  TrendingUp,
  Users,
  Clock,
  Award,
  ChevronRight,
  Pill,
  FlaskConical,
  Target,
  BookOpen,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';

const Home: React.FC = () => {
  const { t } = useTranslation();

  // 轮播图数据
  const heroSlides = [
    {
      id: 1,
      title: '传承千年智慧，学习中医精髓',
      subtitle: '专业的中医学习平台，助您深入理解中医药文化',
      image: 'bg-gradient-to-r from-green-600 to-emerald-600',
      cta: '开始学习',
      link: '/herbs',
    },
    {
      id: 2,
      title: '中药材数据库',
      subtitle: '收录数千种中药材，详细的功效主治和临床应用',
      image: 'bg-gradient-to-r from-blue-600 to-cyan-600',
      cta: '查看中药',
      link: '/herbs',
    },
    {
      id: 3,
      title: '经典方剂大全',
      subtitle: '汇集历代名方，传统配伍与现代应用相结合',
      image: 'bg-gradient-to-r from-purple-600 to-pink-600',
      cta: '查看方剂',
      link: '/formulas',
    },
  ];

  // 特色功能
  const featuredSections = [
    {
      key: 'herbs',
      title: t('home.featuredSections.herbs.title'),
      description: t('home.featuredSections.herbs.description'),
      icon: Pill,
      link: '/herbs',
      color: 'bg-green-500',
      stats: '5000+ 中药材',
    },
    {
      key: 'formulas',
      title: t('home.featuredSections.formulas.title'),
      description: t('home.featuredSections.formulas.description'),
      icon: FlaskConical,
      link: '/formulas',
      color: 'bg-blue-500',
      stats: '2000+ 经典方剂',
    },
    {
      key: 'acupoints',
      title: t('home.featuredSections.acupoints.title'),
      description: t('home.featuredSections.acupoints.description'),
      icon: Target,
      link: '/acupoints',
      color: 'bg-purple-500',
      stats: '400+ 穴位',
    },
    {
      key: 'learning',
      title: t('home.featuredSections.learning.title'),
      description: t('home.featuredSections.learning.description'),
      icon: GraduationCap,
      link: '/resources',
      color: 'bg-orange-500',
      stats: '1000+ 学习资源',
    },
  ];

  // 最新文章
  const latestArticles = [
    {
      id: 1,
      title: '中医基础理论：阴阳五行学说',
      summary: '深入解析中医理论中的阴阳五行学说，了解其在中医诊断和治疗中的重要作用...',
      category: '中医理论',
      author: '张仲景',
      publishedAt: '2025-01-05',
      readTime: 8,
      image: 'bg-gradient-to-br from-yellow-400 to-orange-500',
    },
    {
      id: 2,
      title: '常用中药材的识别与应用',
      summary: '学习如何识别常用中药材，掌握其基本功效和临床应用方法...',
      category: '中药学',
      author: '李时珍',
      publishedAt: '2025-01-04',
      readTime: 12,
      image: 'bg-gradient-to-br from-green-400 to-emerald-500',
    },
    {
      id: 3,
      title: '针灸穴位定位技巧',
      summary: '掌握准确的穴位定位方法，提高针灸治疗的临床效果...',
      category: '针灸学',
      author: '皇甫谧',
      publishedAt: '2025-01-03',
      readTime: 10,
      image: 'bg-gradient-to-br from-blue-400 to-cyan-500',
    },
  ];

  // 学习统计数据
  const stats = [
    { label: '注册用户', value: '50,000+', icon: Users },
    { label: '学习课时', value: '100,000+', icon: Clock },
    { label: '获得证书', value: '10,000+', icon: Award },
    { label: '满意度', value: '98%', icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section with Carousel */}
      <section className="relative">
        <Carousel className="w-full">
          <CarouselContent>
            {heroSlides.map((slide) => (
              <CarouselItem key={slide.id}>
                <div className={`relative h-[600px] flex items-center justify-center ${slide.image}`}>
                  <div className="absolute inset-0 bg-black/20" />
                  <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-4">
                    <h1 className="text-4xl md:text-6xl font-bold mb-6">
                      {slide.title}
                    </h1>
                    <p className="text-xl md:text-2xl mb-8 opacity-90">
                      {slide.subtitle}
                    </p>
                    <Button size="lg" asChild className="bg-white text-primary hover:bg-white/90">
                      <Link to={slide.link}>
                        {slide.cta}
                        <ChevronRight className="ml-2 h-5 w-5" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="left-4" />
          <CarouselNext className="right-4" />
        </Carousel>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="flex items-center justify-center w-16 h-16 mx-auto mb-4 bg-primary rounded-full text-primary-foreground">
                    <Icon className="h-8 w-8" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-2">{stat.value}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Sections */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">核心功能</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              全面的中医学习资源，系统化的知识体系，助您掌握中医精髓
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredSections.map((section) => {
              const Icon = section.icon;
              return (
                <Card key={section.key} className="group hover:shadow-lg transition-shadow cursor-pointer">
                  <Link to={section.link}>
                    <CardHeader className="text-center">
                      <div className={`w-16 h-16 mx-auto mb-4 rounded-full ${section.color} flex items-center justify-center text-white group-hover:scale-110 transition-transform`}>
                        <Icon className="h-8 w-8" />
                      </div>
                      <CardTitle className="text-xl">{section.title}</CardTitle>
                      <Badge variant="secondary" className="w-fit mx-auto">
                        {section.stats}
                      </Badge>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-center">
                        {section.description}
                      </CardDescription>
                    </CardContent>
                  </Link>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('home.latestArticles')}</h2>
              <p className="text-xl text-muted-foreground">
                精选优质内容，提升您的中医知识水平
              </p>
            </div>
            <Button variant="outline" asChild>
              <Link to="/articles">
                查看更多
                <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestArticles.map((article) => (
              <Card key={article.id} className="group hover:shadow-lg transition-shadow overflow-hidden">
                <div className={`h-48 ${article.image}`} />
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary">{article.category}</Badge>
                    <span className="text-sm text-muted-foreground">{article.readTime} 分钟阅读</span>
                  </div>
                  <CardTitle className="line-clamp-2 group-hover:text-primary transition-colors">
                    {article.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="line-clamp-3 mb-4">
                    {article.summary}
                  </CardDescription>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>作者: {article.author}</span>
                    <span>{article.publishedAt}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Access */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">{t('home.quickAccess')}</h2>
            <p className="text-xl text-muted-foreground">
              快速访问常用功能，提高学习效率
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Search className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2">智能搜索</h3>
              <p className="text-muted-foreground mb-4">
                快速搜索中药、方剂、穴位和文章内容
              </p>
              <Button variant="outline" asChild>
                <Link to="/search">开始搜索</Link>
              </Button>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <BookOpen className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2">在线测试</h3>
              <p className="text-muted-foreground mb-4">
                测试您的中医知识水平，查看学习进度
              </p>
              <Button variant="outline" asChild>
                <Link to="/quiz">开始测试</Link>
              </Button>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <Users className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2">学习社区</h3>
              <p className="text-muted-foreground mb-4">
                与其他学习者交流，分享学习心得
              </p>
              <Button variant="outline" asChild>
                <Link to="/community">加入社区</Link>
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            开始您的中医学习之旅
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            加入我们的学习平台，与数万名中医爱好者一起探索传统医学的奥秘
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link to="/register">
                免费注册
                <ChevronRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/pricing">
                查看会员方案
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
