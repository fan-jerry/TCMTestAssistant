import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Search,
  Filter,
  Grid,
  List,
  ChevronDown,
  Heart,
  Eye,
  Target,
  MapPin,
  Activity,
  User2,
  Zap,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import { cn } from '@/lib/utils';

interface Acupoint {
  id: number;
  name: string;
  pinyin: string;
  englishName: string;
  code: string;
  meridian: string;
  meridianType: string;
  location: string;
  functions: string;
  indications: string;
  viewCount: number;
  likeCount: number;
  image: string;
  isPremium: boolean;
}

const Acupoints: React.FC = () => {
  const { t } = useTranslation();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMeridian, setSelectedMeridian] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [currentPage, setCurrentPage] = useState(1);
  const [acupoints, setAcupoints] = useState<Acupoint[]>([]);
  const [loading, setLoading] = useState(true);

  // 经络分类数据
  const meridians = [
    { value: 'all', label: '全部经络' },
    { value: '手太阴肺经', label: '手太阴肺经' },
    { value: '手阳明大肠经', label: '手阳明大肠经' },
    { value: '足阳明胃经', label: '足阳明胃经' },
    { value: '足太阴脾经', label: '足太阴脾经' },
    { value: '手少阴心经', label: '手少阴心经' },
    { value: '手太阳小肠经', label: '手太阳小肠经' },
    { value: '足太阳膀胱经', label: '足太阳膀胱经' },
    { value: '足少阴肾经', label: '足少阴肾经' },
    { value: '手厥阴心包经', label: '手厥阴心包经' },
    { value: '手少阳三焦经', label: '手少阳三焦经' },
    { value: '足少阳胆经', label: '足少阳胆经' },
    { value: '足厥阴肝经', label: '足厥阴肝经' },
    { value: '督脉', label: '督脉' },
    { value: '任脉', label: '任脉' },
    { value: '经外奇穴', label: '经外奇穴' },
  ];

  const meridianTypes = [
    { value: 'all', label: '全部类型' },
    { value: '十二正经', label: '十二正经' },
    { value: '奇经八脉', label: '奇经八脉' },
    { value: '奇穴', label: '经外奇穴' },
  ];

  useEffect(() => {
    fetchAcupoints();
  }, []);

  const fetchAcupoints = async () => {
    try {
      setLoading(true);
      const response = await fetch('/data/acupoints.json');
      const data = await response.json();
      setAcupoints(data);
    } catch (error) {
      console.error('加载穴位数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  // 过滤和搜索逻辑
  const filteredAcupoints = acupoints.filter(acupoint => {
    const matchesSearch = acupoint.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         acupoint.pinyin.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         acupoint.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         acupoint.functions.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         acupoint.indications.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesMeridian = selectedMeridian === 'all' || acupoint.meridian === selectedMeridian;
    const matchesType = selectedType === 'all' || acupoint.meridianType === selectedType;
    
    return matchesSearch && matchesMeridian && matchesType;
  });

  // 排序逻辑
  const sortedAcupoints = [...filteredAcupoints].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'code':
        return a.code.localeCompare(b.code);
      case 'meridian':
        return a.meridian.localeCompare(b.meridian);
      case 'viewCount':
        return b.viewCount - a.viewCount;
      case 'likeCount':
        return b.likeCount - a.likeCount;
      default:
        return 0;
    }
  });

  const itemsPerPage = 12;
  const totalPages = Math.ceil(sortedAcupoints.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentAcupoints = sortedAcupoints.slice(startIndex, startIndex + itemsPerPage);

  // 按经络分组
  const acupointsByMeridian = acupoints.reduce((acc, acupoint) => {
    if (!acc[acupoint.meridian]) {
      acc[acupoint.meridian] = [];
    }
    acc[acupoint.meridian].push(acupoint);
    return acc;
  }, {} as Record<string, Acupoint[]>);

  const AcupointCard = ({ acupoint }: { acupoint: Acupoint }) => (
    <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg font-bold mb-1 group-hover:text-primary transition-colors">
              <Link to={`/acupoints/${acupoint.id}`} className="block">
                {acupoint.name}
                {acupoint.isPremium && (
                  <Badge variant="secondary" className="ml-2 text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                    VIP
                  </Badge>
                )}
              </Link>
            </CardTitle>
            <p className="text-sm text-muted-foreground mb-2">{acupoint.pinyin}</p>
            <p className="text-xs text-muted-foreground italic">{acupoint.englishName}</p>
          </div>
          <div className={cn("w-16 h-16 rounded-lg flex items-center justify-center text-white", acupoint.image)}>
            <Target className="w-8 h-8" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="flex flex-wrap gap-1">
            <Badge variant="outline" className="text-xs">
              {acupoint.code}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {acupoint.meridianType}
            </Badge>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Activity className="w-4 h-4" />
              <span className="line-clamp-1">{acupoint.meridian}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span className="line-clamp-1">{acupoint.location}</span>
            </div>
          </div>

          <div className="space-y-2">
            <div>
              <p className="text-sm font-medium mb-1">主要功效</p>
              <p className="text-sm text-muted-foreground line-clamp-2">{acupoint.functions}</p>
            </div>
            <div>
              <p className="text-sm font-medium mb-1">主治</p>
              <p className="text-sm text-muted-foreground line-clamp-2">{acupoint.indications}</p>
            </div>
          </div>
          
          <div className="flex items-center justify-between pt-2 border-t">
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                <span>{acupoint.viewCount.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <Heart className="w-4 h-4" />
                <span>{acupoint.likeCount}</span>
              </div>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to={`/acupoints/${acupoint.id}`}>
                详细了解
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const AcupointListItem = ({ acupoint }: { acupoint: Acupoint }) => (
    <Card className="group hover:shadow-md transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          <div className={cn("w-16 h-16 rounded-lg flex items-center justify-center text-white flex-shrink-0", acupoint.image)}>
            <Target className="w-8 h-8" />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <Link to={`/acupoints/${acupoint.id}`} className="font-bold text-lg group-hover:text-primary transition-colors">
                {acupoint.name}
              </Link>
              <Badge variant="outline" className="text-xs">{acupoint.code}</Badge>
              {acupoint.isPremium && (
                <Badge variant="secondary" className="text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                  VIP
                </Badge>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
              <div>
                <p className="text-sm text-muted-foreground mb-1">{acupoint.pinyin}</p>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <Activity className="w-4 h-4" />
                  <span>{acupoint.meridian}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span className="line-clamp-1">{acupoint.location}</span>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium mb-1">主要功效</p>
                <p className="text-sm text-muted-foreground line-clamp-2">{acupoint.functions}</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{acupoint.viewCount.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Heart className="w-4 h-4" />
                  <span>{acupoint.likeCount}</span>
                </div>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to={`/acupoints/${acupoint.id}`}>
                  详细了解
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const MeridianSection = ({ meridianName, acupoints }: { meridianName: string, acupoints: Acupoint[] }) => (
    <div className="mb-8">
      <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Activity className="w-5 h-5" />
        {meridianName}
        <Badge variant="secondary" className="ml-2">
          {acupoints.length} 个穴位
        </Badge>
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {acupoints.slice(0, 6).map((acupoint) => (
          <Card key={acupoint.id} className="group hover:shadow-md transition-all duration-300">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center text-white", acupoint.image)}>
                  <Target className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <Link to={`/acupoints/${acupoint.id}`} className="font-semibold group-hover:text-primary transition-colors">
                    {acupoint.name}
                  </Link>
                  <p className="text-sm text-muted-foreground">{acupoint.code}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      {acupoints.length > 6 && (
        <div className="mt-4 text-center">
          <Button variant="outline" size="sm">
            查看更多 {meridianName} 穴位
          </Button>
        </div>
      )}
    </div>
  );

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 页面标题 */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{t('acupoints.title')}</h1>
        <p className="text-xl text-muted-foreground">
          针灸穴位定位与应用指南
        </p>
      </div>

      {/* 标签页 */}
      <Tabs defaultValue="search" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="search">搜索穴位</TabsTrigger>
          <TabsTrigger value="meridian">按经络浏览</TabsTrigger>
        </TabsList>

        <TabsContent value="search" className="space-y-6">
          {/* 搜索和过滤区域 */}
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="搜索穴位名称、拼音、编码、功效..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <Select value={selectedMeridian} onValueChange={setSelectedMeridian}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="选择经络" />
                </SelectTrigger>
                <SelectContent>
                  {meridians.map((meridian) => (
                    <SelectItem key={meridian.value} value={meridian.value}>
                      {meridian.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="选择类型" />
                </SelectTrigger>
                <SelectContent>
                  {meridianTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="gap-2">
                    <Filter className="w-4 h-4" />
                    排序方式
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuLabel>排序方式</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setSortBy('name')}>
                    按名称排序
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortBy('code')}>
                    按编码排序
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortBy('meridian')}>
                    按经络排序
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortBy('viewCount')}>
                    按浏览量排序
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortBy('likeCount')}>
                    按收藏量排序
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* 统计信息 */}
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              共找到 {filteredAcupoints.length} 个穴位
            </p>
            <p className="text-sm text-muted-foreground">
              第 {currentPage} 页，共 {totalPages} 页
            </p>
          </div>

          {/* 穴位列表 */}
          {currentAcupoints.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-24 h-24 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
                <Target className="w-12 h-12 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">未找到相关穴位</h3>
              <p className="text-muted-foreground">请尝试调整搜索条件或过滤选项</p>
            </div>
          ) : (
            <>
              {viewMode === 'grid' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {currentAcupoints.map((acupoint) => (
                    <AcupointCard key={acupoint.id} acupoint={acupoint} />
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {currentAcupoints.map((acupoint) => (
                    <AcupointListItem key={acupoint.id} acupoint={acupoint} />
                  ))}
                </div>
              )}

              {/* 分页 */}
              {totalPages > 1 && (
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious 
                        onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
                        className={currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                      />
                    </PaginationItem>
                    
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      const pageNum = i + 1;
                      return (
                        <PaginationItem key={pageNum}>
                          <PaginationLink
                            onClick={() => setCurrentPage(pageNum)}
                            isActive={currentPage === pageNum}
                            className="cursor-pointer"
                          >
                            {pageNum}
                          </PaginationLink>
                        </PaginationItem>
                      );
                    })}
                    
                    <PaginationItem>
                      <PaginationNext 
                        onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
                        className={currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              )}
            </>
          )}
        </TabsContent>

        <TabsContent value="meridian" className="space-y-6">
          {/* 人体经络导航图 */}
          <Card className="p-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">人体经络图</h3>
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-8 mb-4">
                <div className="flex items-center justify-center h-64">
                  <User2 className="w-32 h-32 text-primary" />
                </div>
              </div>
              <p className="text-sm text-muted-foreground">
                点击下方经络名称查看对应穴位，或使用搜索功能快速定位
              </p>
            </div>
          </Card>

          {/* 按经络分组显示 */}
          <div className="space-y-8">
            {Object.entries(acupointsByMeridian).map(([meridianName, meridianAcupoints]) => (
              <MeridianSection
                key={meridianName}
                meridianName={meridianName}
                acupoints={meridianAcupoints}
              />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Acupoints;
