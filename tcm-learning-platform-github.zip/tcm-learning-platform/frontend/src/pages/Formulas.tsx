import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Search,
  Filter,
  Grid,
  List,
  ChevronDown,
  Heart,
  Eye,
  BookOpen,
  Pill,
  User,
  Calendar,
  Tag,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import { cn } from '@/lib/utils';

interface Formula {
  id: number;
  name: string;
  pinyin: string;
  englishName?: string;
  category: string;
  subcategory: string;
  source: string;
  author: string;
  dynasty: string;
  composition: Array<{ herb: string; dosage: string; unit: string; role: string }>;
  functions: string;
  indications: string;
  viewCount: number;
  likeCount: number;
  image: string;
  isPremium: boolean;
}

const Formulas: React.FC = () => {
  const { t } = useTranslation();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedDynasty, setSelectedDynasty] = useState('all');
  const [selectedSource, setSelectedSource] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [currentPage, setCurrentPage] = useState(1);
  const [formulas, setFormulas] = useState<Formula[]>([]);
  const [loading, setLoading] = useState(true);

  // 分类数据
  const categories = [
    { value: 'all', label: '全部分类' },
    { value: '解表剂', label: '解表剂' },
    { value: '泻下剂', label: '泻下剂' },
    { value: '和解剂', label: '和解剂' },
    { value: '清热剂', label: '清热剂' },
    { value: '温里剂', label: '温里剂' },
    { value: '补益剂', label: '补益剂' },
    { value: '固涩剂', label: '固涩剂' },
    { value: '安神剂', label: '安神剂' },
    { value: '开窍剂', label: '开窍剂' },
    { value: '理气剂', label: '理气剂' },
    { value: '理血剂', label: '理血剂' },
    { value: '治风剂', label: '治风剂' },
    { value: '治燥剂', label: '治燥剂' },
    { value: '祛湿剂', label: '祛湿剂' },
    { value: '祛痰剂', label: '祛痰剂' },
    { value: '消食剂', label: '消食剂' },
    { value: '驱虫剂', label: '驱虫剂' },
  ];

  const dynasties = [
    { value: 'all', label: '全部朝代' },
    { value: '汉朝', label: '汉朝' },
    { value: '唐朝', label: '唐朝' },
    { value: '宋朝', label: '宋朝' },
    { value: '金朝', label: '金朝' },
    { value: '元朝', label: '元朝' },
    { value: '明朝', label: '明朝' },
    { value: '清朝', label: '清朝' },
  ];

  const sources = [
    { value: 'all', label: '全部出处' },
    { value: '《伤寒论》', label: '《伤寒论》' },
    { value: '《金匮要略》', label: '《金匮要略》' },
    { value: '《太平惠民和剂局方》', label: '《太平惠民和剂局方》' },
    { value: '《温病条辨》', label: '《温病条辨》' },
    { value: '《小儿药证直诀》', label: '《小儿药证直诀》' },
    { value: '《医学启源》', label: '《医学启源》' },
    { value: '《丹溪心法》', label: '《丹溪心法》' },
  ];

  useEffect(() => {
    fetchFormulas();
  }, []);

  const fetchFormulas = async () => {
    try {
      setLoading(true);
      const response = await fetch('/data/formulas.json');
      const data = await response.json();
      setFormulas(data);
    } catch (error) {
      console.error('加载方剂数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  // 过滤和搜索逻辑
  const filteredFormulas = formulas.filter(formula => {
    const matchesSearch = formula.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         formula.pinyin.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         formula.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         formula.functions.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         formula.indications.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || formula.category === selectedCategory;
    const matchesDynasty = selectedDynasty === 'all' || formula.dynasty === selectedDynasty;
    const matchesSource = selectedSource === 'all' || formula.source === selectedSource;
    
    return matchesSearch && matchesCategory && matchesDynasty && matchesSource;
  });

  // 排序逻辑
  const sortedFormulas = [...filteredFormulas].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'viewCount':
        return b.viewCount - a.viewCount;
      case 'likeCount':
        return b.likeCount - a.likeCount;
      case 'dynasty':
        return a.dynasty.localeCompare(b.dynasty);
      default:
        return 0;
    }
  });

  const itemsPerPage = 12;
  const totalPages = Math.ceil(sortedFormulas.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentFormulas = sortedFormulas.slice(startIndex, startIndex + itemsPerPage);

  const FormulaCard = ({ formula }: { formula: Formula }) => (
    <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg font-bold mb-1 group-hover:text-primary transition-colors">
              <Link to={`/formulas/${formula.id}`} className="block">
                {formula.name}
                {formula.isPremium && (
                  <Badge variant="secondary" className="ml-2 text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                    VIP
                  </Badge>
                )}
              </Link>
            </CardTitle>
            <p className="text-sm text-muted-foreground mb-2">{formula.pinyin}</p>
            {formula.englishName && (
              <p className="text-xs text-muted-foreground italic">{formula.englishName}</p>
            )}
          </div>
          <div className={cn("w-16 h-16 rounded-lg flex items-center justify-center text-white", formula.image)}>
            <Pill className="w-8 h-8" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div className="flex flex-wrap gap-1">
            <Badge variant="outline" className="text-xs">
              {formula.category}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {formula.subcategory}
            </Badge>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <BookOpen className="w-4 h-4" />
              <span>{formula.source}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <User className="w-4 h-4" />
              <span>{formula.author}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>{formula.dynasty}</span>
            </div>
          </div>

          <div className="space-y-2">
            <div>
              <p className="text-sm font-medium mb-1">功效主治</p>
              <p className="text-sm text-muted-foreground line-clamp-2">{formula.functions}</p>
            </div>
            <div>
              <p className="text-sm font-medium mb-1">药物组成</p>
              <p className="text-sm text-muted-foreground line-clamp-2">
                {formula.composition.map(item => item.herb).join('、')}
              </p>
            </div>
          </div>
          
          <div className="flex items-center justify-between pt-2 border-t">
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Eye className="w-4 h-4" />
                <span>{formula.viewCount.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <Heart className="w-4 h-4" />
                <span>{formula.likeCount}</span>
              </div>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to={`/formulas/${formula.id}`}>
                详细了解
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const FormulaListItem = ({ formula }: { formula: Formula }) => (
    <Card className="group hover:shadow-md transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          <div className={cn("w-16 h-16 rounded-lg flex items-center justify-center text-white flex-shrink-0", formula.image)}>
            <Pill className="w-8 h-8" />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <Link to={`/formulas/${formula.id}`} className="font-bold text-lg group-hover:text-primary transition-colors">
                {formula.name}
              </Link>
              {formula.isPremium && (
                <Badge variant="secondary" className="text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                  VIP
                </Badge>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
              <div>
                <p className="text-sm text-muted-foreground mb-1">{formula.pinyin}</p>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <BookOpen className="w-4 h-4" />
                  <span>{formula.source} · {formula.author} · {formula.dynasty}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  <Badge variant="outline" className="text-xs">{formula.category}</Badge>
                  <Badge variant="outline" className="text-xs">{formula.subcategory}</Badge>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium mb-1">功效主治</p>
                <p className="text-sm text-muted-foreground line-clamp-2">{formula.functions}</p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  <span>{formula.viewCount.toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Heart className="w-4 h-4" />
                  <span>{formula.likeCount}</span>
                </div>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to={`/formulas/${formula.id}`}>
                  详细了解
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 页面标题 */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{t('formulas.title')}</h1>
        <p className="text-xl text-muted-foreground">
          传统方剂配伍大全，临床应用指导
        </p>
      </div>

      {/* 搜索和过滤区域 */}
      <div className="mb-6 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="搜索方剂名称、拼音、作者、功效..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="flex flex-wrap gap-4">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="选择分类" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category.value} value={category.value}>
                  {category.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedDynasty} onValueChange={setSelectedDynasty}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="选择朝代" />
            </SelectTrigger>
            <SelectContent>
              {dynasties.map((dynasty) => (
                <SelectItem key={dynasty.value} value={dynasty.value}>
                  {dynasty.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedSource} onValueChange={setSelectedSource}>
            <SelectTrigger className="w-60">
              <SelectValue placeholder="选择出处" />
            </SelectTrigger>
            <SelectContent>
              {sources.map((source) => (
                <SelectItem key={source.value} value={source.value}>
                  {source.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Filter className="w-4 h-4" />
                排序方式
                <ChevronDown className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuLabel>排序方式</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setSortBy('name')}>
                按名称排序
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('viewCount')}>
                按浏览量排序
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('likeCount')}>
                按收藏量排序
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('dynasty')}>
                按朝代排序
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* 统计信息 */}
      <div className="mb-6 flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          共找到 {filteredFormulas.length} 个方剂
        </p>
        <p className="text-sm text-muted-foreground">
          第 {currentPage} 页，共 {totalPages} 页
        </p>
      </div>

      {/* 方剂列表 */}
      {currentFormulas.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-24 h-24 mx-auto mb-4 bg-muted rounded-full flex items-center justify-center">
            <Pill className="w-12 h-12 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-2">未找到相关方剂</h3>
          <p className="text-muted-foreground">请尝试调整搜索条件或过滤选项</p>
        </div>
      ) : (
        <>
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {currentFormulas.map((formula) => (
                <FormulaCard key={formula.id} formula={formula} />
              ))}
            </div>
          ) : (
            <div className="space-y-4 mb-8">
              {currentFormulas.map((formula) => (
                <FormulaListItem key={formula.id} formula={formula} />
              ))}
            </div>
          )}

          {/* 分页 */}
          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
                    className={currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                  />
                </PaginationItem>
                
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const pageNum = i + 1;
                  return (
                    <PaginationItem key={pageNum}>
                      <PaginationLink
                        onClick={() => setCurrentPage(pageNum)}
                        isActive={currentPage === pageNum}
                        className="cursor-pointer"
                      >
                        {pageNum}
                      </PaginationLink>
                    </PaginationItem>
                  );
                })}
                
                <PaginationItem>
                  <PaginationNext 
                    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
                    className={currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}
    </div>
  );
};

export default Formulas;
