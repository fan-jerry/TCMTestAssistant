import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Search,
  Filter,
  Grid,
  List,
  ChevronDown,
  Heart,
  Eye,
  BookOpen,
  Leaf,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import { cn } from '@/lib/utils';

const Herbs: React.FC = () => {
  const { t } = useTranslation();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedNature, setSelectedNature] = useState('all');
  const [selectedTaste, setSelectedTaste] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [currentPage, setCurrentPage] = useState(1);

  // 模拟数据
  const categories = [
    { value: 'all', label: '全部分类' },
    { value: 'qi-tonifying', label: '补气药' },
    { value: 'blood-tonifying', label: '补血药' },
    { value: 'yin-tonifying', label: '补阴药' },
    { value: 'yang-tonifying', label: '补阳药' },
    { value: 'heat-clearing', label: '清热药' },
    { value: 'wind-dampness', label: '祛风湿药' },
    { value: 'blood-regulating', label: '活血化瘀药' },
    { value: 'qi-regulating', label: '理气药' },
  ];

  const natures = [
    { value: 'all', label: '全部性味' },
    { value: 'cold', label: '寒' },
    { value: 'cool', label: '凉' },
    { value: 'neutral', label: '平' },
    { value: 'warm', label: '温' },
    { value: 'hot', label: '热' },
  ];

  const tastes = [
    { value: 'all', label: '全部味道' },
    { value: 'sweet', label: '甘' },
    { value: 'bitter', label: '苦' },
    { value: 'spicy', label: '辛' },
    { value: 'sour', label: '酸' },
    { value: 'salty', label: '咸' },
    { value: 'bland', label: '淡' },
  ];

  const herbs = [
    {
      id: 1,
      name: '人参',
      pinyin: 'rén shēn',
      englishName: 'Ginseng',
      category: '补气药',
      nature: '温',
      taste: '甘、微苦',
      meridian: '脾、肺、心、肾经',
      functions: '大补元气，复脉固脱，补脾益肺，生津养血，安神益智',
      indications: '气虚欲脱，肢冷脉微，脾虚食少，肺虚喘咳，津伤口渴，内热消渴，气血亏虚，久病虚羸，惊悸失眠，阳痿宫冷',
      usage: '3-9g，另煎兑入；或研末冲服，一次2g，一日2次',
      isPremium: false,
      viewCount: 12580,
      likeCount: 358,
      image: 'bg-gradient-to-br from-red-400 to-orange-500',
    },
    {
      id: 2,
      name: '当归',
      pinyin: 'dāng guī',
      englishName: 'Angelica Sinensis',
      category: '补血药',
      nature: '温',
      taste: '甘、辛',
      meridian: '肝、心、脾经',
      functions: '补血活血，调经止痛，润肠通便',
      indications: '血虚萎黄，眩晕心悸，月经不调，经闭痛经，虚寒腹痛，风湿痹痛，跌扑损伤，痈疽疮疡，肠燥便秘',
      usage: '6-12g',
      isPremium: false,
      viewCount: 9876,
      likeCount: 287,
      image: 'bg-gradient-to-br from-green-400 to-emerald-500',
    },
    {
      id: 3,
      name: '黄芪',
      pinyin: 'huáng qí',
      englishName: 'Astragalus',
      category: '补气药',
      nature: '微温',
      taste: '甘',
      meridian: '肺、脾经',
      functions: '补气升阳，固表止汗，利水消肿，生津养血，行滞通痹，托毒排脓，敛疮生肌',
      indications: '气虚乏力，食少便溏，中气下陷，久泻脱肛，便血崩漏，表虚自汗，气虚水肿，内热消渴，血虚萎黄，半身不遂，痹痛麻木，痈疽难溃，久溃不敛',
      usage: '9-30g',
      isPremium: false,
      viewCount: 8234,
      likeCount: 234,
      image: 'bg-gradient-to-br from-yellow-400 to-orange-500',
    },
    {
      id: 4,
      name: '枸杞子',
      pinyin: 'gǒu qǐ zǐ',
      englishName: 'Lycium Barbarum',
      category: '补阴药',
      nature: '平',
      taste: '甘',
      meridian: '肝、肾经',
      functions: '滋补肝肾，明目润肺',
      indications: '肝肾阴虚，腰膝酸软，头晕目眩，目昏多泪，虚劳咳嗽，消渴遗精',
      usage: '6-12g',
      isPremium: false,
      viewCount: 15678,
      likeCount: 456,
      image: 'bg-gradient-to-br from-purple-400 to-pink-500',
    },
    {
      id: 5,
      name: '甘草',
      pinyin: 'gān cǎo',
      englishName: 'Glycyrrhiza',
      category: '补气药',
      nature: '平',
      taste: '甘',
      meridian: '心、肺、脾、胃经',
      functions: '补脾益气，清热解毒，祛痰止咳，缓急止痛，调和诸药',
      indications: '脾胃虚弱，倦怠乏力，心悸气短，咳嗽痰多，脘腹、四肢挛急疼痛，痈肿疮毒，缓解药物毒性、烈性',
      usage: '2-10g',
      isPremium: false,
      viewCount: 11234,
      likeCount: 298,
      image: 'bg-gradient-to-br from-blue-400 to-cyan-500',
    },
    {
      id: 6,
      name: '冬虫夏草',
      pinyin: 'dōng chóng xià cǎo',
      englishName: 'Cordyceps',
      category: '补阳药',
      nature: '温',
      taste: '甘',
      meridian: '肺、肾经',
      functions: '补肾益肺，止血化痰',
      indications: '肾虚精亏，阳痿遗精，腰膝酸痛，病后虚弱，久咳虚喘，劳嗽痰血',
      usage: '5-10g，煎服；或入丸、散',
      isPremium: true,
      viewCount: 25678,
      likeCount: 789,
      image: 'bg-gradient-to-br from-amber-400 to-yellow-500',
    },
  ];

  const filteredHerbs = herbs.filter(herb => {
    const matchesSearch = herb.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         herb.pinyin.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         herb.functions.includes(searchQuery) ||
                         herb.indications.includes(searchQuery);
    
    const matchesCategory = selectedCategory === 'all' || herb.category === categories.find(c => c.value === selectedCategory)?.label;
    
    return matchesSearch && matchesCategory;
  });

  const HerbCard: React.FC<{ herb: typeof herbs[0]; view: 'grid' | 'list' }> = ({ herb, view }) => {
    if (view === 'list') {
      return (
        <Card className="hover:shadow-md transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <div className={`w-20 h-20 rounded-lg ${herb.image} flex-shrink-0`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-xl font-semibold">{herb.name}</h3>
                    <p className="text-muted-foreground">{herb.pinyin}</p>
                    {herb.englishName && (
                      <p className="text-sm text-muted-foreground">{herb.englishName}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    {herb.isPremium && (
                      <Badge variant="secondary">会员</Badge>
                    )}
                    <Button variant="ghost" size="sm">
                      <Heart className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                  <div>
                    <span className="text-muted-foreground">分类：</span>
                    <Badge variant="outline">{herb.category}</Badge>
                  </div>
                  <div>
                    <span className="text-muted-foreground">性味：</span>
                    <span>{herb.nature} {herb.taste}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">归经：</span>
                    <span>{herb.meridian}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">用量：</span>
                    <span>{herb.usage}</span>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                  <strong>功效：</strong>{herb.functions}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span className="flex items-center">
                      <Eye className="h-4 w-4 mr-1" />
                      {herb.viewCount}
                    </span>
                    <span className="flex items-center">
                      <Heart className="h-4 w-4 mr-1" />
                      {herb.likeCount}
                    </span>
                  </div>
                  <Button asChild>
                    <Link to={`/herbs/${herb.id}`}>查看详情</Link>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      );
    }

    return (
      <Card className="group hover:shadow-lg transition-shadow overflow-hidden">
        <div className={`h-48 ${herb.image} relative`}>
          {herb.isPremium && (
            <Badge className="absolute top-2 right-2" variant="secondary">
              会员
            </Badge>
          )}
        </div>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="min-w-0 flex-1">
              <CardTitle className="text-lg line-clamp-1">{herb.name}</CardTitle>
              <CardDescription>{herb.pinyin}</CardDescription>
              {herb.englishName && (
                <p className="text-xs text-muted-foreground mt-1">{herb.englishName}</p>
              )}
            </div>
            <Button variant="ghost" size="sm" className="flex-shrink-0">
              <Heart className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <Badge variant="outline">{herb.category}</Badge>
            <span className="text-muted-foreground">{herb.nature} {herb.taste}</span>
          </div>
          
          <p className="text-sm text-muted-foreground line-clamp-3">
            <strong>功效：</strong>{herb.functions}
          </p>
          
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-3 text-xs text-muted-foreground">
              <span className="flex items-center">
                <Eye className="h-3 w-3 mr-1" />
                {herb.viewCount}
              </span>
              <span className="flex items-center">
                <Heart className="h-3 w-3 mr-1" />
                {herb.likeCount}
              </span>
            </div>
            <Button size="sm" asChild>
              <Link to={`/herbs/${herb.id}`}>详情</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{t('herbs.title')}</h1>
        <p className="text-xl text-muted-foreground">
          汇集传统中药材精粹，深入了解每一味药材的功效与应用
        </p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4 mb-8">
        {/* Main Search */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder={t('herbs.searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="选择分类" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category.value} value={category.value}>
                  {category.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedNature} onValueChange={setSelectedNature}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="药性" />
            </SelectTrigger>
            <SelectContent>
              {natures.map((nature) => (
                <SelectItem key={nature.value} value={nature.value}>
                  {nature.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedTaste} onValueChange={setSelectedTaste}>
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="药味" />
            </SelectTrigger>
            <SelectContent>
              {tastes.map((taste) => (
                <SelectItem key={taste.value} value={taste.value}>
                  {taste.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                排序
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => setSortBy('name')}>
                按名称排序
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('category')}>
                按分类排序
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('viewCount')}>
                按浏览量排序
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy('likeCount')}>
                按收藏量排序
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Results Info */}
      <div className="flex items-center justify-between mb-6">
        <p className="text-muted-foreground">
          共找到 {filteredHerbs.length} 种中药材
        </p>
        <Button variant="outline" size="sm">
          <Filter className="h-4 w-4 mr-2" />
          高级筛选
        </Button>
      </div>

      {/* Herbs Grid/List */}
      <div className={cn(
        viewMode === 'grid' 
          ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' 
          : 'space-y-4'
      )}>
        {filteredHerbs.map((herb) => (
          <HerbCard key={herb.id} herb={herb} view={viewMode} />
        ))}
      </div>

      {/* Pagination */}
      <div className="mt-12 flex justify-center">
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious 
                href="#" 
                onClick={(e) => {
                  e.preventDefault();
                  if (currentPage > 1) setCurrentPage(currentPage - 1);
                }}
                className={currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
              />
            </PaginationItem>
            {[...Array(Math.ceil(filteredHerbs.length / 12))].map((_, index) => (
              <PaginationItem key={index + 1}>
                <PaginationLink
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setCurrentPage(index + 1);
                  }}
                  isActive={currentPage === index + 1}
                >
                  {index + 1}
                </PaginationLink>
              </PaginationItem>
            ))}
            <PaginationItem>
              <PaginationNext 
                href="#" 
                onClick={(e) => {
                  e.preventDefault();
                  if (currentPage < Math.ceil(filteredHerbs.length / 12)) {
                    setCurrentPage(currentPage + 1);
                  }
                }}
                className={currentPage === Math.ceil(filteredHerbs.length / 12) ? 'pointer-events-none opacity-50' : ''}
              />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      </div>
    </div>
  );
};

export default Herbs;
