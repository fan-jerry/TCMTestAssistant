import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import {
  ArrowLeft,
  Bookmark,
  Heart,
  Share2,
  MessageSquare,
  AlertCircle,
  BarChart3,
  ClipboardList,
  Beaker,
  PlusCircle,
  MinusCircle,
  Scale,
  Thermometer,
  Activity,
  CircleOff,
  FileText,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Formula, Herb } from '@/types';
import { formulaApi, favoriteApi } from '@/lib/api';
import { cn } from '@/lib/utils';

const FormulaDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [isFavorited, setIsFavorited] = useState(false);
  const [comment, setComment] = useState('');
  
  // 模拟方剂数据
  const mockFormula: Formula = {
    id: 1,
    name: '桂枝汤',
    pinyin: 'guì zhī tāng',
    englishName: 'Cinnamon Twig Decoction',
    category: '解表剂',
    source: '《伤寒论》',
    composition: [
      { 
        herb: {
          id: 1,
          name: '桂枝',
          pinyin: 'guì zhī',
          englishName: 'Cinnamon Twig',
          category: '解表药',
          nature: '温',
          taste: '辛、甘',
          meridian: '心、肺、膀胱经',
          functions: '发汗解表，温通经脉，助阳化气',
          indications: '风寒感冒，恶寒发热，头痛鼻塞，四肢酸痛',
          usage: '3-10g',
          precautions: '阴虚火旺及有实热证者慎用',
          image: '/images/herbs/guizhi.jpg',
          isPremium: false,
          createdAt: '2024-01-01',
          updatedAt: '2024-01-01'
        },
        dosage: '9',
        unit: '克'
      },
      { 
        herb: {
          id: 2,
          name: '白芍',
          pinyin: 'bái sháo',
          englishName: 'White Peony Root',
          category: '补血药',
          nature: '微寒',
          taste: '苦、酸',
          meridian: '肝、脾经',
          functions: '养血柔肝，缓中止痛，平抑肝阳',
          indications: '月经不调，痛经，自汗，盗汗，腹痛，腹泻',
          usage: '6-15g',
          precautions: '脾胃虚寒者慎用',
          image: '/images/herbs/baishao.jpg',
          isPremium: false,
          createdAt: '2024-01-01',
          updatedAt: '2024-01-01'
        },
        dosage: '9',
        unit: '克'
      },
      { 
        herb: {
          id: 3,
          name: '生姜',
          pinyin: 'shēng jiāng',
          englishName: 'Fresh Ginger',
          category: '解表药',
          nature: '微温',
          taste: '辛',
          meridian: '肺、脾、胃经',
          functions: '发汗解表，温中止呕，温肺止咳',
          indications: '风寒感冒，恶心呕吐，胃寒痛，咳嗽痰多',
          usage: '3-10g',
          precautions: '阴虚火旺者慎用',
          image: '/images/herbs/shengjiang.jpg',
          isPremium: false,
          createdAt: '2024-01-01',
          updatedAt: '2024-01-01'
        },
        dosage: '9',
        unit: '克'
      },
      { 
        herb: {
          id: 4,
          name: '大枣',
          pinyin: 'dà zǎo',
          englishName: 'Jujube',
          category: '补气药',
          nature: '温',
          taste: '甘',
          meridian: '脾、胃经',
          functions: '补中益气，养血安神',
          indications: '脾胃虚弱，气血不足，食少乏力，心悸失眠',
          usage: '10-30g',
          precautions: '湿阻中满、积滞腹胀者慎用',
          image: '/images/herbs/dazao.jpg',
          isPremium: false,
          createdAt: '2024-01-01',
          updatedAt: '2024-01-01'
        },
        dosage: '12',
        unit: '枚'
      },
      { 
        herb: {
          id: 5,
          name: '甘草',
          pinyin: 'gān cǎo',
          englishName: 'Licorice Root',
          category: '补气药',
          nature: '平',
          taste: '甘',
          meridian: '心、肺、脾、胃经',
          functions: '补脾益气，清热解毒，祛痰止咳，缓急止痛，调和诸药',
          indications: '脾胃虚弱，倦怠乏力，心悸气短，咳嗽痰多，痈肿疮毒',
          usage: '3-10g',
          precautions: '水肿、高血压者慎用',
          image: '/images/herbs/gancao.jpg',
          isPremium: false,
          createdAt: '2024-01-01',
          updatedAt: '2024-01-01'
        },
        dosage: '6',
        unit: '克'
      }
    ],
    functions: '发汗解表，调和营卫',
    indications: '治太阳中风，恶风，发热，汗出，头痛，鼻鸣，干呕，苔薄白，脉浮缓。',
    preparation: '上五味，以水七升，微火煮取三升，去滓，适温服一升，服已须臾，啜热稀粥一升余，以助药力。温覆取微似汗，不可发大汗，大汗出亡阳，为难治也。若一服汗出病瘥，停后服。',
    dosage: '温服，日三次',
    precautions: '不可用于外感风热、热病、阴虚发热者。汗出太多可导致阳气大伤，慎用。',
    clinicalApplications: '主要用于风寒感冒，表虚不固证。现代也用于治疗自汗、盗汗、过敏性鼻炎、风湿关节痛等。',
    isPremium: false,
    createdAt: '2024-01-01',
    updatedAt: '2024-01-01'
  };
  
  // 相关方剂推荐
  const relatedFormulas = [
    { id: 2, name: '桂枝加葛根汤', category: '解表剂', source: '《伤寒论》' },
    { id: 3, name: '桂枝加芍药汤', category: '解表剂', source: '《伤寒论》' },
    { id: 4, name: '桂枝加厚朴杏子汤', category: '解表剂', source: '《伤寒论》' },
    { id: 5, name: '葛根汤', category: '解表剂', source: '《伤寒论》' },
  ];
  
  // 用户评论
  const comments = [
    {
      id: 1,
      user: { id: 1, username: 'doctor1', nickname: '李医师', avatar: '' },
      content: '桂枝汤是经方中非常经典的方剂，重在调和营卫。我在临床中常用于治疗表虚感冒，效果很好。',
      createdAt: '2024-05-15T14:30:00Z',
      likeCount: 15
    },
    {
      id: 2,
      user: { id: 2, username: 'student1', nickname: '张同学', avatar: '' },
      content: '作为初学者，桂枝汤是理解伤寒论六经辨证的重要方剂，值得深入研究。',
      createdAt: '2024-05-14T08:15:00Z',
      likeCount: 8
    }
  ];
  
  // 模拟API调用
  // const { data: formula, isLoading, error } = useQuery(
  //   ['formula', id],
  //   () => formulaApi.get(Number(id)),
  //   { enabled: !!id }
  // );
  
  // 为了演示，直接使用模拟数据
  const formula = mockFormula;
  const isLoading = false;
  const error = null;
  
  // 检查是否已收藏
  useEffect(() => {
    if (isAuthenticated && id) {
      // 模拟API调用检查是否已收藏
      // favoriteApi.check('FORMULA', Number(id))
      //   .then(result => {
      //     setIsFavorited(result);
      //   });
      setIsFavorited(false);
    }
  }, [isAuthenticated, id]);
  
  const handleToggleFavorite = () => {
    if (!isAuthenticated) {
      toast({
        title: "需要登录",
        description: "请登录后使用收藏功能",
        variant: "destructive"
      });
      return;
    }
    
    setIsFavorited(!isFavorited);
    
    if (!isFavorited) {
      // favoriteApi.add('FORMULA', Number(id))
      toast({
        title: "收藏成功",
        description: `已将"${formula.name}"添加到收藏`
      });
    } else {
      // favoriteApi.remove(Number(id))
      toast({
        title: "已取消收藏",
        description: `已将"${formula.name}"从收藏中移除`
      });
    }
  };
  
  const handleSubmitComment = () => {
    if (!isAuthenticated) {
      toast({
        title: "需要登录",
        description: "请登录后发表评论",
        variant: "destructive"
      });
      return;
    }
    
    if (!comment.trim()) {
      toast({
        title: "评论不能为空",
        description: "请输入评论内容",
        variant: "destructive"
      });
      return;
    }
    
    // 提交评论逻辑
    toast({
      title: "评论已提交",
      description: "您的评论已成功发布"
    });
    
    setComment('');
  };
  
  // 计算总药量
  const calculateTotalWeight = () => {
    return formula.composition.reduce((total, item) => {
      if (item.unit === '克') {
        return total + parseFloat(item.dosage);
      }
      return total;
    }, 0);
  };
  
  // 判断药材归经
  const getMeridianColor = (meridian: string) => {
    if (meridian.includes('心')) return 'text-red-600';
    if (meridian.includes('肺')) return 'text-gray-500';
    if (meridian.includes('肝')) return 'text-green-600';
    if (meridian.includes('脾')) return 'text-yellow-600';
    if (meridian.includes('胃')) return 'text-yellow-500';
    if (meridian.includes('肾')) return 'text-blue-600';
    if (meridian.includes('胆')) return 'text-green-500';
    if (meridian.includes('膀胱')) return 'text-blue-500';
    if (meridian.includes('三焦')) return 'text-orange-500';
    if (meridian.includes('大肠')) return 'text-amber-600';
    if (meridian.includes('小肠')) return 'text-amber-500';
    return 'text-gray-600';
  };
  
  // 药性标签颜色
  const getNatureColor = (nature: string) => {
    if (nature.includes('热') || nature.includes('温')) return 'bg-red-100 text-red-800 border-red-300';
    if (nature.includes('凉') || nature.includes('寒')) return 'bg-blue-100 text-blue-800 border-blue-300';
    return 'bg-gray-100 text-gray-800 border-gray-300';
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (error || !formula) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>错误</AlertTitle>
          <AlertDescription>
            加载方剂信息失败，请稍后重试。
          </AlertDescription>
        </Alert>
        <Button 
          variant="outline" 
          onClick={() => navigate('/formulas')}
          className="mt-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          返回方剂列表
        </Button>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      {/* 返回按钮 */}
      <div className="mb-6">
        <Button variant="outline" onClick={() => navigate('/formulas')} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          返回方剂列表
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 左侧：方剂基本信息 */}
        <div className="lg:col-span-2">
          {/* 方剂基本信息卡片 */}
          <Card className="mb-6">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl md:text-3xl mb-1">{formula.name}</CardTitle>
                  <div className="text-sm text-muted-foreground">
                    <span>{formula.pinyin}</span>
                    {formula.englishName && (
                      <span className="ml-2">({formula.englishName})</span>
                    )}
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-300">
                    {formula.category}
                  </Badge>
                  {formula.isPremium && (
                    <Badge variant="secondary" className="bg-primary text-primary-foreground">
                      会员专享
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="flex flex-wrap gap-2 mb-4">
                <div className="flex items-center">
                  <FileText className="h-4 w-4 mr-1 text-gray-500" />
                  <span className="text-sm">出处：{formula.source}</span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <h3 className="text-sm font-medium flex items-center mb-2">
                    <Sparkles className="h-4 w-4 mr-1 text-amber-500" />
                    功效
                  </h3>
                  <p className="text-sm text-gray-700">{formula.functions}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium flex items-center mb-2">
                    <Activity className="h-4 w-4 mr-1 text-green-500" />
                    主治
                  </h3>
                  <p className="text-sm text-gray-700">{formula.indications}</p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-4">
                <Button
                  variant={isFavorited ? "default" : "outline"}
                  size="sm"
                  onClick={handleToggleFavorite}
                  className={isFavorited ? "bg-red-100 text-red-800 hover:bg-red-200 border-red-300" : ""}
                >
                  <Heart className={`h-4 w-4 mr-1 ${isFavorited ? "fill-red-800" : ""}`} />
                  {isFavorited ? "已收藏" : "收藏"}
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4 mr-1" />
                  分享
                </Button>
                <Button variant="outline" size="sm">
                  <Bookmark className="h-4 w-4 mr-1" />
                  保存到学习清单
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* 详细信息标签页 */}
          <Tabs defaultValue="composition" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="composition">组成</TabsTrigger>
              <TabsTrigger value="preparation">用法用量</TabsTrigger>
              <TabsTrigger value="analysis">方解</TabsTrigger>
              <TabsTrigger value="clinical">临床应用</TabsTrigger>
            </TabsList>
            
            <TabsContent value="composition" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center">
                    <ClipboardList className="h-5 w-5 mr-2 text-amber-600" />
                    方剂组成
                  </CardTitle>
                  <CardDescription>
                    总重量约 {calculateTotalWeight()} 克（不含药材单位非克的药材）
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>药材</TableHead>
                        <TableHead>用量</TableHead>
                        <TableHead className="hidden md:table-cell">性味</TableHead>
                        <TableHead className="hidden md:table-cell">归经</TableHead>
                        <TableHead className="hidden lg:table-cell">功效</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {formula.composition.map((item) => (
                        <TableRow key={item.herb.id}>
                          <TableCell className="font-medium">
                            <Link 
                              to={`/herbs/${item.herb.id}`}
                              className="text-primary hover:underline flex items-center"
                            >
                              {item.herb.name}
                              <ChevronRight className="h-4 w-4 inline-block ml-1" />
                            </Link>
                          </TableCell>
                          <TableCell>
                            {item.dosage} {item.unit}
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            <div className="flex flex-wrap gap-1">
                              <Badge 
                                variant="outline" 
                                className={cn("text-xs", getNatureColor(item.herb.nature))}
                              >
                                {item.herb.nature}
                              </Badge>
                              {item.herb.taste.split('、').map((taste, index) => (
                                <Badge 
                                  key={index} 
                                  variant="outline" 
                                  className="text-xs bg-gray-100 text-gray-800 border-gray-300"
                                >
                                  {taste}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            <span className={getMeridianColor(item.herb.meridian)}>
                              {item.herb.meridian}
                            </span>
                          </TableCell>
                          <TableCell className="hidden lg:table-cell text-sm text-gray-600">
                            <div className="line-clamp-2">
                              {item.herb.functions}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="preparation" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center">
                    <Beaker className="h-5 w-5 mr-2 text-blue-600" />
                    用法用量
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-base font-medium mb-2">制备方法</h3>
                      <p className="text-gray-700 whitespace-pre-line">{formula.preparation}</p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-base font-medium mb-2">服用方法</h3>
                      <p className="text-gray-700">{formula.dosage}</p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-base font-medium mb-2 flex items-center">
                        <AlertCircle className="h-4 w-4 mr-1 text-red-600" />
                        注意事项
                      </h3>
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>禁忌</AlertTitle>
                        <AlertDescription>
                          {formula.precautions}
                        </AlertDescription>
                      </Alert>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="analysis" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2 text-purple-600" />
                    方剂分析
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-base font-medium mb-2">君臣佐使</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="border border-dashed border-gray-300 rounded-lg p-4">
                          <h4 className="text-sm font-medium mb-2 text-red-700">君药</h4>
                          <div className="flex items-center">
                            <span className="font-medium mr-2">桂枝</span>
                            <span className="text-sm text-gray-600">发汗解表，温通经脉</span>
                          </div>
                        </div>
                        
                        <div className="border border-dashed border-gray-300 rounded-lg p-4">
                          <h4 className="text-sm font-medium mb-2 text-orange-700">臣药</h4>
                          <div className="flex items-center">
                            <span className="font-medium mr-2">白芍</span>
                            <span className="text-sm text-gray-600">养血敛阴，缓急止痛</span>
                          </div>
                        </div>
                        
                        <div className="border border-dashed border-gray-300 rounded-lg p-4">
                          <h4 className="text-sm font-medium mb-2 text-green-700">佐药</h4>
                          <div className="flex flex-col space-y-2">
                            <div className="flex items-center">
                              <span className="font-medium mr-2">生姜</span>
                              <span className="text-sm text-gray-600">解表散寒，温中止呕</span>
                            </div>
                            <div className="flex items-center">
                              <span className="font-medium mr-2">大枣</span>
                              <span className="text-sm text-gray-600">补脾和胃，调和营卫</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="border border-dashed border-gray-300 rounded-lg p-4">
                          <h4 className="text-sm font-medium mb-2 text-blue-700">使药</h4>
                          <div className="flex items-center">
                            <span className="font-medium mr-2">甘草</span>
                            <span className="text-sm text-gray-600">调和诸药</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-base font-medium mb-2">配伍特点</h3>
                      <p className="text-gray-700">
                        桂枝汤方中桂枝辛温，发汗解表；白芍酸寒，养血敛阴；二者相须为用，一散一收，共奏调和营卫之效。生姜辛温助桂枝解表，大枣甘温补中和营，甘草调和诸药。五药配伍，使卫气得解，营阴得复，营卫调和，汗出而解。
                      </p>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-base font-medium mb-2">药物配比</h3>
                      <div className="relative h-8 w-full overflow-hidden rounded-full bg-gray-200">
                        {formula.composition.map((item, index) => {
                          // 计算每种药材占的比例
                          const percentage = parseFloat(item.dosage) / calculateTotalWeight() * 100;
                          const colors = [
                            'bg-red-500', 'bg-blue-500', 'bg-green-500', 
                            'bg-yellow-500', 'bg-purple-500', 'bg-pink-500'
                          ];
                          
                          return (
                            <TooltipProvider key={item.herb.id}>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <div 
                                    className={`absolute top-0 h-full ${colors[index % colors.length]}`}
                                    style={{ 
                                      left: `${index === 0 ? 0 : formula.composition.slice(0, index).reduce((acc, curr) => acc + (parseFloat(curr.dosage) / calculateTotalWeight() * 100), 0)}%`,
                                      width: `${percentage}%` 
                                    }}
                                  ></div>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{item.herb.name}: {item.dosage}{item.unit} ({percentage.toFixed(1)}%)</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          );
                        })}
                      </div>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {formula.composition.map((item, index) => {
                          const colors = [
                            'bg-red-500', 'bg-blue-500', 'bg-green-500', 
                            'bg-yellow-500', 'bg-purple-500', 'bg-pink-500'
                          ];
                          
                          return (
                            <div key={item.herb.id} className="flex items-center">
                              <div className={`w-3 h-3 rounded-full ${colors[index % colors.length]} mr-1`}></div>
                              <span className="text-xs">{item.herb.name}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="clinical" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center">
                    <Activity className="h-5 w-5 mr-2 text-green-600" />
                    临床应用
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-base font-medium mb-2">传统应用</h3>
                      <p className="text-gray-700 whitespace-pre-line mb-4">
                        桂枝汤为伤寒论太阳病中风证的代表方剂，主要用于治疗外感风寒、营卫不和之证。临床上具有以下应用：
                      </p>
                      <ul className="list-disc pl-5 space-y-2 text-gray-700">
                        <li>治疗太阳中风证，表现为恶风、发热、汗出、脉浮缓等。</li>
                        <li>用于风湿痹痛，肢体酸楚，得温则舒者。</li>
                        <li>治疗营卫不和之证，表现为自汗、盗汗、畏风等。</li>
                      </ul>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-base font-medium mb-2">现代应用</h3>
                      <p className="text-gray-700">{formula.clinicalApplications}</p>
                      
                      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="border rounded-lg p-4">
                          <h4 className="text-sm font-medium mb-2 flex items-center">
                            <PlusCircle className="h-4 w-4 mr-1 text-green-600" />
                            适应证
                          </h4>
                          <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700">
                            <li>感冒初期，畏风、微热、汗出等</li>
                            <li>风湿关节痛，得温则舒</li>
                            <li>过敏性鼻炎、荨麻疹等过敏性疾病</li>
                            <li>自汗、盗汗症</li>
                          </ul>
                        </div>
                        
                        <div className="border rounded-lg p-4">
                          <h4 className="text-sm font-medium mb-2 flex items-center">
                            <MinusCircle className="h-4 w-4 mr-1 text-red-600" />
                            禁忌证
                          </h4>
                          <ul className="list-disc pl-5 space-y-1 text-sm text-gray-700">
                            <li>外感风热证</li>
                            <li>热病、高热不退者</li>
                            <li>阴虚内热、潮热盗汗者</li>
                            <li>表实证</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-base font-medium mb-2">方剂加减</h3>
                      <div className="space-y-3">
                        <div className="border-l-4 border-blue-500 pl-4 py-2">
                          <h4 className="text-sm font-medium mb-1">太阳中风兼表实者</h4>
                          <p className="text-sm text-gray-700">加葛根，制成桂枝加葛根汤</p>
                        </div>
                        
                        <div className="border-l-4 border-green-500 pl-4 py-2">
                          <h4 className="text-sm font-medium mb-1">太阳中风兼肌肉疼痛者</h4>
                          <p className="text-sm text-gray-700">加芍药，制成桂枝加芍药汤</p>
                        </div>
                        
                        <div className="border-l-4 border-purple-500 pl-4 py-2">
                          <h4 className="text-sm font-medium mb-1">太阳中风兼咳嗽气喘者</h4>
                          <p className="text-sm text-gray-700">加厚朴、杏仁，制成桂枝加厚朴杏子汤</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          {/* 评论区 */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-xl">评论与心得</CardTitle>
              <CardDescription>
                分享您对此方剂的心得体会和临床经验
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isAuthenticated ? (
                <div className="mb-6">
                  <Textarea
                    placeholder="分享您的使用体验和心得..."
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    className="min-h-[100px] mb-2"
                  />
                  <Button onClick={handleSubmitComment}>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    发表评论
                  </Button>
                </div>
              ) : (
                <div className="text-center py-4 mb-6 border border-dashed rounded-lg">
                  <p className="text-gray-500 mb-2">登录后参与讨论</p>
                  <Button onClick={() => navigate('/login')}>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    登录发表评论
                  </Button>
                </div>
              )}
              
              <div className="space-y-4">
                {comments.map((comment) => (
                  <div key={comment.id} className="border-b pb-4">
                    <div className="flex items-start space-x-3 mb-2">
                      <Avatar>
                        <AvatarImage src={comment.user.avatar} alt={comment.user.nickname} />
                        <AvatarFallback>{comment.user.nickname.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{comment.user.nickname}</div>
                        <div className="text-sm text-gray-500">
                          {new Date(comment.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <p className="text-gray-700 pl-10">{comment.content}</p>
                    <div className="flex items-center space-x-4 mt-2 pl-10">
                      <Button variant="ghost" size="sm" className="text-gray-500 h-8">
                        <Heart className="h-4 w-4 mr-1" />
                        {comment.likeCount}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-500 h-8">
                        <MessageSquare className="h-4 w-4 mr-1" />
                        回复
                      </Button>
                    </div>
                  </div>
                ))}
                
                {comments.length === 0 && (
                  <div className="text-center py-8">
                    <MessageSquare className="h-12 w-12 text-gray-300 mx-auto mb-2" />
                    <p className="text-gray-500">暂无评论</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* 右侧边栏 */}
        <div className="space-y-6">
          {/* 相关方剂 */}
          <Card>
            <CardHeader>
              <CardTitle>相关方剂</CardTitle>
              <CardDescription>
                与{formula.name}相关的其他方剂
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {relatedFormulas.map((related) => (
                <Link key={related.id} to={`/formulas/${related.id}`}>
                  <div className="flex items-center justify-between hover:bg-gray-50 p-2 rounded-lg transition-colors">
                    <div>
                      <h3 className="font-medium">{related.name}</h3>
                      <div className="text-xs text-gray-500 flex items-center mt-1">
                        <Badge variant="outline" className="mr-2 text-xs">{related.category}</Badge>
                        <span>{related.source}</span>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  </div>
                </Link>
              ))}
            </CardContent>
          </Card>
          
          {/* 学习工具 */}
          <Card>
            <CardHeader>
              <CardTitle>学习工具</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                <ClipboardList className="h-4 w-4 mr-2" />
                添加到学习清单
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Heart className="h-4 w-4 mr-2" />
                收藏方剂
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Share2 className="h-4 w-4 mr-2" />
                分享方剂
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Scale className="h-4 w-4 mr-2" />
                量计算器
              </Button>
            </CardContent>
          </Card>
          
          {/* 学习提示 */}
          <Card>
            <CardHeader>
              <CardTitle>方剂学习要点</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">1</span>
                  <span className="text-sm">掌握桂枝汤的组成及其配伍意义</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">2</span>
                  <span className="text-sm">理解营卫不和的病机特点</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">3</span>
                  <span className="text-sm">区分桂枝汤与麻黄汤的应用区别</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs mr-2 mt-0.5">4</span>
                  <span className="text-sm">熟悉桂枝汤在临床中的辨证运用</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default FormulaDetail;