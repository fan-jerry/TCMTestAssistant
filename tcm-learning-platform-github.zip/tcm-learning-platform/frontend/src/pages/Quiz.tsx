import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Play,
  Award,
  Clock,
  Target,
  BarChart3,
  Settings,
  BookOpen,
  Brain,
  TrendingUp,
  Users,
  Calendar,
  Filter,
  Search,
  ChevronRight,
  Star,
  Trophy,
  Zap,
  CheckCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface QuizCategory {
  id: number;
  name: string;
  description: string;
  parentId?: number;
  children?: QuizCategory[];
  questionCount: number;
}

interface QuizSetting {
  categoryIds: number[];
  questionCount: number;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'MIXED';
  timeLimit?: number;
  showAnswer: boolean;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
}

interface QuizHistory {
  id: number;
  categoryName: string;
  score: number;
  totalScore: number;
  percentage: number;
  completedAt: string;
  duration: number;
  questionCount: number;
}

const Quiz: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();

  const [categories, setCategories] = useState<QuizCategory[]>([]);
  const [quizHistory, setQuizHistory] = useState<QuizHistory[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('all');
  const [isSettingDialogOpen, setIsSettingDialogOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  // 测试配置
  const [quizSetting, setQuizSetting] = useState<QuizSetting>({
    categoryIds: [],
    questionCount: 10,
    difficulty: 'MIXED',
    timeLimit: undefined,
    showAnswer: true,
    shuffleQuestions: true,
    shuffleOptions: true,
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // 加载测试分类
      const response = await fetch('/data/quiz-questions.json');
      const data = await response.json();
      setCategories(data.categories);
      
      // 模拟加载历史记录
      const mockHistory: QuizHistory[] = [
        {
          id: 1,
          categoryName: '中医基础理论',
          score: 85,
          totalScore: 100,
          percentage: 85,
          completedAt: '2024-01-15T10:30:00Z',
          duration: 1200,
          questionCount: 20,
        },
        {
          id: 2,
          categoryName: '中药学',
          score: 78,
          totalScore: 90,
          percentage: 87,
          completedAt: '2024-01-14T14:20:00Z',
          duration: 900,
          questionCount: 15,
        },
        {
          id: 3,
          categoryName: '方剂学',
          score: 92,
          totalScore: 100,
          percentage: 92,
          completedAt: '2024-01-13T16:45:00Z',
          duration: 1500,
          questionCount: 25,
        },
      ];
      setQuizHistory(mockHistory);
    } catch (error) {
      console.error('加载数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const startQuiz = (categoryId?: number) => {
    // 允许未登录用户进行测试（游客模式）
    if (!isAuthenticated) {
      toast({
        title: "游客模式",
        description: "您正在以游客身份进行测试，测试结果不会保存",
      });
    }

    const selectedCategories = categoryId ? [categoryId] : quizSetting.categoryIds;
    
    if (selectedCategories.length === 0) {
      toast({
        variant: "destructive",
        title: "请选择测试分类",
        description: "至少选择一个测试分类才能开始测试",
      });
      return;
    }

    // 构建查询参数
    const params = new URLSearchParams({
      categories: selectedCategories.join(','),
      count: quizSetting.questionCount.toString(),
      difficulty: quizSetting.difficulty,
      showAnswer: quizSetting.showAnswer.toString(),
    });

    if (quizSetting.timeLimit) {
      params.append('timeLimit', quizSetting.timeLimit.toString());
    }

    navigate(`/quiz/test/new?${params.toString()}`);
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    return `${minutes} 分钟`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 页面标题 */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{t('quiz.title')}</h1>
        <p className="text-xl text-muted-foreground">
          在线中医知识测试评估
        </p>
      </div>

      {/* 主要内容区域 */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* 左侧主内容 */}
        <div className="lg:col-span-3 space-y-8">
          {/* 快速开始 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                快速开始测试
              </CardTitle>
              <CardDescription>
                选择测试分类，立即开始学习评估
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {categories.map((category) => (
                  <Card key={category.id} className="group hover:shadow-md transition-all duration-300 cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                            {category.name}
                          </h4>
                          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                            {category.description}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Target className="w-3 h-3" />
                            <span>{category.questionCount} 道题目</span>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => startQuiz(category.id)}
                          className="gap-2"
                        >
                          <Play className="w-3 h-3" />
                          开始
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 测试分类详情 */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  测试分类详情
                </CardTitle>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="搜索分类..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 w-48"
                    />
                  </div>
                  <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="难度" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部</SelectItem>
                      <SelectItem value="EASY">简单</SelectItem>
                      <SelectItem value="MEDIUM">中等</SelectItem>
                      <SelectItem value="HARD">困难</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {categories.map((category) => (
                  <div key={category.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-lg">{category.name}</h4>
                        <p className="text-muted-foreground">{category.description}</p>
                      </div>
                      <Badge variant="outline">{category.questionCount} 题</Badge>
                    </div>
                    
                    {category.children && category.children.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mt-4">
                        {category.children.map((subcategory) => (
                          <div key={subcategory.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                            <div>
                              <p className="font-medium text-sm">{subcategory.name}</p>
                              <p className="text-xs text-muted-foreground">{subcategory.questionCount} 题</p>
                            </div>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => startQuiz(subcategory.id)}
                            >
                              测试
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 历史记录 */}
          {isAuthenticated && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  测试历史
                </CardTitle>
                <CardDescription>
                  查看您的测试记录和成绩统计
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {quizHistory.map((record) => (
                    <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-12 h-12 rounded-full flex items-center justify-center text-white font-bold",
                          record.percentage >= 90 ? "bg-green-500" :
                          record.percentage >= 80 ? "bg-blue-500" :
                          record.percentage >= 70 ? "bg-yellow-500" : "bg-red-500"
                        )}>
                          {record.percentage}%
                        </div>
                        <div>
                          <h4 className="font-semibold">{record.categoryName}</h4>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Target className="w-3 h-3" />
                              {record.score}/{record.totalScore} 分
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {formatDuration(record.duration)}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {formatDate(record.completedAt)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {record.percentage >= 90 && <Trophy className="w-5 h-5 text-yellow-500" />}
                        {record.percentage >= 80 && <Star className="w-5 h-5 text-blue-500" />}
                        <Button variant="outline" size="sm">
                          查看详情
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* 右侧边栏 */}
        <div className="space-y-6">
          {/* 测试设置 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                测试设置
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-sm font-medium">题目数量</Label>
                <Select
                  value={quizSetting.questionCount.toString()}
                  onValueChange={(value) => setQuizSetting(prev => ({ ...prev, questionCount: parseInt(value) }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 题</SelectItem>
                    <SelectItem value="10">10 题</SelectItem>
                    <SelectItem value="15">15 题</SelectItem>
                    <SelectItem value="20">20 题</SelectItem>
                    <SelectItem value="30">30 题</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-sm font-medium">难度级别</Label>
                <Select
                  value={quizSetting.difficulty}
                  onValueChange={(value: QuizSetting['difficulty']) => setQuizSetting(prev => ({ ...prev, difficulty: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="EASY">简单</SelectItem>
                    <SelectItem value="MEDIUM">中等</SelectItem>
                    <SelectItem value="HARD">困难</SelectItem>
                    <SelectItem value="MIXED">混合</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium">显示答案解析</Label>
                <Switch
                  checked={quizSetting.showAnswer}
                  onCheckedChange={(checked) => setQuizSetting(prev => ({ ...prev, showAnswer: checked }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label className="text-sm font-medium">随机排列题目</Label>
                <Switch
                  checked={quizSetting.shuffleQuestions}
                  onCheckedChange={(checked) => setQuizSetting(prev => ({ ...prev, shuffleQuestions: checked }))}
                />
              </div>

              {/* 自定义测试 */}
              <Dialog open={isSettingDialogOpen} onOpenChange={setIsSettingDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full gap-2">
                    <Settings className="w-4 h-4" />
                    自定义测试
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>自定义测试设置</DialogTitle>
                    <DialogDescription>
                      配置您的专属测试参数
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div>
                      <Label className="text-sm font-medium mb-2 block">选择测试分类</Label>
                      <div className="space-y-2 max-h-40 overflow-y-auto">
                        {categories.map((category) => (
                          <div key={category.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`category-${category.id}`}
                              checked={quizSetting.categoryIds.includes(category.id)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setQuizSetting(prev => ({
                                    ...prev,
                                    categoryIds: [...prev.categoryIds, category.id]
                                  }));
                                } else {
                                  setQuizSetting(prev => ({
                                    ...prev,
                                    categoryIds: prev.categoryIds.filter(id => id !== category.id)
                                  }));
                                }
                              }}
                            />
                            <Label
                              htmlFor={`category-${category.id}`}
                              className="text-sm font-normal cursor-pointer"
                            >
                              {category.name}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium mb-2 block">
                        时间限制: {quizSetting.timeLimit || '无限制'}
                      </Label>
                      <Slider
                        value={[quizSetting.timeLimit || 0]}
                        onValueChange={(value) => setQuizSetting(prev => ({ 
                          ...prev, 
                          timeLimit: value[0] === 0 ? undefined : value[0] 
                        }))}
                        max={60}
                        min={0}
                        step={5}
                        className="w-full"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsSettingDialogOpen(false)}>
                      取消
                    </Button>
                    <Button 
                      onClick={() => {
                        setIsSettingDialogOpen(false);
                        startQuiz();
                      }}
                      disabled={quizSetting.categoryIds.length === 0}
                    >
                      开始测试
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>

          {/* 学习统计 */}
          {isAuthenticated && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  学习统计
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">12</div>
                    <div className="text-xs text-muted-foreground">已完成测试</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">85%</div>
                    <div className="text-xs text-muted-foreground">平均得分</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">240</div>
                    <div className="text-xs text-muted-foreground">答题总数</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">15h</div>
                    <div className="text-xs text-muted-foreground">学习时长</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* 推荐测试 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5" />
                推荐测试
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-3">
                <div className="p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">中医诊断学</p>
                      <p className="text-xs text-muted-foreground">基础理论强化</p>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
                <div className="p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">针灸学进阶</p>
                      <p className="text-xs text-muted-foreground">专业技能提升</p>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
                <div className="p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">中药炮制</p>
                      <p className="text-xs text-muted-foreground">实用技能</p>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Quiz;
