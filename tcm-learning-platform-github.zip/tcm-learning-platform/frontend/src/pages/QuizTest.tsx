import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  ArrowLeft,
  ArrowRight,
  Clock,
  Eye,
  EyeOff,
  CheckCircle,
  XCircle,
  AlertCircle,
  RotateCcw,
  Flag,
  Award,
  BookOpen,
  Target,
  TrendingUp,
  Settings,
  Pause,
  Play,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface Question {
  id: number;
  categoryId: number;
  content: string;
  type: 'SINGLE_CHOICE' | 'MULTIPLE_CHOICE' | 'TRUE_FALSE' | 'FILL_BLANK';
  options?: Array<{ id: string; content: string }>;
  correctAnswer: string;
  explanation?: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
  points: number;
  tags: string[];
}

interface QuizConfig {
  categoryIds: number[];
  questionCount: number;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'MIXED';
  timeLimit?: number;
  showAnswer: boolean;
  shuffleQuestions: boolean;
  shuffleOptions: boolean;
}

interface UserAnswer {
  questionId: number;
  answer: string;
  isCorrect: boolean;
  points: number;
  timeTaken: number;
}

const QuizTest: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();

  // 测试状态
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<UserAnswer[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState<string>('');
  const [showAnswer, setShowAnswer] = useState(false);
  const [testCompleted, setTestCompleted] = useState(false);
  const [testStarted, setTestStarted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  
  // 时间相关
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const [questionStartTime, setQuestionStartTime] = useState(Date.now());
  const [totalTestTime, setTotalTestTime] = useState(0);
  
  // 配置
  const [config, setConfig] = useState<QuizConfig>({
    categoryIds: [],
    questionCount: 10,
    difficulty: 'MIXED',
    timeLimit: undefined,
    showAnswer: true,
    shuffleQuestions: true,
    shuffleOptions: true,
  });

  // 加载测试配置和题目
  useEffect(() => {
    if (id) {
      loadQuizTest();
    }
  }, [id]);

  // 计时器
  useEffect(() => {
    if (testStarted && !testCompleted && !isPaused && timeRemaining !== null && timeRemaining > 0) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev === null || prev <= 1) {
            handleTimeUp();
            return 0;
          }
          return prev - 1;
        });
        setTotalTestTime(prev => prev + 1);
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [testStarted, testCompleted, isPaused, timeRemaining]);

  const loadQuizTest = async () => {
    try {
      // 从URL参数读取配置
      const categoryIds = searchParams.get('categories')?.split(',').map(Number) || [1];
      const questionCount = parseInt(searchParams.get('count') || '10');
      const difficulty = (searchParams.get('difficulty') || 'MIXED') as QuizConfig['difficulty'];
      const timeLimit = searchParams.get('timeLimit') ? parseInt(searchParams.get('timeLimit')!) : undefined;
      const showAnswer = searchParams.get('showAnswer') !== 'false';
      
      const testConfig: QuizConfig = {
        categoryIds,
        questionCount,
        difficulty,
        timeLimit,
        showAnswer,
        shuffleQuestions: true,
        shuffleOptions: true,
      };
      
      setConfig(testConfig);
      
      // 加载题目
      const response = await fetch('/data/quiz-questions.json');
      const data = await response.json();
      
      let filteredQuestions = data.questions.filter((q: Question) => 
        categoryIds.includes(q.categoryId)
      );
      
      if (difficulty !== 'MIXED') {
        filteredQuestions = filteredQuestions.filter((q: Question) => q.difficulty === difficulty);
      }
      
      // 随机排序并限制数量
      if (testConfig.shuffleQuestions) {
        filteredQuestions = filteredQuestions.sort(() => Math.random() - 0.5);
      }
      
      filteredQuestions = filteredQuestions.slice(0, questionCount);
      
      // 打乱选项顺序
      if (testConfig.shuffleOptions) {
        filteredQuestions = filteredQuestions.map((q: Question) => ({
          ...q,
          options: q.options?.sort(() => Math.random() - 0.5)
        }));
      }
      
      setQuestions(filteredQuestions);
      
      if (timeLimit) {
        setTimeRemaining(timeLimit * 60); // 转换为秒
      }
    } catch (error) {
      console.error('加载测试失败:', error);
      toast({
        variant: "destructive",
        title: "加载失败",
        description: "无法加载测试题目，请稍后重试",
      });
    }
  };

  const startTest = () => {
    setTestStarted(true);
    setQuestionStartTime(Date.now());
  };

  const handleTimeUp = () => {
    toast({
      variant: "destructive",
      title: "时间到！",
      description: "测试时间已结束，系统将自动提交",
    });
    finishTest();
  };

  const submitAnswer = () => {
    const currentQuestion = questions[currentQuestionIndex];
    const timeTaken = Math.floor((Date.now() - questionStartTime) / 1000);
    
    let isCorrect = false;
    let points = 0;
    
    if (currentQuestion.type === 'MULTIPLE_CHOICE') {
      const selectedAnswers = currentAnswer.split(',').sort();
      const correctAnswers = currentQuestion.correctAnswer.split(',').sort();
      isCorrect = JSON.stringify(selectedAnswers) === JSON.stringify(correctAnswers);
    } else {
      isCorrect = currentAnswer.toLowerCase().trim() === currentQuestion.correctAnswer.toLowerCase().trim();
    }
    
    if (isCorrect) {
      points = currentQuestion.points;
    }
    
    const userAnswer: UserAnswer = {
      questionId: currentQuestion.id,
      answer: currentAnswer,
      isCorrect,
      points,
      timeTaken,
    };
    
    setUserAnswers(prev => [...prev, userAnswer]);
    
    if (config.showAnswer) {
      setShowAnswer(true);
    } else {
      nextQuestion();
    }
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setCurrentAnswer('');
      setShowAnswer(false);
      setQuestionStartTime(Date.now());
    } else {
      finishTest();
    }
  };

  const previousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
      setCurrentAnswer(userAnswers[currentQuestionIndex - 1]?.answer || '');
      setShowAnswer(false);
    }
  };

  const finishTest = () => {
    setTestCompleted(true);
    
    // 保存测试结果
    const score = userAnswers.reduce((total, answer) => total + answer.points, 0);
    const totalPoints = questions.reduce((total, question) => total + question.points, 0);
    const percentage = Math.round((score / totalPoints) * 100);
    
    toast({
      title: "测试完成！",
      description: `您的得分：${score}/${totalPoints} (${percentage}%)`,
    });
  };

  const resetTest = () => {
    setCurrentQuestionIndex(0);
    setUserAnswers([]);
    setCurrentAnswer('');
    setShowAnswer(false);
    setTestCompleted(false);
    setTestStarted(false);
    setIsPaused(false);
    setTotalTestTime(0);
    if (config.timeLimit) {
      setTimeRemaining(config.timeLimit * 60);
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
  const score = userAnswers.reduce((total, answer) => total + answer.points, 0);
  const totalPoints = questions.reduce((total, question) => total + question.points, 0);

  // 如果还没开始测试，显示测试说明
  if (!testStarted && !testCompleted && questions.length > 0) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate('/quiz')}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            返回测试列表
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <BookOpen className="w-6 h-6" />
              测试说明
            </CardTitle>
            <CardDescription>
              开始测试前，请仔细阅读以下说明
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  <span className="font-medium">题目数量: {questions.length} 题</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-primary" />
                  <span className="font-medium">总分: {totalPoints} 分</span>
                </div>
                {config.timeLimit && (
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-primary" />
                    <span className="font-medium">时间限制: {config.timeLimit} 分钟</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span className="font-medium">难度: {config.difficulty === 'MIXED' ? '混合' : config.difficulty}</span>
                </div>
              </div>

              <div className="space-y-4">
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>注意事项</AlertTitle>
                  <AlertDescription className="mt-2 space-y-1 text-sm">
                    <p>• 请确保网络连接稳定</p>
                    <p>• 每题只能提交一次答案</p>
                    {config.timeLimit && <p>• 时间到将自动提交</p>}
                    <p>• 建议在安静环境中完成测试</p>
                  </AlertDescription>
                </Alert>
              </div>
            </div>

            <Separator />

            <div className="text-center">
              <Button size="lg" onClick={startTest} className="gap-2">
                <Play className="w-5 h-5" />
                开始测试
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // 测试完成结果页面
  if (testCompleted) {
    const percentage = Math.round((score / totalPoints) * 100);
    const correctCount = userAnswers.filter(answer => answer.isCorrect).length;
    const avgTimePerQuestion = Math.round(totalTestTime / questions.length);

    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-3xl flex items-center justify-center gap-2">
              <Award className="w-8 h-8 text-primary" />
              测试完成
            </CardTitle>
            <CardDescription>
              恭喜您完成了本次测试！
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* 成绩概览 */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-primary">{percentage}%</div>
                  <div className="text-sm text-muted-foreground">总得分</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold">{correctCount}/{questions.length}</div>
                  <div className="text-sm text-muted-foreground">正确题数</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold">{score}</div>
                  <div className="text-sm text-muted-foreground">获得分数</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold">{formatTime(avgTimePerQuestion)}</div>
                  <div className="text-sm text-muted-foreground">平均用时</div>
                </CardContent>
              </Card>
            </div>

            {/* 详细分析 */}
            <Tabs defaultValue="summary" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="summary">总结分析</TabsTrigger>
                <TabsTrigger value="details">详细结果</TabsTrigger>
                <TabsTrigger value="suggestions">学习建议</TabsTrigger>
              </TabsList>

              <TabsContent value="summary" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {['EASY', 'MEDIUM', 'HARD'].map(difficulty => {
                    const difficultyQuestions = questions.filter(q => q.difficulty === difficulty);
                    const difficultyCorrect = userAnswers.filter(answer => {
                      const question = questions.find(q => q.id === answer.questionId);
                      return question?.difficulty === difficulty && answer.isCorrect;
                    }).length;
                    
                    if (difficultyQuestions.length === 0) return null;
                    
                    const difficultyPercentage = Math.round((difficultyCorrect / difficultyQuestions.length) * 100);
                    
                    return (
                      <Card key={difficulty}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium">
                              {difficulty === 'EASY' ? '简单' : difficulty === 'MEDIUM' ? '中等' : '困难'}
                            </span>
                            <Badge variant={difficultyPercentage >= 80 ? 'default' : difficultyPercentage >= 60 ? 'secondary' : 'destructive'}>
                              {difficultyPercentage}%
                            </Badge>
                          </div>
                          <Progress value={difficultyPercentage} className="mb-2" />
                          <div className="text-xs text-muted-foreground">
                            {difficultyCorrect}/{difficultyQuestions.length} 题正确
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              <TabsContent value="details" className="space-y-4">
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {questions.map((question, index) => {
                    const userAnswer = userAnswers.find(answer => answer.questionId === question.id);
                    return (
                      <Card key={question.id}>
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div className={cn(
                              "w-6 h-6 rounded-full flex items-center justify-center text-white text-sm",
                              userAnswer?.isCorrect ? "bg-green-500" : "bg-red-500"
                            )}>
                              {userAnswer?.isCorrect ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                            </div>
                            <div className="flex-1">
                              <p className="font-medium mb-2">
                                第 {index + 1} 题: {question.content}
                              </p>
                              <div className="text-sm space-y-1">
                                <p className="text-muted-foreground">您的答案: {userAnswer?.answer || '未作答'}</p>
                                <p className="text-green-600">正确答案: {question.correctAnswer}</p>
                                {question.explanation && (
                                  <p className="text-blue-600">解析: {question.explanation}</p>
                                )}
                              </div>
                            </div>
                            <div className="text-right text-sm">
                              <div className={cn("font-medium", userAnswer?.isCorrect ? "text-green-600" : "text-red-600")}>
                                {userAnswer?.points || 0}/{question.points}分
                              </div>
                              <div className="text-muted-foreground">
                                {formatTime(userAnswer?.timeTaken || 0)}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              <TabsContent value="suggestions" className="space-y-4">
                <Alert>
                  <BookOpen className="h-4 w-4" />
                  <AlertTitle>学习建议</AlertTitle>
                  <AlertDescription className="mt-2 space-y-2">
                    {percentage >= 90 && (
                      <p>恭喜！您的成绩优秀，对相关知识掌握扎实。建议继续保持，可以尝试更高难度的测试。</p>
                    )}
                    {percentage >= 70 && percentage < 90 && (
                      <p>成绩良好！还有提升空间，建议重点复习答错的知识点，加强薄弱环节的学习。</p>
                    )}
                    {percentage >= 60 && percentage < 70 && (
                      <p>成绩及格，但需要加强学习。建议系统性地复习相关理论知识，多做练习题巩固。</p>
                    )}
                    {percentage < 60 && (
                      <p>建议重新学习相关知识点，可以从基础理论开始，循序渐进地掌握核心概念。</p>
                    )}
                  </AlertDescription>
                </Alert>
              </TabsContent>
            </Tabs>

            <div className="flex justify-center gap-4">
              <Button onClick={resetTest} variant="outline" className="gap-2">
                <RotateCcw className="w-4 h-4" />
                重新测试
              </Button>
              <Button onClick={() => navigate('/quiz')} className="gap-2">
                <BookOpen className="w-4 h-4" />
                返回测试中心
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // 正在进行的测试
  if (!currentQuestion) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* 顶部进度条和控制 */}
      <div className="mb-6 space-y-4">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => navigate('/quiz')}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            退出测试
          </Button>
          <div className="flex items-center gap-4">
            {timeRemaining !== null && (
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span className={cn("font-mono", timeRemaining < 300 && "text-red-500")}>
                  {formatTime(timeRemaining)}
                </span>
              </div>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsPaused(!isPaused)}
              className="gap-2"
            >
              {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              {isPaused ? '继续' : '暂停'}
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>进度: {currentQuestionIndex + 1} / {questions.length}</span>
            <span>得分: {score} / {totalPoints}</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </div>

      {/* 题目卡片 */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline">第 {currentQuestionIndex + 1} 题</Badge>
              <Badge variant={
                currentQuestion.difficulty === 'EASY' ? 'secondary' :
                currentQuestion.difficulty === 'MEDIUM' ? 'default' : 'destructive'
              }>
                {currentQuestion.difficulty === 'EASY' ? '简单' : 
                 currentQuestion.difficulty === 'MEDIUM' ? '中等' : '困难'}
              </Badge>
              <Badge variant="outline">{currentQuestion.points} 分</Badge>
            </div>
            {config.showAnswer && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAnswer(!showAnswer)}
                className="gap-2"
              >
                {showAnswer ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                {showAnswer ? '隐藏答案' : '查看答案'}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* 题目内容 */}
          <div>
            <h3 className="text-lg font-medium mb-4">{currentQuestion.content}</h3>
          </div>

          {/* 答题区域 */}
          <div className="space-y-4">
            {currentQuestion.type === 'SINGLE_CHOICE' && (
              <div className="space-y-2">
                {currentQuestion.options?.map((option) => (
                  <label
                    key={option.id}
                    className={cn(
                      "flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors",
                      currentAnswer === option.id && "border-primary bg-primary/5",
                      showAnswer && currentQuestion.correctAnswer === option.id && "border-green-500 bg-green-50",
                      showAnswer && currentAnswer === option.id && currentQuestion.correctAnswer !== option.id && "border-red-500 bg-red-50"
                    )}
                  >
                    <input
                      type="radio"
                      name="answer"
                      value={option.id}
                      checked={currentAnswer === option.id}
                      onChange={(e) => setCurrentAnswer(e.target.value)}
                      disabled={showAnswer}
                      className="text-primary"
                    />
                    <span className="flex-1">{option.content}</span>
                    {showAnswer && currentQuestion.correctAnswer === option.id && (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    )}
                  </label>
                ))}
              </div>
            )}

            {currentQuestion.type === 'MULTIPLE_CHOICE' && (
              <div className="space-y-2">
                {currentQuestion.options?.map((option) => {
                  const selectedAnswers = currentAnswer.split(',').filter(Boolean);
                  const isSelected = selectedAnswers.includes(option.id);
                  const correctAnswers = currentQuestion.correctAnswer.split(',');
                  
                  return (
                    <label
                      key={option.id}
                      className={cn(
                        "flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors",
                        isSelected && "border-primary bg-primary/5",
                        showAnswer && correctAnswers.includes(option.id) && "border-green-500 bg-green-50",
                        showAnswer && isSelected && !correctAnswers.includes(option.id) && "border-red-500 bg-red-50"
                      )}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setCurrentAnswer(prev => prev ? `${prev},${option.id}` : option.id);
                          } else {
                            setCurrentAnswer(prev => 
                              prev.split(',').filter(id => id !== option.id).join(',')
                            );
                          }
                        }}
                        disabled={showAnswer}
                        className="text-primary"
                      />
                      <span className="flex-1">{option.content}</span>
                      {showAnswer && correctAnswers.includes(option.id) && (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      )}
                    </label>
                  );
                })}
              </div>
            )}

            {currentQuestion.type === 'TRUE_FALSE' && (
              <div className="space-y-2">
                {['正确', '错误'].map((option, index) => {
                  const value = index === 0 ? 'A' : 'B';
                  return (
                    <label
                      key={value}
                      className={cn(
                        "flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-colors",
                        currentAnswer === value && "border-primary bg-primary/5",
                        showAnswer && currentQuestion.correctAnswer === value && "border-green-500 bg-green-50",
                        showAnswer && currentAnswer === value && currentQuestion.correctAnswer !== value && "border-red-500 bg-red-50"
                      )}
                    >
                      <input
                        type="radio"
                        name="answer"
                        value={value}
                        checked={currentAnswer === value}
                        onChange={(e) => setCurrentAnswer(e.target.value)}
                        disabled={showAnswer}
                        className="text-primary"
                      />
                      <span className="flex-1">{option}</span>
                      {showAnswer && currentQuestion.correctAnswer === value && (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      )}
                    </label>
                  );
                })}
              </div>
            )}

            {currentQuestion.type === 'FILL_BLANK' && (
              <div>
                <input
                  type="text"
                  value={currentAnswer}
                  onChange={(e) => setCurrentAnswer(e.target.value)}
                  disabled={showAnswer}
                  placeholder="请输入您的答案..."
                  className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            )}
          </div>

          {/* 答案解析 */}
          {showAnswer && currentQuestion.explanation && (
            <Alert>
              <BookOpen className="h-4 w-4" />
              <AlertTitle>答案解析</AlertTitle>
              <AlertDescription className="mt-2">
                <div className="space-y-2">
                  <p><strong>正确答案:</strong> {currentQuestion.correctAnswer}</p>
                  <p><strong>解析:</strong> {currentQuestion.explanation}</p>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* 操作按钮 */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={previousQuestion}
              disabled={currentQuestionIndex === 0}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              上一题
            </Button>

            <div className="space-x-2">
              {!showAnswer && (
                <Button
                  onClick={submitAnswer}
                  disabled={!currentAnswer.trim() || isPaused}
                  className="gap-2"
                >
                  <Flag className="w-4 h-4" />
                  提交答案
                </Button>
              )}

              {showAnswer && (
                <Button
                  onClick={nextQuestion}
                  className="gap-2"
                >
                  {currentQuestionIndex === questions.length - 1 ? (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      完成测试
                    </>
                  ) : (
                    <>
                      <ArrowRight className="w-4 h-4" />
                      下一题
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default QuizTest;
