import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  BookOpen,
  User,
  Calendar,
  Clock,
  Star,
  Eye,
  Heart,
  Download,
  Play,
  MessageCircle,
  Share2,
  ArrowLeft,
  Bookmark,
  List,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';

const TheoryDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [isFavorited, setIsFavorited] = useState(false);
  const [readingProgress, setReadingProgress] = useState(0);

  // 模拟理论详情数据
  const theory = {
    id: 1,
    title: '黄帝内经',
    subtitle: '素问 · 灵枢',
    author: '黄帝',
    dynasty: '先秦',
    cover: '/images/theories/huangdi-neijing.jpg',
    summary: '《黄帝内经》是中医理论的奠基之作，分为《素问》和《灵枢》两部分。《素问》主要论述中医的基本理论，包括阴阳五行、脏腑经络、病因病机、诊断治疗等内容；《灵枢》则重点阐述针灸学理论。全书确立了中医学的理论基础，对后世中医学发展产生了深远影响。',
    content: `《黄帝内经》是中国最早的医学典籍，传统医学四大经典著作之一。《黄帝内经》奠定了中医学的理论基础，从整体观念出发，认为人体是一个有机的整体，人与自然环境是相互统一的整体。

本书分为《素问》和《灵枢》两部分，各八十一篇。《素问》重在论述中医的基本理论，包括阴阳五行、脏腑学说、经络学说、病因病机、四诊方法、治疗法则等；《灵枢》重点论述针灸学理论，包括经络穴位、针刺方法、针刺适应症等。

全书运用阴阳五行学说，论证了人体的生理、病理，确立了中医学辨证论治的基本原则，是中医理论的源头活水。`,
    category: 'classic',
    difficulty: 'ADVANCED',
    readingTime: 720,
    viewCount: 12580,
    likeCount: 892,
    chapters: [
      { id: 1, title: '上古天真论篇第一', content: '昔在黄帝，生而神灵，弱而能言，幼而徇齐，长而敦敏，成而登天。' },
      { id: 2, title: '四气调神大论篇第二', content: '春三月，此谓发陈，天地俱生，万物以荣。' },
      { id: 3, title: '生气通天论篇第三', content: '黄帝曰：夫自古通天者，生之本，本于阴阳。' },
      { id: 4, title: '金匮真言论篇第四', content: '黄帝问曰：天有八风，经有五风，何谓？' },
      { id: 5, title: '阴阳应象大论篇第五', content: '黄帝曰：阴阳者，天地之道也，万物之纲纪。' },
    ],
    isPremium: false,
    isPublished: true,
    publishedAt: '2024-01-01',
    tags: ['经典', '基础理论', '阴阳五行'],
    annotations: [
      {
        id: 1,
        text: '阴阳者，天地之道也',
        explanation: '阴阳是宇宙万物运行的根本规律，是中医理论的核心概念。'
      },
      {
        id: 2,
        text: '五行相生相克',
        explanation: '五行学说认为木、火、土、金、水五种元素相互生成、相互制约。'
      }
    ]
  };

  const handleToggleFavorite = () => {
    setIsFavorited(!isFavorited);
  };

  const handleStartReading = () => {
    navigate(`/theory/${id}/read`);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 返回按钮 */}
      <div className="mb-6">
        <Button variant="ghost" onClick={() => navigate('/theory')} className="mb-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          返回理论列表
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 主要内容 */}
        <div className="lg:col-span-2">
          {/* 书籍信息卡片 */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                {/* 封面 */}
                <div className="relative mx-auto md:mx-0">
                  <div className="w-48 h-64 bg-gradient-to-b from-amber-50 to-amber-100 rounded-lg border-2 border-amber-200 flex items-center justify-center shadow-lg">
                    {theory.cover ? (
                      <img src={theory.cover} alt={theory.title} className="w-full h-full object-cover rounded-lg" />
                    ) : (
                      <BookOpen className="h-16 w-16 text-amber-600" />
                    )}
                  </div>
                  {theory.isPremium && (
                    <Badge variant="secondary" className="absolute -top-2 -right-2 bg-amber-500 text-white">
                      会员专享
                    </Badge>
                  )}
                </div>

                {/* 书籍详情 */}
                <div className="flex-1">
                  <div className="mb-4">
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">{theory.title}</h1>
                    {theory.subtitle && (
                      <p className="text-lg text-gray-600 mb-3">{theory.subtitle}</p>
                    )}
                    
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-4">
                      <span className="flex items-center">
                        <User className="h-4 w-4 mr-1" />
                        {theory.author}
                      </span>
                      <span className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {theory.dynasty}
                      </span>
                      <span className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {Math.floor(theory.readingTime / 60)}小时阅读
                      </span>
                      <Badge variant="outline">
                        {theory.difficulty === 'BEGINNER' ? '入门' : 
                         theory.difficulty === 'INTERMEDIATE' ? '进阶' : '高级'}
                      </Badge>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {theory.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="bg-amber-100 text-amber-800">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center gap-6 text-sm text-gray-500 mb-6">
                      <span className="flex items-center">
                        <Eye className="h-4 w-4 mr-1" />
                        {theory.viewCount.toLocaleString()} 阅读
                      </span>
                      <span className="flex items-center">
                        <Heart className="h-4 w-4 mr-1" />
                        {theory.likeCount} 点赞
                      </span>
                      <span className="flex items-center">
                        <BookOpen className="h-4 w-4 mr-1" />
                        {theory.chapters.length} 章节
                      </span>
                    </div>
                  </div>

                  {/* 操作按钮 */}
                  <div className="flex flex-wrap gap-3">
                    <Button onClick={handleStartReading} size="lg" className="flex-1 md:flex-none">
                      <Play className="h-4 w-4 mr-2" />
                      开始阅读
                    </Button>
                    
                    {isAuthenticated && (
                      <>
                        <Button 
                          variant="outline" 
                          onClick={handleToggleFavorite}
                          className={isFavorited ? 'text-red-600 border-red-600' : ''}
                        >
                          <Heart className={`h-4 w-4 mr-2 ${isFavorited ? 'fill-current' : ''}`} />
                          {isFavorited ? '已收藏' : '收藏'}
                        </Button>
                        
                        <Button variant="outline">
                          <Bookmark className="h-4 w-4 mr-2" />
                          添加书签
                        </Button>
                      </>
                    )}
                    
                    <Button variant="outline">
                      <Share2 className="h-4 w-4 mr-2" />
                      分享
                    </Button>
                    
                    <Button variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      下载PDF
                    </Button>
                  </div>

                  {/* 阅读进度 */}
                  {isAuthenticated && readingProgress > 0 && (
                    <div className="mt-6 p-4 bg-amber-50 rounded-lg border border-amber-200">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-amber-800">阅读进度</span>
                        <span className="text-sm text-amber-600">{readingProgress}%</span>
                      </div>
                      <Progress value={readingProgress} className="mb-2" />
                      <Button variant="outline" size="sm" onClick={handleStartReading}>
                        继续阅读
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 详细内容 */}
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">概述</TabsTrigger>
              <TabsTrigger value="chapters">章节目录</TabsTrigger>
              <TabsTrigger value="annotations">注释说明</TabsTrigger>
              <TabsTrigger value="comments">评论讨论</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>内容概述</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-sm max-w-none">
                    <p className="text-gray-700 leading-relaxed mb-4">{theory.summary}</p>
                    <div className="whitespace-pre-line text-gray-700 leading-relaxed">
                      {theory.content}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chapters" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>章节目录</CardTitle>
                  <CardDescription>
                    共 {theory.chapters.length} 章节
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {theory.chapters.map((chapter, index) => (
                      <div key={chapter.id} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg border border-gray-100">
                        <div className="flex items-center space-x-3">
                          <span className="text-sm text-gray-500 font-medium">第{index + 1}章</span>
                          <span className="font-medium">{chapter.title}</span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => navigate(`/theory/${id}/read?chapter=${chapter.id}`)}
                        >
                          阅读
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="annotations" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>注释说明</CardTitle>
                  <CardDescription>
                    重要术语和概念解释
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {theory.annotations.map((annotation) => (
                      <div key={annotation.id} className="p-4 border border-amber-200 rounded-lg bg-amber-50">
                        <h4 className="font-medium text-amber-800 mb-2">"{annotation.text}"</h4>
                        <p className="text-sm text-gray-700">{annotation.explanation}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="comments" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>评论讨论</CardTitle>
                  <CardDescription>
                    与其他学习者交流心得体会
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isAuthenticated ? (
                    <div className="text-center py-8">
                      <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500">评论功能开发中...</p>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500 mb-4">登录后可参与讨论</p>
                      <Button onClick={() => navigate('/login')}>立即登录</Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* 侧边栏 */}
        <div className="space-y-6">
          {/* 快速导航 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">快速导航</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start" onClick={handleStartReading}>
                <BookOpen className="h-4 w-4 mr-2" />
                在线阅读
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Download className="h-4 w-4 mr-2" />
                下载离线版
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <List className="h-4 w-4 mr-2" />
                学习笔记
              </Button>
            </CardContent>
          </Card>

          {/* 学习统计 */}
          {isAuthenticated && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">学习统计</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600">阅读进度</span>
                    <span className="text-sm font-medium">{readingProgress}%</span>
                  </div>
                  <Progress value={readingProgress} />
                </div>
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">5</div>
                    <div className="text-xs text-gray-500">已读章节</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-primary">12</div>
                    <div className="text-xs text-gray-500">学习笔记</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* 相关推荐 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">相关推荐</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer">
                <div className="w-12 h-16 bg-gradient-to-b from-amber-50 to-amber-100 rounded border border-amber-200 flex items-center justify-center">
                  <BookOpen className="h-4 w-4 text-amber-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-gray-800 truncate">伤寒论</h4>
                  <p className="text-xs text-gray-500">张仲景</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer">
                <div className="w-12 h-16 bg-gradient-to-b from-amber-50 to-amber-100 rounded border border-amber-200 flex items-center justify-center">
                  <BookOpen className="h-4 w-4 text-amber-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-gray-800 truncate">本草纲目</h4>
                  <p className="text-xs text-gray-500">李时珍</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TheoryDetail;
