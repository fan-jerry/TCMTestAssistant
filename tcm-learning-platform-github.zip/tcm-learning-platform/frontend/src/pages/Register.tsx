import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Eye,
  EyeOff,
  UserPlus,
  Mail,
  Lock,
  User,
  Phone,
  ArrowLeft,
  BookOpen,
  CheckCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useAuth } from '@/contexts/AuthContext';
import { isValidEmail, isValidPhone } from '@/lib/utils';
import { toast } from 'sonner';

const registerSchema = z.object({
  username: z
    .string()
    .min(3, '用户名至少3个字符')
    .max(20, '用户名最多20个字符')
    .regex(/^[a-zA-Z0-9_]+$/, '用户名只能包含字母、数字和下划线'),
  email: z
    .string()
    .min(1, '请输入邮箱地址')
    .refine(isValidEmail, '邮箱格式不正确'),
  password: z
    .string()
    .min(8, '密码至少8个字符')
    .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, '密码必须包含大小写字母和数字'),
  confirmPassword: z.string().min(1, '请确认密码'),
  phone: z
    .string()
    .optional()
    .refine((phone) => !phone || isValidPhone(phone), '手机号格式不正确'),
  nickname: z
    .string()
    .min(2, '昵称至少2个字符')
    .max(20, '昵称最多20个字符'),
  agreeTerms: z.boolean().refine(val => val, '请同意服务条款和隐私政策'),
}).refine((data) => data.password === data.confirmPassword, {
  message: '两次输入的密码不一致',
  path: ['confirmPassword'],
});

type RegisterFormData = z.infer<typeof registerSchema>;

const Register: React.FC = () => {
  const { t } = useTranslation();
  const { register: registerUser } = useAuth();
  const navigate = useNavigate();
  
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      agreeTerms: false,
    },
  });

  const onSubmit = async (data: RegisterFormData) => {
    try {
      setIsLoading(true);
      setError(null);
      
      await registerUser({
        username: data.username,
        email: data.email,
        password: data.password,
        confirmPassword: data.confirmPassword,
        phone: data.phone,
        nickname: data.nickname,
      });
      
      toast.success('注册成功！请查看邮箱进行验证。');
      navigate('/login', { 
        state: { 
          message: '注册成功！请使用您的账号密码登录。' 
        }
      });
    } catch (error: any) {
      setError(error.message || '注册失败，请重试');
    } finally {
      setIsLoading(false);
    }
  };

  const passwordStrength = watch('password');
  const getPasswordStrengthColor = () => {
    if (!passwordStrength) return '';
    if (passwordStrength.length < 6) return 'bg-red-500';
    if (passwordStrength.length < 8) return 'bg-yellow-500';
    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(passwordStrength)) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getPasswordStrengthText = () => {
    if (!passwordStrength) return '';
    if (passwordStrength.length < 6) return '弱';
    if (passwordStrength.length < 8) return '中';
    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(passwordStrength)) return '中';
    return '强';
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-50 p-4">
      <div className="w-full max-w-4xl grid lg:grid-cols-2 gap-8 lg:gap-0">
        {/* Left Side - Branding */}
        <div className="hidden lg:flex flex-col justify-center p-12 bg-gradient-to-br from-green-600 to-emerald-600 text-white rounded-l-lg">
          <div className="max-w-md">
            <div className="flex items-center space-x-2 mb-8">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-white text-green-600">
                <BookOpen className="h-6 w-6" />
              </div>
              <span className="text-2xl font-bold">中医学习平台</span>
            </div>
            
            <h1 className="text-3xl font-bold mb-4">
              开始您的中医学习之旅
            </h1>
            
            <p className="text-lg opacity-90 mb-8">
              加入我们的学习社区，与数万名学员一起深入探索传统中医药的智慧与奥秘。
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20">
                  <CheckCircle className="h-4 w-4" />
                </div>
                <span>免费访问基础中医知识</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20">
                  <CheckCircle className="h-4 w-4" />
                </div>
                <span>个性化学习进度跟踪</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20">
                  <CheckCircle className="h-4 w-4" />
                </div>
                <span>专业社区交流讨论</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20">
                  <CheckCircle className="h-4 w-4" />
                </div>
                <span>在线测试评估系统</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Register Form */}
        <div className="flex flex-col justify-center p-8 lg:p-12 bg-white lg:rounded-r-lg shadow-xl">
          <div className="w-full max-w-md mx-auto">
            {/* Mobile Header */}
            <div className="lg:hidden text-center mb-8">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
                  <BookOpen className="h-4 w-4" />
                </div>
                <span className="text-xl font-bold text-primary">中医学习平台</span>
              </div>
              <h1 className="text-2xl font-bold">注册新账号</h1>
            </div>

            <Card className="border-0 shadow-none lg:border lg:shadow-sm">
              <CardHeader className="space-y-1 pb-6">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl">{t('auth.registerTitle')}</CardTitle>
                  <Button variant="ghost" size="sm" asChild>
                    <Link to="/">
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      返回首页
                    </Link>
                  </Button>
                </div>
                <CardDescription>
                  填写信息创建您的学习账号
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-6">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  {/* Username Field */}
                  <div className="space-y-2">
                    <Label htmlFor="username">{t('auth.username')}</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="username"
                        type="text"
                        placeholder="输入用户名"
                        className="pl-10"
                        {...register('username')}
                        autoComplete="username"
                      />
                    </div>
                    {errors.username && (
                      <p className="text-sm text-destructive">{errors.username.message}</p>
                    )}
                  </div>

                  {/* Email Field */}
                  <div className="space-y-2">
                    <Label htmlFor="email">{t('auth.email')}</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="输入邮箱地址"
                        className="pl-10"
                        {...register('email')}
                        autoComplete="email"
                      />
                    </div>
                    {errors.email && (
                      <p className="text-sm text-destructive">{errors.email.message}</p>
                    )}
                  </div>

                  {/* Password Field */}
                  <div className="space-y-2">
                    <Label htmlFor="password">{t('auth.password')}</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="输入密码"
                        className="pl-10 pr-10"
                        {...register('password')}
                        autoComplete="new-password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    {passwordStrength && (
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2 text-xs">
                          <span>密码强度:</span>
                          <div className="flex-1 h-1 bg-gray-200 rounded">
                            <div 
                              className={`h-full rounded transition-all ${getPasswordStrengthColor()}`}
                              style={{ width: `${Math.min((passwordStrength.length / 12) * 100, 100)}%` }}
                            />
                          </div>
                          <span className="text-muted-foreground">{getPasswordStrengthText()}</span>
                        </div>
                      </div>
                    )}
                    {errors.password && (
                      <p className="text-sm text-destructive">{errors.password.message}</p>
                    )}
                  </div>

                  {/* Confirm Password Field */}
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">{t('auth.confirmPassword')}</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="confirmPassword"
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="确认密码"
                        className="pl-10 pr-10"
                        {...register('confirmPassword')}
                        autoComplete="new-password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    {errors.confirmPassword && (
                      <p className="text-sm text-destructive">{errors.confirmPassword.message}</p>
                    )}
                  </div>

                  {/* Nickname Field */}
                  <div className="space-y-2">
                    <Label htmlFor="nickname">{t('auth.nickname')}</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="nickname"
                        type="text"
                        placeholder="输入昵称"
                        className="pl-10"
                        {...register('nickname')}
                        autoComplete="name"
                      />
                    </div>
                    {errors.nickname && (
                      <p className="text-sm text-destructive">{errors.nickname.message}</p>
                    )}
                  </div>

                  {/* Phone Field - Optional */}
                  <div className="space-y-2">
                    <Label htmlFor="phone">{t('auth.phone')} (可选)</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="输入手机号"
                        className="pl-10"
                        {...register('phone')}
                        autoComplete="tel"
                      />
                    </div>
                    {errors.phone && (
                      <p className="text-sm text-destructive">{errors.phone.message}</p>
                    )}
                  </div>

                  {/* Terms Agreement */}
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="agreeTerms"
                      checked={watch('agreeTerms')}
                      onCheckedChange={(checked) => setValue('agreeTerms', checked as boolean)}
                      className="mt-1"
                    />
                    <Label
                      htmlFor="agreeTerms"
                      className="text-sm font-normal cursor-pointer leading-relaxed"
                    >
                      我已阅读并同意{' '}
                      <Link to="/terms" className="text-primary hover:underline">
                        服务条款
                      </Link>{' '}
                      和{' '}
                      <Link to="/privacy" className="text-primary hover:underline">
                        隐私政策
                      </Link>
                    </Label>
                  </div>
                  {errors.agreeTerms && (
                    <p className="text-sm text-destructive">{errors.agreeTerms.message}</p>
                  )}

                  {/* Submit Button */}
                  <Button
                    type="submit"
                    className="w-full"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        注册中...
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4 mr-2" />
                        {t('common.register')}
                      </>
                    )}
                  </Button>
                </form>

                {/* Login Link */}
                <div className="mt-6 text-center">
                  <p className="text-sm text-muted-foreground">
                    {t('auth.hasAccount')}{' '}
                    <Link
                      to="/login"
                      className="text-primary hover:underline font-medium"
                    >
                      {t('auth.loginNow')}
                    </Link>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
