import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Bookmark,
  List,
  Settings,
  Plus,
  Save,
  Moon,
  Sun,
  X,
  Share2,
  Heart,
  MessageSquare,
  ArrowLeft,
  Menu,
  Type,
  AlignJustify,
  RotateCcw,
  Minimize,
  Maximize,
  ChevronDown,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
  SheetFooter,
} from '@/components/ui/sheet';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { Toggle } from '@/components/ui/toggle';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';

const TheoryReader: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const chapterId = searchParams.get('chapter') || '1';
  const { t } = useTranslation();
  const { isAuthenticated, user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const contentRef = useRef<HTMLDivElement>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [currentChapter, setCurrentChapter] = useState(parseInt(chapterId, 10));
  const [readingProgress, setReadingProgress] = useState(0);
  const [fontSize, setFontSize] = useState(18);
  const [lineHeight, setLineHeight] = useState(1.8);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isVerticalMode, setIsVerticalMode] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showNoteSidebar, setShowNoteSidebar] = useState(false);
  const [currentNote, setCurrentNote] = useState({ id: 0, content: '' });
  const [isShowingAnnotation, setIsShowingAnnotation] = useState<number | null>(null);
  const [bookmarks, setBookmarks] = useState<Array<{ id: number, position: number, note: string, timestamp: string }>>([]);
  const [notesTab, setNotesTab] = useState<'mine' | 'all'>('mine');
  
  // 模拟理论详情数据
  const theory = {
    id: 1,
    title: '黄帝内经',
    subtitle: '素问 · 灵枢',
    author: '黄帝',
    dynasty: '先秦',
    cover: '/images/theories/huangdi-neijing.jpg',
    summary: '《黄帝内经》是中国最早的医学典籍，传统医学四大经典著作之一。',
    chapters: [
      { 
        id: 1, 
        title: '上古天真论篇第一', 
        content: `昔在黄帝，生而神灵，弱而能言，幼而徇齐，长而敦敏，成而登天。乃问于天师曰："余闻上古之人，春秋皆度百岁，而动作不衰；今时之人，年半百而动作皆衰者，时世异耶？人将失之耶？"
          
岐伯对曰："上古之人，其知道者，法于阴阳，和于术数，食饮有节，起居有常，不妄作劳，故能形与神俱，而尽终其天年，度百岁乃去。今时之人不然也，以酒为浆，以妄为常，醉以入房，以欲竭其精，以耗散其真，不知持满，不时御神，务快其心，逆于生乐，起居无节，故半百而衰也。"
          
黄帝曰："余闻上古有真人者，提挈天地，把握阴阳，呼吸精气，独立守神，肌肉若一，故能寿敝天地，无有终时，此其道生。中古之时，有至人者，淳德全道，和于阴阳，调于四时，去世离俗，积精全神，游行天地之间，视听八达之外，此盖益其寿命而强者也，亦归于真人。"
        `,
        annotations: [
          {
            id: 1,
            text: '昔在黄帝',
            position: { start: 0, end: 4 },
            explanation: '昔：古时；在：存在。意为古时候有黄帝。'
          },
          {
            id: 2,
            text: '春秋皆度百岁',
            position: { start: 52, end: 58 },
            explanation: '春秋：年龄；度：超过。意为年龄都超过了一百岁。'
          },
          {
            id: 3,
            text: '法于阴阳，和于术数',
            position: { start: 120, end: 130 },
            explanation: '法：遵循；术数：天文历法和算术。意为遵循阴阳规律，协调天文历法。'
          }
        ]
      },
      { 
        id: 2, 
        title: '四气调神大论篇第二', 
        content: `黄帝问曰："四气调神，愿闻其说。"岐伯对曰："夫四时阴阳者，万物之根本也。所以圣人春夏养阳，秋冬养阴，以从其根，故与万物沉浮于生长之门。逆其根，则伐其本，坏其真矣。故阴阳四时者，万物之终始也，死生之本也，逆之则灾害生，从之则苛疾不起，是谓得道。道者，圣人行之，愚者佩之。从阴阳则生，逆之则死，从之则治，逆之则乱。反顺为逆，是谓内格。"
          
黄帝曰："人生有形，不与万物同论，然有恶死乐生者，何也？"
          
岐伯曰："天地合气，命之曰人。人能应四时者，天地为之父母。"
        `,
        annotations: [
          {
            id: 4,
            text: '四气调神',
            position: { start: 5, end: 9 },
            explanation: '四气：春夏秋冬四季的气候；调神：调节精神。意为通过调节四季的气候来调养精神。'
          },
          {
            id: 5,
            text: '春夏养阳，秋冬养阴',
            position: { start: 60, end: 70 },
            explanation: '指在春夏阳气旺盛时养护阳气，在秋冬阴气旺盛时养护阴气，顺应自然规律。'
          }
        ]
      },
      { 
        id: 3, 
        title: '生气通天论篇第三', 
        content: `黄帝曰："夫自古通天者，生之本，本于阴阳。天地之间，六合之内，其气九州、九窍、五藏、十二节，皆通乎天气。其生五，其气三，数犯此者，则邪气伤人，此寿命之本也。"
          
黄帝曰："余闻上古之人，春秋皆度百岁，而动作不衰；今时之人，年半百而动作皆衰者，时世异耶？人将失之耶？"
          
岐伯对曰："上古之人，其知道者，法于阴阳，和于术数，食饮有节，起居有常，不妄作劳，故能形与神俱，而尽终其天年，度百岁乃去。今时之人不然也，以酒为浆，以妄为常，醉以入房，以欲竭其精，以耗散其真，不知持满，不时御神，务快其心，逆于生乐，起居无节，故半百而衰也。"
        `,
        annotations: [
          {
            id: 6,
            text: '生气通天',
            position: { start: 5, end: 9 },
            explanation: '生气：生命之气；通天：上通于天。意为生命之气上通于天。'
          },
          {
            id: 7,
            text: '六合之内',
            position: { start: 40, end: 44 },
            explanation: '六合：古人将天地四方统称为六合，指天地之间。'
          }
        ]
      },
      { 
        id: 4, 
        title: '金匮真言论篇第四', 
        content: `黄帝问曰："天有八风，经有五风，何谓？"
          
岐伯对曰："八风发邪，以为经风，触五藏，邪气发病。"
          
黄帝问曰："何谓八风？"
          
岐伯对曰："八风者，东风、南风、西风、北风、东南风、东北风、西南风、西北风。经言春气者温，夏气者热，秋气者凉，冬气者寒，此四时正气之气，故知天之刑德。"
        `,
        annotations: [
          {
            id: 8,
            text: '金匮真言',
            position: { start: 0, end: 4 },
            explanation: '金匮：喻贵重如黄金的宝库；真言：真实可信的话。意为珍贵如黄金宝库的真实言论。'
          },
          {
            id: 9,
            text: '天有八风，经有五风',
            position: { start: 9, end: 19 },
            explanation: '八风：八个方向的风；五风：指影响人体五脏的风邪。'
          }
        ]
      },
      { 
        id: 5, 
        title: '阴阳应象大论篇第五', 
        content: `黄帝曰："阴阳者，天地之道也，万物之纲纪，变化之父母，生杀之本始，神明之府也。治病必求于本。"
          
"故积阳为天，积阴为地。阴静阳躁，阳生阴长，阳杀阴藏。阳化气，阴成形。寒极生热，热极生寒。寒气生浊，热气生清。清气在下，则生飧泄；浊气在上，则生䐜胀。此阴阳反作，病之逆从也。"
          
"故清阳为天，浊阴为地；地气上为云，天气下为雨；雨出地气，云出天气。故清阳出上窍，浊阴出下窍；清阳发腠理，浊阴走五藏；清阳实四肢，浊阴归六府。"
        `,
        annotations: [
          {
            id: 10,
            text: '阴阳者，天地之道也',
            position: { start: 5, end: 15 },
            explanation: '意为阴阳是天地运行的规律。'
          },
          {
            id: 11,
            text: '万物之纲纪',
            position: { start: 16, end: 22 },
            explanation: '纲纪：网纲和绳索，引申为总纲和条目。意为万物的总纲和条目。'
          },
          {
            id: 12,
            text: '阴静阳躁',
            position: { start: 75, end: 79 },
            explanation: '阴气静止，阳气躁动，形容阴阳两气的基本属性。'
          }
        ]
      }
    ],
    isPremium: false,
    notes: [
      {
        id: 1,
        user: { id: 1, username: 'user1', nickname: '张医师' },
        chapterId: 1,
        content: '上古天真论主要讲述了养生之道，强调顺应自然规律，调和阴阳。',
        createdAt: '2024-05-12T14:30:00Z'
      },
      {
        id: 2,
        user: { id: 2, username: 'user2', nickname: '李学者' },
        chapterId: 1,
        content: '这一篇提到了"上古之人"的生活方式，与现代人形成对比，说明了养生的重要性。',
        createdAt: '2024-05-14T09:15:00Z'
      }
    ]
  };

  const chapter = theory.chapters.find(c => c.id === currentChapter) || theory.chapters[0];
  
  // 计算阅读进度
  useEffect(() => {
    const handleScroll = () => {
      if (contentRef.current) {
        const { scrollTop, scrollHeight, clientHeight } = contentRef.current;
        const progress = (scrollTop / (scrollHeight - clientHeight)) * 100;
        setReadingProgress(Math.min(Math.max(progress, 0), 100));
      }
    };
    
    const contentEl = contentRef.current;
    if (contentEl) {
      contentEl.addEventListener('scroll', handleScroll);
      return () => contentEl.removeEventListener('scroll', handleScroll);
    }
  }, [chapter]);
  
  // 保存阅读进度
  useEffect(() => {
    if (isAuthenticated && readingProgress > 0) {
      // 这里可以调用API保存阅读进度
      const saveProgress = () => {
        console.log(`保存阅读进度: ${readingProgress.toFixed(2)}%`);
        // readingProgressApi.update(theory.id, { chapterId: currentChapter, progress: readingProgress });
      };
      
      // 使用防抖，避免频繁保存
      const timeoutId = setTimeout(saveProgress, 2000);
      return () => clearTimeout(timeoutId);
    }
  }, [readingProgress, isAuthenticated, currentChapter, theory.id]);
  
  // 全屏模式处理
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);
  
  const toggleFullscreen = () => {
    if (!isFullscreen) {
      document.documentElement.requestFullscreen().catch(err => {
        console.error(`全屏请求失败: ${err.message}`);
      });
    } else {
      document.exitFullscreen().catch(err => {
        console.error(`退出全屏失败: ${err.message}`);
      });
    }
  };
  
  const navigateToChapter = (chapterId: number) => {
    setCurrentChapter(chapterId);
    navigate(`/theory/${id}/read?chapter=${chapterId}`, { replace: true });
    setMenuOpen(false);
  };
  
  const prevChapter = () => {
    if (currentChapter > 1) {
      navigateToChapter(currentChapter - 1);
    }
  };
  
  const nextChapter = () => {
    if (currentChapter < theory.chapters.length) {
      navigateToChapter(currentChapter + 1);
    }
  };
  
  const addBookmark = () => {
    if (!isAuthenticated) {
      toast({
        title: "需要登录",
        description: "请登录后使用书签功能",
        variant: "destructive"
      });
      return;
    }
    
    const position = readingProgress;
    const timestamp = new Date().toISOString();
    const newBookmark = { 
      id: bookmarks.length + 1, 
      position, 
      note: "", 
      timestamp 
    };
    
    setBookmarks([...bookmarks, newBookmark]);
    toast({
      title: "添加书签成功",
      description: `在当前章节的 ${position.toFixed(1)}% 处添加了书签`
    });
  };
  
  const addNote = () => {
    if (!isAuthenticated) {
      toast({
        title: "需要登录",
        description: "请登录后使用笔记功能",
        variant: "destructive"
      });
      return;
    }
    
    setCurrentNote({ id: 0, content: '' });
    setShowNoteSidebar(true);
  };
  
  const saveNote = () => {
    if (!currentNote.content.trim()) {
      toast({
        title: "保存失败",
        description: "笔记内容不能为空",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "笔记已保存",
      description: "您的笔记已成功保存"
    });
    
    setShowNoteSidebar(false);
  };
  
  const toggleAnnotation = (id: number) => {
    if (isShowingAnnotation === id) {
      setIsShowingAnnotation(null);
    } else {
      setIsShowingAnnotation(id);
    }
  };
  
  // 渲染带注释的内容
  const renderContentWithAnnotations = () => {
    if (!chapter || !chapter.content) return null;
    
    let content = chapter.content;
    const annotations = chapter.annotations || [];
    
    if (annotations.length === 0) return <p className="mb-4">{content}</p>;
    
    // 对注释按位置排序，从后向前处理，避免位置偏移
    const sortedAnnotations = [...annotations].sort((a, b) => 
      b.position.start - a.position.start
    );
    
    let result = content;
    sortedAnnotations.forEach(anno => {
      const { id, text, position } = anno;
      const { start, end } = position;
      
      const before = result.substring(0, start);
      const annotatedText = result.substring(start, end);
      const after = result.substring(end);
      
      result = before + 
        `<span class="annotation-text cursor-pointer underline decoration-dotted underline-offset-4 decoration-amber-500 hover:text-amber-700" data-id="${id}">${annotatedText}</span>` + 
        after;
    });
    
    // 分段落显示
    const paragraphs = result.split('\n\n').map((p, idx) => 
      <p key={idx} className="mb-4" dangerouslySetInnerHTML={{ __html: p.trim() }} />
    );
    
    return (
      <div onClick={(e) => {
        const target = e.target as HTMLElement;
        if (target.classList.contains('annotation-text')) {
          const id = parseInt(target.getAttribute('data-id') || '0', 10);
          toggleAnnotation(id);
        }
      }}>
        {paragraphs}
      </div>
    );
  };
  
  return (
    <div 
      className={cn(
        "min-h-screen flex flex-col transition-colors duration-300",
        isDarkMode ? "bg-gray-900 text-gray-100" : "bg-amber-50 text-gray-900"
      )}
    >
      {/* 顶部导航栏 */}
      <div className={cn(
        "sticky top-0 z-50 px-4 py-2 flex items-center justify-between border-b",
        isDarkMode ? "bg-gray-900 border-gray-700" : "bg-amber-50 border-amber-200"
      )}>
        <div className="flex items-center space-x-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate(`/theory/${id}`)}
            className={isDarkMode ? "hover:bg-gray-800" : "hover:bg-amber-100"}
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            返回
          </Button>
          
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm"
                className={isDarkMode ? "hover:bg-gray-800" : "hover:bg-amber-100"}
              >
                <Menu className="h-4 w-4 mr-1" />
                目录
              </Button>
            </SheetTrigger>
            <SheetContent 
              side="left" 
              className={cn(
                "w-[300px] sm:w-[400px]",
                isDarkMode ? "bg-gray-800 text-gray-100" : "bg-amber-50 text-gray-900"
              )}
            >
              <SheetHeader>
                <SheetTitle>
                  {theory.title} - 目录
                </SheetTitle>
                <SheetDescription>
                  共 {theory.chapters.length} 章
                </SheetDescription>
              </SheetHeader>
              
              <div className="mt-6 overflow-y-auto max-h-[calc(100vh-150px)]">
                <div className="space-y-1">
                  {theory.chapters.map((ch) => (
                    <div 
                      key={ch.id} 
                      className={cn(
                        "py-2 px-3 rounded-md cursor-pointer flex justify-between items-center",
                        ch.id === currentChapter
                          ? isDarkMode
                            ? "bg-gray-700 text-amber-400"
                            : "bg-amber-200 text-amber-900"
                          : isDarkMode
                            ? "hover:bg-gray-700"
                            : "hover:bg-amber-100"
                      )}
                      onClick={() => navigateToChapter(ch.id)}
                    >
                      <div>
                        <span className="text-sm mr-2">{ch.id}.</span>
                        <span>{ch.title}</span>
                      </div>
                      {ch.id === currentChapter && (
                        <Badge variant="outline" className={isDarkMode ? "border-amber-400 text-amber-400" : "border-amber-600 text-amber-800"}>
                          当前
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
        
        <div className="text-center flex-1 truncate mx-4">
          <h1 className="text-lg font-medium">{theory.title}</h1>
          <p className="text-xs opacity-70">{chapter.title}</p>
        </div>
        
        <div className="flex items-center space-x-1">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={addBookmark}
            className={isDarkMode ? "hover:bg-gray-800" : "hover:bg-amber-100"}
          >
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Bookmark className="h-4 w-4" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>添加书签</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={addNote}
            className={isDarkMode ? "hover:bg-gray-800" : "hover:bg-amber-100"}
          >
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Plus className="h-4 w-4" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>添加笔记</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </Button>
          
          <DropdownMenu>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      className={isDarkMode ? "hover:bg-gray-800" : "hover:bg-amber-100"}
                    >
                      <Settings className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                </TooltipTrigger>
                <TooltipContent>
                  <p>阅读设置</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <DropdownMenuContent
              className={cn(
                isDarkMode ? "bg-gray-800 text-gray-100 border-gray-700" : "bg-amber-50 border-amber-200"
              )}
            >
              <DropdownMenuLabel>阅读设置</DropdownMenuLabel>
              <DropdownMenuSeparator />
              
              <div className="px-2 py-1.5">
                <div className="mb-1 text-xs opacity-70">字体大小</div>
                <div className="flex items-center space-x-2">
                  <Type className="h-3 w-3" />
                  <Slider
                    value={[fontSize]}
                    min={14}
                    max={24}
                    step={1}
                    onValueChange={(value) => setFontSize(value[0])}
                    className="w-32"
                  />
                  <Type className="h-4 w-4" />
                </div>
              </div>
              
              <div className="px-2 py-1.5">
                <div className="mb-1 text-xs opacity-70">行间距</div>
                <div className="flex items-center space-x-2">
                  <AlignJustify className="h-3 w-3" />
                  <Slider
                    value={[lineHeight * 10]}
                    min={15}
                    max={25}
                    step={1}
                    onValueChange={(value) => setLineHeight(value[0] / 10)}
                    className="w-32"
                  />
                  <AlignJustify className="h-4 w-4" />
                </div>
              </div>
              
              <DropdownMenuSeparator />
              
              <DropdownMenuItem 
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="cursor-pointer"
              >
                {isDarkMode ? (
                  <Sun className="h-4 w-4 mr-2" />
                ) : (
                  <Moon className="h-4 w-4 mr-2" />
                )}
                {isDarkMode ? "明亮模式" : "夜间模式"}
              </DropdownMenuItem>
              
              <DropdownMenuItem 
                onClick={() => setIsVerticalMode(!isVerticalMode)}
                className="cursor-pointer"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                {isVerticalMode ? "横排模式" : "竖排模式"}
              </DropdownMenuItem>
              
              <DropdownMenuItem 
                onClick={toggleFullscreen}
                className="cursor-pointer"
              >
                {isFullscreen ? (
                  <Minimize className="h-4 w-4 mr-2" />
                ) : (
                  <Maximize className="h-4 w-4 mr-2" />
                )}
                {isFullscreen ? "退出全屏" : "全屏阅读"}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      {/* 主阅读区域 */}
      <div className="flex flex-1 overflow-hidden">
        {/* 正文内容 */}
        <div 
          className={cn(
            "flex-1 overflow-auto px-4 lg:px-0 py-8 transition-all",
            isVerticalMode 
              ? "writing-vertical flex justify-center" 
              : "lg:flex lg:justify-center"
          )}
          ref={contentRef}
        >
          <div 
            className={cn(
              "w-full lg:max-w-2xl xl:max-w-3xl transition-all",
              isVerticalMode 
                ? "h-[80vh] flex flex-row-reverse items-start writing-mode-vertical" 
                : "flex flex-col items-start"
            )}
            style={{ 
              fontSize: `${fontSize}px`, 
              lineHeight: lineHeight,
            }}
          >
            {/* 章节标题 */}
            <div className={cn(
              "w-full text-center mb-8",
              isVerticalMode ? "writing-vertical mr-8" : ""
            )}>
              <h2 className="text-2xl font-semibold mb-2">{chapter.title}</h2>
              <div className="text-sm opacity-70 flex items-center justify-center space-x-2">
                <span>{theory.title}</span>
                <span>·</span>
                <span>{theory.author}</span>
              </div>
            </div>
            
            {/* 正文内容 */}
            <div className={cn(
              "w-full",
              isVerticalMode 
                ? "ancient-vertical writing-mode-vertical" 
                : "ancient-horizontal",
              isDarkMode ? "text-gray-200" : "text-gray-800"
            )}>
              {renderContentWithAnnotations()}
              
              {/* 注释弹出框 */}
              {isShowingAnnotation !== null && chapter.annotations && (
                <div className={cn(
                  "fixed p-4 rounded-lg shadow-lg max-w-xs z-50 border",
                  isDarkMode 
                    ? "bg-gray-800 border-gray-700 text-gray-100" 
                    : "bg-amber-100 border-amber-300 text-gray-900"
                )}
                  style={{ 
                    top: '50%', 
                    left: '50%', 
                    transform: 'translate(-50%, -50%)' 
                  }}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="font-medium text-sm">注释</div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-5 w-5" 
                      onClick={() => setIsShowingAnnotation(null)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                  
                  <div>
                    {(() => {
                      const anno = chapter.annotations.find(a => a.id === isShowingAnnotation);
                      if (!anno) return null;
                      
                      return (
                        <>
                          <div className="text-sm font-medium mb-1">{anno.text}</div>
                          <p className="text-xs">{anno.explanation}</p>
                        </>
                      );
                    })()}
                  </div>
                </div>
              )}
            </div>
            
            {/* 章节末尾 */}
            <div className="w-full text-center mt-16 mb-32">
              <Separator className="mb-8" />
              <div className="flex items-center justify-center space-x-8">
                <Button
                  variant="outline"
                  onClick={prevChapter}
                  disabled={currentChapter <= 1}
                  className={isDarkMode ? "border-gray-700 hover:bg-gray-800" : "border-amber-200 hover:bg-amber-100"}
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  上一章
                </Button>
                
                <span className="text-sm opacity-70">
                  {currentChapter} / {theory.chapters.length}
                </span>
                
                <Button
                  variant="outline"
                  onClick={nextChapter}
                  disabled={currentChapter >= theory.chapters.length}
                  className={isDarkMode ? "border-gray-700 hover:bg-gray-800" : "border-amber-200 hover:bg-amber-100"}
                >
                  下一章
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* 侧边栏 - 笔记/书签等 */}
        {!isMobile && (
          <Sheet open={showNoteSidebar} onOpenChange={setShowNoteSidebar}>
            <SheetContent 
              side="right" 
              className={cn(
                "w-[350px] sm:w-[450px] overflow-y-auto",
                isDarkMode ? "bg-gray-800 text-gray-100 border-gray-700" : "bg-amber-50 border-amber-200"
              )}
            >
              <SheetHeader>
                <SheetTitle>学习笔记</SheetTitle>
                <SheetDescription>
                  记录您的想法和学习心得
                </SheetDescription>
              </SheetHeader>
              
              <div className="mt-6">
                <Tabs defaultValue="add" className="w-full">
                  <TabsList className="w-full grid grid-cols-2">
                    <TabsTrigger value="add">添加笔记</TabsTrigger>
                    <TabsTrigger value="view">查看笔记</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="add" className="mt-4">
                    <div className="space-y-4">
                      <div>
                        <div className="text-sm mb-2">笔记内容</div>
                        <Textarea 
                          value={currentNote.content}
                          onChange={(e) => setCurrentNote({ ...currentNote, content: e.target.value })}
                          placeholder="请输入您的笔记内容..."
                          className="min-h-[200px]"
                        />
                      </div>
                      
                      <Button onClick={saveNote} className="w-full">
                        <Save className="h-4 w-4 mr-2" />
                        保存笔记
                      </Button>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="view" className="mt-4">
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <div className="text-sm font-medium">所有笔记</div>
                        <div className="flex">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => setNotesTab('mine')}
                            className={cn(
                              "text-xs px-2 py-1",
                              notesTab === 'mine' 
                                ? isDarkMode ? "bg-gray-700" : "bg-amber-200" 
                                : ""
                            )}
                          >
                            我的笔记
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => setNotesTab('all')}
                            className={cn(
                              "text-xs px-2 py-1",
                              notesTab === 'all' 
                                ? isDarkMode ? "bg-gray-700" : "bg-amber-200" 
                                : ""
                            )}
                          >
                            全部笔记
                          </Button>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        {theory.notes
                          .filter(note => notesTab === 'all' || (isAuthenticated && note.user.id === user?.id))
                          .map(note => (
                            <Card key={note.id} className={isDarkMode ? "bg-gray-700 border-gray-600" : "bg-white border-amber-200"}>
                              <CardContent className="p-4">
                                <div className="flex justify-between items-start mb-2">
                                  <div className="text-sm font-medium">{note.user.nickname}</div>
                                  <div className="text-xs opacity-70">
                                    {new Date(note.createdAt).toLocaleDateString()}
                                  </div>
                                </div>
                                <p className="text-sm whitespace-pre-line">{note.content}</p>
                                <div className="flex justify-end mt-2 space-x-2">
                                  <Button variant="ghost" size="sm" className="text-xs px-2 py-1">
                                    <Heart className="h-3 w-3 mr-1" />
                                    点赞
                                  </Button>
                                  <Button variant="ghost" size="sm" className="text-xs px-2 py-1">
                                    <MessageSquare className="h-3 w-3 mr-1" />
                                    回复
                                  </Button>
                                  <Button variant="ghost" size="sm" className="text-xs px-2 py-1">
                                    <Share2 className="h-3 w-3 mr-1" />
                                    分享
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        
                        {theory.notes.filter(note => notesTab === 'all' || (isAuthenticated && note.user.id === user?.id)).length === 0 && (
                          <div className="text-center py-8">
                            <BookOpen className={cn(
                              "h-12 w-12 mx-auto mb-4",
                              isDarkMode ? "text-gray-600" : "text-amber-300"
                            )} />
                            <p className="text-sm opacity-70">
                              {notesTab === 'mine' ? '您还没有添加笔记' : '暂无相关笔记'}
                            </p>
                            <Button variant="outline" size="sm" className="mt-4" onClick={() => addNote()}>
                              添加笔记
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </SheetContent>
          </Sheet>
        )}
        
        {/* 移动端笔记侧边栏 */}
        {isMobile && (
          <Drawer open={showNoteSidebar} onOpenChange={setShowNoteSidebar}>
            <DrawerContent className={isDarkMode ? "bg-gray-800 text-gray-100" : "bg-amber-50"}>
              <DrawerHeader>
                <DrawerTitle>学习笔记</DrawerTitle>
                <DrawerDescription>
                  记录您的想法和学习心得
                </DrawerDescription>
              </DrawerHeader>
              
              <div className="px-4 py-2">
                <Textarea 
                  value={currentNote.content}
                  onChange={(e) => setCurrentNote({ ...currentNote, content: e.target.value })}
                  placeholder="请输入您的笔记内容..."
                  className="min-h-[150px]"
                />
              </div>
              
              <DrawerFooter className="flex flex-row justify-between">
                <DrawerClose asChild>
                  <Button variant="outline">取消</Button>
                </DrawerClose>
                <Button onClick={saveNote}>保存笔记</Button>
              </DrawerFooter>
            </DrawerContent>
          </Drawer>
        )}
      </div>
      
      {/* 底部进度条 */}
      <div className={cn(
        "sticky bottom-0 z-50 w-full border-t",
        isDarkMode ? "bg-gray-900 border-gray-700" : "bg-amber-50 border-amber-200"
      )}>
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs opacity-70">{chapter.title}</span>
            <span className="text-xs opacity-70">{readingProgress.toFixed(0)}%</span>
          </div>
          <Progress value={readingProgress} className="h-1" />
        </div>
      </div>
      
      <style>{`
        .writing-mode-vertical {
          writing-mode: vertical-rl;
          text-orientation: upright;
        }
        
        .ancient-vertical {
          font-family: "SimSun", "STSong", serif;
          letter-spacing: 0.05em;
        }
        
        .ancient-horizontal {
          font-family: "SimSun", "STSong", serif;
          letter-spacing: 0.05em;
        }
      `}</style>
    </div>
  );
};

export default TheoryReader;