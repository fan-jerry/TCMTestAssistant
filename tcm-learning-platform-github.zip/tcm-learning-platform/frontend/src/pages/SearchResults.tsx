import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Search,
  Filter,
  ArrowLeft,
  Leaf,
  BookOpen,
  MapPin,
  FileText,
  ExternalLink,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';

interface SearchResult {
  id: number;
  type: 'herb' | 'formula' | 'acupoint' | 'article';
  title: string;
  subtitle: string;
  description?: string;
  url: string;
}

const SearchResults: React.FC = () => {
  const { t } = useTranslation();
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [searchType, setSearchType] = useState(searchParams.get('type') || 'all');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);

  const typeOptions = [
    { value: 'all', label: '全部类型', icon: Search },
    { value: 'herbs', label: '中药材', icon: Leaf },
    { value: 'formulas', label: '方剂', icon: BookOpen },
    { value: 'acupoints', label: '穴位', icon: MapPin },
    { value: 'articles', label: '文章', icon: FileText },
  ];

  const getTypeInfo = (type: string) => {
    switch (type) {
      case 'herb':
        return { label: '中药材', icon: Leaf, color: 'bg-green-100 text-green-800' };
      case 'formula':
        return { label: '方剂', icon: BookOpen, color: 'bg-blue-100 text-blue-800' };
      case 'acupoint':
        return { label: '穴位', icon: MapPin, color: 'bg-purple-100 text-purple-800' };
      case 'article':
        return { label: '文章', icon: FileText, color: 'bg-gray-100 text-gray-800' };
      default:
        return { label: '其他', icon: Search, color: 'bg-gray-100 text-gray-800' };
    }
  };

  const performSearch = async (searchQuery: string, type: string) => {
    if (!searchQuery.trim()) {
      setResults([]);
      setTotal(0);
      return;
    }

    setLoading(true);
    try {
      // 使用encodeURIComponent来正确编码中文
      const encodedQuery = encodeURIComponent(searchQuery);
      const response = await fetch(`/api/search?q=${encodedQuery}&type=${type}&limit=20`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.code === 200) {
        setResults(data.data || []);
        setTotal(data.data?.length || 0);
      } else {
        toast({
          title: "搜索失败",
          description: data.message || "搜索时发生错误",
          variant: "destructive",
        });
        setResults([]);
        setTotal(0);
      }
    } catch (error) {
      console.error('搜索错误:', error);
      toast({
        title: "搜索失败",
        description: "网络错误，请稍后重试",
        variant: "destructive",
      });
      setResults([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const currentQuery = searchParams.get('q') || '';
    const currentType = searchParams.get('type') || 'all';
    
    setQuery(currentQuery);
    setSearchType(currentType);
    
    if (currentQuery) {
      performSearch(currentQuery, currentType);
    }
  }, [searchParams]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setSearchParams({ q: query, type: searchType });
    }
  };

  const handleTypeChange = (newType: string) => {
    setSearchType(newType);
    if (query.trim()) {
      setSearchParams({ q: query, type: newType });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 返回按钮 */}
      <Button variant="ghost" asChild className="mb-6">
        <Link to="/">
          <ArrowLeft className="h-4 w-4 mr-2" />
          返回首页
        </Link>
      </Button>

      {/* 页面标题 */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">搜索结果</h1>
        <p className="text-xl text-muted-foreground">
          查找中医药相关内容
        </p>
      </div>

      {/* 搜索表单 */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="输入中药材、方剂、穴位名称..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Select value={searchType} onValueChange={handleTypeChange}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="搜索类型" />
                  </SelectTrigger>
                  <SelectContent>
                    {typeOptions.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center">
                          <type.icon className="h-4 w-4 mr-2" />
                          {type.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button type="submit" disabled={loading}>
                  <Search className="h-4 w-4 mr-2" />
                  搜索
                </Button>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* 搜索结果统计 */}
      {query && (
        <div className="mb-6">
          <p className="text-muted-foreground">
            {loading ? (
              '搜索中...'
            ) : (
              <>
                搜索 "<strong>{query}</strong>" 找到 <strong>{total}</strong> 条结果
              </>
            )}
          </p>
        </div>
      )}

      {/* 搜索结果列表 */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      ) : results.length > 0 ? (
        <div className="space-y-4">
          {results.map((result) => {
            const typeInfo = getTypeInfo(result.type);
            const IconComponent = typeInfo.icon;
            
            return (
              <Card key={`${result.type}-${result.id}`} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className={`p-2 rounded-lg ${typeInfo.color}`}>
                      <IconComponent className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="text-xl font-semibold mb-1">
                            <Link 
                              to={result.url} 
                              className="hover:text-primary transition-colors"
                            >
                              {result.title}
                            </Link>
                          </h3>
                          <Badge variant="outline" className="mb-2">
                            {typeInfo.label}
                          </Badge>
                        </div>
                        <Button variant="ghost" size="sm" asChild>
                          <Link to={result.url}>
                            <ExternalLink className="h-4 w-4" />
                          </Link>
                        </Button>
                      </div>
                      
                      <p className="text-muted-foreground mb-2 line-clamp-2">
                        {result.subtitle}
                      </p>
                      
                      {result.description && (
                        <p className="text-sm text-muted-foreground">
                          {result.description}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : query && !loading ? (
        <div className="text-center py-12">
          <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-lg font-semibold mb-2">未找到相关结果</h3>
          <p className="text-muted-foreground mb-4">
            没有找到包含 "{query}" 的相关内容
          </p>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>搜索建议：</p>
            <ul className="list-disc list-inside space-y-1">
              <li>检查拼写是否正确</li>
              <li>尝试使用药材、方剂或穴位的别名</li>
              <li>使用更通用的关键词</li>
              <li>尝试中文、拼音或英文名称</li>
            </ul>
          </div>
        </div>
      ) : (
        <div className="text-center py-12">
          <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-lg font-semibold mb-2">开始搜索</h3>
          <p className="text-muted-foreground">
            输入关键词搜索中医药相关内容
          </p>
        </div>
      )}
    </div>
  );
};

export default SearchResults;
