import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Search,
  Filter,
  Download,
  ExternalLink,
  FileText,
  Video,
  Globe,
  BookOpen,
  Users,
  Calendar,
  Eye,
  Heart,
  Share2,
  MessageSquare,
  Star,
  TrendingUp,
  Clock,
  Tag,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface Article {
  id: number;
  title: string;
  content: string;
  summary: string;
  category: string;
  tags: string[];
  author: string;
  thumbnail?: string;
  isPremium: boolean;
  viewCount: number;
  likeCount: number;
  publishedAt: string;
}

interface PDFResource {
  id: number;
  title: string;
  description: string;
  category: string;
  fileSize: string;
  downloadCount: number;
  uploadedAt: string;
  isPremium: boolean;
}

interface Website {
  id: number;
  name: string;
  description: string;
  url: string;
  category: string;
  rating: number;
  visitCount: number;
  addedAt: string;
}

interface UserContribution {
  id: number;
  title: string;
  content: string;
  author: string;
  avatar?: string;
  category: string;
  tags: string[];
  publishedAt: string;
  likeCount: number;
  commentCount: number;
}

const Resources: React.FC = () => {
  const { t } = useTranslation();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(false);

  // 模拟数据
  const articles: Article[] = [
    {
      id: 1,
      title: '中医四诊：望闻问切的现代应用',
      content: '四诊是中医诊断疾病的基本方法...',
      summary: '深入解析中医四诊方法在现代临床中的应用与发展',
      category: '中医诊断',
      tags: ['四诊', '诊断学', '临床应用'],
      author: '张仲景',
      thumbnail: 'bg-gradient-to-br from-blue-400 to-cyan-500',
      isPremium: false,
      viewCount: 12580,
      likeCount: 368,
      publishedAt: '2024-01-15T10:30:00Z',
    },
    {
      id: 2,
      title: '针灸治疗失眠的临床研究',
      content: '失眠是现代人常见的健康问题...',
      summary: '综述针灸治疗失眠的机理与临床疗效观察',
      category: '针灸学',
      tags: ['针灸', '失眠', '临床研究'],
      author: '皇甫谧',
      thumbnail: 'bg-gradient-to-br from-green-400 to-blue-500',
      isPremium: true,
      viewCount: 8965,
      likeCount: 234,
      publishedAt: '2024-01-14T14:20:00Z',
    },
    {
      id: 3,
      title: '中药配伍禁忌与现代药理学',
      content: '中药配伍禁忌是中医药学的重要内容...',
      summary: '从现代药理学角度分析中药配伍禁忌的科学依据',
      category: '中药学',
      tags: ['中药', '配伍', '药理学'],
      author: '李时珍',
      thumbnail: 'bg-gradient-to-br from-purple-400 to-pink-500',
      isPremium: false,
      viewCount: 15420,
      likeCount: 456,
      publishedAt: '2024-01-13T16:45:00Z',
    },
  ];

  const pdfResources: PDFResource[] = [
    {
      id: 1,
      title: '《黄帝内经》素问篇',
      description: '中医经典文献，中医理论基础',
      category: '经典文献',
      fileSize: '25.6 MB',
      downloadCount: 15680,
      uploadedAt: '2024-01-01T00:00:00Z',
      isPremium: false,
    },
    {
      id: 2,
      title: '《伤寒论》条文解析',
      description: '张仲景伤寒论详细注释与临床应用',
      category: '经典文献',
      fileSize: '18.3 MB',
      downloadCount: 12340,
      uploadedAt: '2024-01-02T00:00:00Z',
      isPremium: true,
    },
    {
      id: 3,
      title: '中医针灸学教程',
      description: '现代中医针灸学理论与实践教程',
      category: '教学资料',
      fileSize: '42.1 MB',
      downloadCount: 9876,
      uploadedAt: '2024-01-03T00:00:00Z',
      isPremium: false,
    },
  ];

  const websites: Website[] = [
    {
      id: 1,
      name: '中国中医药信息网',
      description: '权威的中医药信息发布平台',
      url: 'https://www.cntcm.com.cn',
      category: '官方网站',
      rating: 4.8,
      visitCount: 25680,
      addedAt: '2024-01-01T00:00:00Z',
    },
    {
      id: 2,
      name: '中医世家',
      description: '中医药文化传承与交流平台',
      url: 'https://www.zysj.com.cn',
      category: '学习平台',
      rating: 4.6,
      visitCount: 18920,
      addedAt: '2024-01-02T00:00:00Z',
    },
    {
      id: 3,
      name: '中华中医药学会',
      description: '中华中医药学会官方网站',
      url: 'https://www.cacm.org.cn',
      category: '学术组织',
      rating: 4.7,
      visitCount: 12450,
      addedAt: '2024-01-03T00:00:00Z',
    },
  ];

  const userContributions: UserContribution[] = [
    {
      id: 1,
      title: '我的中医学习心得：从入门到临床',
      content: '分享我三年来中医学习的经验与感悟...',
      author: '中医小白',
      avatar: '/avatars/user1.jpg',
      category: '学习心得',
      tags: ['学习方法', '经验分享'],
      publishedAt: '2024-01-15T10:30:00Z',
      likeCount: 128,
      commentCount: 45,
    },
    {
      id: 2,
      title: '针灸治疗腰痛的个人体会',
      content: '结合多年临床实践，谈谈针灸治疗腰痛的要点...',
      author: '针灸医师',
      avatar: '/avatars/user2.jpg',
      category: '临床经验',
      tags: ['针灸', '腰痛', '临床'],
      publishedAt: '2024-01-14T14:20:00Z',
      likeCount: 89,
      commentCount: 23,
    },
  ];

  const categories = [
    { value: 'all', label: '全部分类' },
    { value: '中医基础', label: '中医基础' },
    { value: '中药学', label: '中药学' },
    { value: '方剂学', label: '方剂学' },
    { value: '针灸学', label: '针灸学' },
    { value: '中医诊断', label: '中医诊断' },
    { value: '临床医学', label: '临床医学' },
    { value: '养生保健', label: '养生保健' },
  ];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const formatFileSize = (size: string) => {
    return size;
  };

  const handleDownload = (resource: PDFResource) => {
    if (resource.isPremium && !isAuthenticated) {
      toast({
        variant: "destructive",
        title: "需要登录",
        description: "VIP资源需要登录后下载",
      });
      return;
    }

    toast({
      title: "下载开始",
      description: `正在下载 ${resource.title}`,
    });
  };

  const handleVisitWebsite = (website: Website) => {
    window.open(website.url, '_blank');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 页面标题 */}
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{t('resources.title')}</h1>
        <p className="text-xl text-muted-foreground">
          丰富的中医学习资源库
        </p>
      </div>

      {/* 搜索和过滤 */}
      <div className="mb-6 flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="搜索文章、资源、网站..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="选择分类" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category.value} value={category.value}>
                {category.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* 标签页内容 */}
      <Tabs defaultValue="articles" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="articles">CMS文章</TabsTrigger>
          <TabsTrigger value="pdfs">PDF资源</TabsTrigger>
          <TabsTrigger value="websites">网站导航</TabsTrigger>
          <TabsTrigger value="contributions">用户贡献</TabsTrigger>
        </TabsList>

        {/* CMS文章 */}
        <TabsContent value="articles" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article) => (
              <Card key={article.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardHeader className="pb-4">
                  <div className={cn("w-full h-32 rounded-lg mb-4", article.thumbnail)}></div>
                  <CardTitle className="line-clamp-2 group-hover:text-primary transition-colors">
                    <Link to={`/articles/${article.id}`}>
                      {article.title}
                      {article.isPremium && (
                        <Badge variant="secondary" className="ml-2 text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                          VIP
                        </Badge>
                      )}
                    </Link>
                  </CardTitle>
                  <CardDescription className="line-clamp-3">
                    {article.summary}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-1">
                      <Badge variant="outline" className="text-xs">{article.category}</Badge>
                      {article.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>{article.author}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{formatDate(article.publishedAt)}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between pt-2 border-t">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Eye className="w-4 h-4" />
                          <span>{article.viewCount.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Heart className="w-4 h-4" />
                          <span>{article.likeCount}</span>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" asChild>
                        <Link to={`/articles/${article.id}`}>
                          阅读全文
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* PDF资源 */}
        <TabsContent value="pdfs" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {pdfResources.map((resource) => (
              <Card key={resource.id} className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <FileText className="w-8 h-8 text-red-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                        {resource.title}
                        {resource.isPremium && (
                          <Badge variant="secondary" className="ml-2 text-xs bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0">
                            VIP
                          </Badge>
                        )}
                      </h3>
                      <p className="text-muted-foreground mb-3 line-clamp-2">
                        {resource.description}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                        <Badge variant="outline">{resource.category}</Badge>
                        <span>{resource.fileSize}</span>
                        <span>{resource.downloadCount.toLocaleString()} 下载</span>
                      </div>
                      <Button 
                        onClick={() => handleDownload(resource)}
                        className="gap-2"
                        size="sm"
                      >
                        <Download className="w-4 h-4" />
                        下载
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 网站导航 */}
        <TabsContent value="websites" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {websites.map((website) => (
              <Card key={website.id} className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Globe className="w-8 h-8 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                        {website.name}
                      </h3>
                      <p className="text-muted-foreground mb-3 line-clamp-2">
                        {website.description}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                        <Badge variant="outline">{website.category}</Badge>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4" />
                          <span>{website.rating}</span>
                        </div>
                        <span>{website.visitCount.toLocaleString()} 访问</span>
                      </div>
                      <Button 
                        onClick={() => handleVisitWebsite(website)}
                        variant="outline"
                        className="gap-2"
                        size="sm"
                      >
                        <ExternalLink className="w-4 h-4" />
                        访问网站
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* 用户贡献 */}
        <TabsContent value="contributions" className="space-y-6">
          {/* 发表观点 */}
          {isAuthenticated && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  发表您的观点
                </CardTitle>
                <CardDescription>
                  分享您的中医学习心得和临床经验
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input placeholder="请输入标题..." />
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="选择分类" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="learning">学习心得</SelectItem>
                    <SelectItem value="clinical">临床经验</SelectItem>
                    <SelectItem value="research">学术研究</SelectItem>
                    <SelectItem value="discussion">学术讨论</SelectItem>
                  </SelectContent>
                </Select>
                <Textarea placeholder="请输入您的观点和看法..." rows={4} />
                <div className="flex items-center gap-2">
                  <Input placeholder="添加标签..." className="flex-1" />
                  <Button>发布</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* 用户贡献列表 */}
          <div className="space-y-4">
            {userContributions.map((contribution) => (
              <Card key={contribution.id} className="group hover:shadow-md transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={contribution.avatar} />
                      <AvatarFallback>{contribution.author.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold group-hover:text-primary transition-colors">
                          {contribution.title}
                        </h3>
                        <Badge variant="outline" className="text-xs">
                          {contribution.category}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground mb-3 line-clamp-2">
                        {contribution.content}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                        <span>{contribution.author}</span>
                        <span>{formatDate(contribution.publishedAt)}</span>
                        {contribution.tags.map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex items-center gap-4">
                        <Button variant="ghost" size="sm" className="gap-2">
                          <Heart className="w-4 h-4" />
                          {contribution.likeCount}
                        </Button>
                        <Button variant="ghost" size="sm" className="gap-2">
                          <MessageSquare className="w-4 h-4" />
                          {contribution.commentCount}
                        </Button>
                        <Button variant="ghost" size="sm" className="gap-2">
                          <Share2 className="w-4 h-4" />
                          分享
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {!isAuthenticated && (
            <Card>
              <CardContent className="p-8 text-center">
                <Users className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">加入社区讨论</h3>
                <p className="text-muted-foreground mb-4">
                  登录后即可发表观点，与其他中医爱好者交流学习心得
                </p>
                <Button asChild>
                  <Link to="/login">立即登录</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Resources;
