import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  ArrowLeft,
  Heart,
  Share2,
  Bookmark,
  Eye,
  Star,
  Download,
  PrinterIcon,
  ExternalLink,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';

interface Herb {
  id: number;
  name: string;
  pinyin: string;
  englishName: string;
  category: string;
  nature: string;
  taste: string;
  meridian: string;
  functions: string;
  indications: string;
  usage: string;
  contraindications?: string;
  precautions?: string;
  pharmacology?: string;
  composition?: string;
  processing?: string;
  identification?: string;
  storage?: string;
  isPremium: boolean;
  viewCount: number;
  likeCount: number;
  image: string;
}

const HerbDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const [herb, setHerb] = useState<Herb | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);

  // 模拟药材数据
  const herbsData: Herb[] = [
    {
      id: 1,
      name: '人参',
      pinyin: 'rén shēn',
      englishName: 'Ginseng',
      category: '补气药',
      nature: '温',
      taste: '甘、微苦',
      meridian: '脾、肺、心、肾经',
      functions: '大补元气，复脉固脱，补脾益肺，生津养血，安神益智',
      indications: '气虚欲脱，肢冷脉微，脾虚食少，肺虚喘咳，津伤口渴，内热消渴，气血亏虚，久病虚羸，惊悸失眠，阳痿宫冷',
      usage: '3-9g，另煎兑入；或研末冲服，一次2g，一日2次',
      contraindications: '实证、热证忌服。不宜与藜芦同用。',
      precautions: '服用期间忌食萝卜、浓茶。高血压患者慎用。',
      pharmacology: '含人参皂苷、人参多糖、挥发油等成分，具有增强免疫、抗疲劳、调节血糖等作用。',
      composition: '主要含人参皂苷Rb1、Rb2、Rc、Rd、Re、Rf、Rg1、Rg2等，还含人参多糖、氨基酸、维生素等。',
      processing: '鲜人参洗净，晒干或烘干；或蒸制后晒干成红参；或用糖水浸渍后晒干成糖参。',
      identification: '根呈纺锤形，表面灰黄色，有纵皱纹及细根痕，根茎顶端有芦头，质硬，断面淡黄白色，有放射状裂隙。',
      storage: '置阴凉干燥处，密闭保存，防虫蛀。',
      isPremium: false,
      viewCount: 12580,
      likeCount: 358,
      image: 'bg-gradient-to-br from-red-400 to-orange-500',
    },
    {
      id: 2,
      name: '当归',
      pinyin: 'dāng guī',
      englishName: 'Angelica Sinensis',
      category: '补血药',
      nature: '温',
      taste: '甘、辛',
      meridian: '肝、心、脾经',
      functions: '补血活血，调经止痛，润肠通便',
      indications: '血虚萎黄，眩晕心悸，月经不调，经闭痛经，虚寒腹痛，风湿痹痛，跌扑损伤，痈疽疮疡，肠燥便秘',
      usage: '6-12g',
      contraindications: '湿盛中满及大便溏泄者慎服。',
      precautions: '用量过大可引起疲倦、嗜睡等反应。',
      pharmacology: '含挥发油、阿魏酸、当归多糖等，具有补血、活血、调经、镇痛等作用。',
      composition: '主要含挥发油、阿魏酸、当归内酯、维生素B12、叶酸等。',
      processing: '除去须根及泥沙，待软后切厚片，晒干或低温干燥。',
      identification: '根呈圆柱形，表面黄棕色至棕褐色，有纵皱纹，质柔韧，断面黄白色或淡黄棕色，皮部厚。',
      storage: '置阴凉干燥处，防虫蛀。',
      isPremium: false,
      viewCount: 9876,
      likeCount: 287,
      image: 'bg-gradient-to-br from-green-400 to-emerald-500',
    },
    {
      id: 3,
      name: '黄芪',
      pinyin: 'huáng qí',
      englishName: 'Astragalus',
      category: '补气药',
      nature: '微温',
      taste: '甘',
      meridian: '肺、脾经',
      functions: '补气升阳，固表止汗，利水消肿，生津养血，行滞通痹，托毒排脓，敛疮生肌',
      indications: '气虚乏力，食少便溏，中气下陷，久泻脱肛，便血崩漏，表虚自汗，气虚水肿，内热消渴，血虚萎黄，半身不遂，痹痛麻木，痈疽难溃，久溃不敛',
      usage: '9-30g',
      contraindications: '表实邪盛，气滞湿阻，食积停滞，痈疽初起或溃后热毒尚盛等实证，以及阴虚阳亢者，均须禁服。',
      precautions: '感冒发热期间不宜服用。高血压患者应在医师指导下使用。',
      pharmacology: '含黄芪甲苷、黄芪多糖、黄酮类等成分，具有增强免疫、抗疲劳、利尿等作用。',
      composition: '主要含黄芪甲苷、黄芪多糖、异黄酮、胆碱、甜菜碱等。',
      processing: '除去须根及根头，晒干。蜜黄芪：取黄芪片，照蜜炙法炒至不粘手。',
      identification: '根呈圆柱形，表面淡棕黄色或淡棕色，有不整齐的纵皱纹或纵沟，质硬而韧，不易折断。',
      storage: '置通风干燥处，防蛀。',
      isPremium: false,
      viewCount: 8234,
      likeCount: 234,
      image: 'bg-gradient-to-br from-yellow-400 to-orange-500',
    },
    {
      id: 4,
      name: '枸杞子',
      pinyin: 'gǒu qǐ zǐ',
      englishName: 'Lycium Barbarum',
      category: '补阴药',
      nature: '平',
      taste: '甘',
      meridian: '肝、肾经',
      functions: '滋补肝肾，明目润肺',
      indications: '肝肾阴虚，腰膝酸软，头晕目眩，目昏多泪，虚劳咳嗽，消渴遗精',
      usage: '6-12g',
      contraindications: '外邪实热，脾虚有湿及泄泻者忌服。',
      precautions: '用量过大可引起上火。糖尿病患者慎用。',
      pharmacology: '含枸杞多糖、甜菜碱、胡萝卜素等，具有免疫调节、抗氧化、保肝等作用。',
      composition: '主要含枸杞多糖、甜菜碱、胡萝卜素、维生素C、硒等。',
      processing: '夏、秋二季果实呈红色时采收，热风烘干。',
      identification: '果实呈椭圆形或纺锤形，表面红色或暗红色，顶端有小突起状的花柱痕，基部有白色的果梗痕。',
      storage: '置阴凉干燥处，防闷热，防虫蛀。',
      isPremium: false,
      viewCount: 7542,
      likeCount: 198,
      image: 'bg-gradient-to-br from-red-400 to-pink-500',
    },
    {
      id: 5,
      name: '甘草',
      pinyin: 'gān cǎo',
      englishName: 'Licorice Root',
      category: '补气药',
      nature: '平',
      taste: '甘',
      meridian: '心、肺、脾、胃经',
      functions: '补脾益气，清热解毒，祛痰止咳，缓急止痛，调和诸药',
      indications: '脾胃虚弱，倦怠乏力，心悸气短，咳嗽痰多，脘腹、四肢挛急疼痛，痈肿疮毒，缓解药物毒性、烈性',
      usage: '2-10g',
      contraindications: '不宜与京大戟、芫花、甘遂、海藻同用。',
      precautions: '大剂量久服可引起假性醛固酮增多症。',
      pharmacology: '含甘草酸、甘草次酸、甘草黄酮等，具有抗炎、解毒、镇咳等作用。',
      composition: '主要含甘草酸、甘草苷、甘草黄酮、异甘草素等。',
      processing: '除去杂质，洗净，润透，切厚片，干燥。蜜甘草：照蜜炙法炒至不粘手。',
      identification: '根及根茎呈圆柱形，表面红棕色或灰棕色，具显著的纵皱纹、沟纹、皮孔及稀疏的细根痕。',
      storage: '置通风干燥处，防蛀。',
      isPremium: false,
      viewCount: 6789,
      likeCount: 156,
      image: 'bg-gradient-to-br from-amber-400 to-yellow-500',
    },
    {
      id: 6,
      name: '冬虫夏草',
      pinyin: 'dōng chóng xià cǎo',
      englishName: 'Cordyceps',
      category: '补阳药',
      nature: '温',
      taste: '甘',
      meridian: '肺、肾经',
      functions: '补肾壮阳，补肺平喘，止血化痰',
      indications: '肾阳不足，精血亏虚，阳痿遗精，腰膝酸痛，久咳虚喘，劳嗽痰血',
      usage: '3-9g',
      contraindications: '有表邪者慎用。',
      precautions: '儿童、孕妇及哺乳期妇女慎用。',
      pharmacology: '含虫草酸、虫草素、多糖等成分，具有免疫调节、抗疲劳、抗肿瘤等作用。',
      composition: '主要含虫草酸、虫草素、腺苷、多糖、蛋白质、氨基酸等。',
      processing: '除去杂质，阴干。',
      identification: '由虫体与从虫头部长出的真菌子座相连而成。虫体似蚕，表面深黄色至黄棕色。',
      storage: '置阴凉干燥处，防虫蛀。',
      isPremium: true,
      viewCount: 15234,
      likeCount: 567,
      image: 'bg-gradient-to-br from-purple-400 to-indigo-500',
    },
  ];

  useEffect(() => {
    const loadHerb = () => {
      setLoading(true);
      
      // 模拟API调用延迟
      setTimeout(() => {
        const herbData = herbsData.find(h => h.id === parseInt(id || '0'));
        setHerb(herbData || null);
        setLoading(false);
        
        // 增加浏览量（模拟）
        if (herbData) {
          herbData.viewCount += 1;
        }
      }, 500);
    };

    loadHerb();
  }, [id]);

  const handleLike = () => {
    setIsLiked(!isLiked);
    if (herb) {
      herb.likeCount += isLiked ? -1 : 1;
    }
    toast({
      title: isLiked ? "已取消收藏" : "已添加收藏",
      description: isLiked ? "已从收藏列表中移除" : "已添加到收藏列表",
    });
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
    toast({
      title: isBookmarked ? "已取消书签" : "已添加书签",
      description: isBookmarked ? "已从书签中移除" : "已添加到书签",
    });
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({
      title: "链接已复制",
      description: "页面链接已复制到剪贴板",
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!herb) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center py-20">
          <h1 className="text-4xl font-bold mb-4">404</h1>
          <p className="text-muted-foreground mb-4">未找到相关药材信息</p>
          <Button asChild>
            <Link to="/herbs">返回药材库</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* 面包屑导航 */}
      <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-6">
        <Link to="/" className="hover:text-primary">首页</Link>
        <span>/</span>
        <Link to="/herbs" className="hover:text-primary">中药材库</Link>
        <span>/</span>
        <span className="text-foreground">{herb.name}</span>
      </div>

      {/* 返回按钮 */}
      <Button variant="ghost" asChild className="mb-6">
        <Link to="/herbs">
          <ArrowLeft className="h-4 w-4 mr-2" />
          返回药材库
        </Link>
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* 主要内容 */}
        <div className="lg:col-span-2 space-y-6">
          {/* 药材基本信息 */}
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <CardTitle className="text-3xl">{herb.name}</CardTitle>
                    {herb.isPremium && (
                      <Badge variant="secondary">会员专享</Badge>
                    )}
                  </div>
                  <CardDescription className="text-lg">
                    {herb.pinyin} | {herb.englishName}
                  </CardDescription>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <span className="flex items-center">
                      <Eye className="h-4 w-4 mr-1" />
                      {herb.viewCount} 次浏览
                    </span>
                    <span className="flex items-center">
                      <Heart className="h-4 w-4 mr-1" />
                      {herb.likeCount} 人收藏
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant={isLiked ? "default" : "outline"}
                    size="sm"
                    onClick={handleLike}
                  >
                    <Heart className={`h-4 w-4 mr-2 ${isLiked ? 'fill-current' : ''}`} />
                    {isLiked ? '已收藏' : '收藏'}
                  </Button>
                  <Button
                    variant={isBookmarked ? "default" : "outline"}
                    size="sm"
                    onClick={handleBookmark}
                  >
                    <Bookmark className={`h-4 w-4 mr-2 ${isBookmarked ? 'fill-current' : ''}`} />
                    书签
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleShare}>
                    <Share2 className="h-4 w-4 mr-2" />
                    分享
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                <div>
                  <h4 className="font-medium text-muted-foreground mb-1">药材分类</h4>
                  <Badge variant="outline">{herb.category}</Badge>
                </div>
                <div>
                  <h4 className="font-medium text-muted-foreground mb-1">性味</h4>
                  <p>{herb.nature} {herb.taste}</p>
                </div>
                <div>
                  <h4 className="font-medium text-muted-foreground mb-1">归经</h4>
                  <p>{herb.meridian}</p>
                </div>
                <div>
                  <h4 className="font-medium text-muted-foreground mb-1">用法用量</h4>
                  <p>{herb.usage}</p>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">功效</h4>
                  <p className="text-muted-foreground leading-relaxed">{herb.functions}</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">主治</h4>
                  <p className="text-muted-foreground leading-relaxed">{herb.indications}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 详细信息标签页 */}
          <Card>
            <CardContent className="p-0">
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="details">详细信息</TabsTrigger>
                  <TabsTrigger value="pharmacology">药理作用</TabsTrigger>
                  <TabsTrigger value="processing">炮制方法</TabsTrigger>
                  <TabsTrigger value="identification">性状鉴别</TabsTrigger>
                </TabsList>
                
                <TabsContent value="details" className="p-6 space-y-6">
                  {herb.contraindications && (
                    <div>
                      <h4 className="font-semibold mb-2 text-red-600">禁忌</h4>
                      <p className="text-muted-foreground leading-relaxed">{herb.contraindications}</p>
                    </div>
                  )}
                  
                  {herb.precautions && (
                    <div>
                      <h4 className="font-semibold mb-2 text-orange-600">注意事项</h4>
                      <p className="text-muted-foreground leading-relaxed">{herb.precautions}</p>
                    </div>
                  )}
                  
                  {herb.storage && (
                    <div>
                      <h4 className="font-semibold mb-2">贮藏</h4>
                      <p className="text-muted-foreground leading-relaxed">{herb.storage}</p>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="pharmacology" className="p-6">
                  {herb.pharmacology ? (
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-semibold mb-2">药理作用</h4>
                        <p className="text-muted-foreground leading-relaxed">{herb.pharmacology}</p>
                      </div>
                      
                      {herb.composition && (
                        <div>
                          <h4 className="font-semibold mb-2">化学成分</h4>
                          <p className="text-muted-foreground leading-relaxed">{herb.composition}</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">暂无药理作用信息</p>
                  )}
                </TabsContent>
                
                <TabsContent value="processing" className="p-6">
                  {herb.processing ? (
                    <div>
                      <h4 className="font-semibold mb-2">炮制方法</h4>
                      <p className="text-muted-foreground leading-relaxed">{herb.processing}</p>
                    </div>
                  ) : (
                    <p className="text-muted-foreground">暂无炮制方法信息</p>
                  )}
                </TabsContent>
                
                <TabsContent value="identification" className="p-6">
                  {herb.identification ? (
                    <div>
                      <h4 className="font-semibold mb-2">性状鉴别</h4>
                      <p className="text-muted-foreground leading-relaxed">{herb.identification}</p>
                    </div>
                  ) : (
                    <p className="text-muted-foreground">暂无性状鉴别信息</p>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* 侧边栏 */}
        <div className="space-y-6">
          {/* 药材图片 */}
          <Card>
            <CardContent className="p-6">
              <div className={`w-full h-48 rounded-lg ${herb.image} mb-4`} />
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" className="flex-1">
                  <Download className="h-4 w-4 mr-2" />
                  下载图片
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <PrinterIcon className="h-4 w-4 mr-2" />
                  打印
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* 快速链接 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">相关链接</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="ghost" className="w-full justify-start" asChild>
                <Link to="/formulas">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  相关方剂
                </Link>
              </Button>
              <Button variant="ghost" className="w-full justify-start" asChild>
                <Link to="/search">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  同类药材
                </Link>
              </Button>
              <Button variant="ghost" className="w-full justify-start" asChild>
                <Link to="/resources">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  学习资源
                </Link>
              </Button>
            </CardContent>
          </Card>

          {/* 评分 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">用户评价</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2 mb-3">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className="h-5 w-5 fill-current text-yellow-400"
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">4.8/5</span>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                基于 {Math.floor(herb.viewCount / 10)} 条用户评价
              </p>
              <Button variant="outline" size="sm" className="w-full">
                查看所有评价
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default HerbDetail;
