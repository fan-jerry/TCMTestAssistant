-- 中医学习平台数据库结构
-- 适用于MySQL 8.0+
-- 字符集：utf8mb4

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- 数据库创建
-- ----------------------------
CREATE DATABASE IF NOT EXISTS `tcm_learning` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `tcm_learning`;

-- ----------------------------
-- 用户表
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `email` varchar(100) NOT NULL COMMENT '邮箱',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `password_hash` varchar(255) NOT NULL COMMENT '密码哈希',
  `nickname` varchar(50) NOT NULL COMMENT '昵称',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像URL',
  `gender` tinyint(1) DEFAULT 0 COMMENT '性别 0:未知 1:男 2:女',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:禁用 1:正常',
  `user_type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '用户类型 1:普通用户 2:VIP用户 3:管理员',
  `level` int(11) NOT NULL DEFAULT 1 COMMENT '用户等级',
  `points` int(11) NOT NULL DEFAULT 0 COMMENT '积分',
  `login_count` int(11) NOT NULL DEFAULT 0 COMMENT '登录次数',
  `last_login_at` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(45) DEFAULT NULL COMMENT '最后登录IP',
  `email_verified_at` datetime DEFAULT NULL COMMENT '邮箱验证时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_phone` (`phone`),
  KEY `idx_status` (`status`),
  KEY `idx_user_type` (`user_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ----------------------------
-- 会员套餐表
-- ----------------------------
DROP TABLE IF EXISTS `membership_plans`;
CREATE TABLE `membership_plans` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '套餐ID',
  `name` varchar(50) NOT NULL COMMENT '套餐名称',
  `description` text COMMENT '套餐描述',
  `duration_days` int(11) NOT NULL COMMENT '有效天数',
  `original_price` decimal(10,2) NOT NULL COMMENT '原价',
  `price` decimal(10,2) NOT NULL COMMENT '现价',
  `features` json DEFAULT NULL COMMENT '功能特性',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:下架 1:上架',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员套餐表';

-- ----------------------------
-- 用户会员记录表
-- ----------------------------
DROP TABLE IF EXISTS `user_memberships`;
CREATE TABLE `user_memberships` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `plan_id` int(11) unsigned NOT NULL COMMENT '套餐ID',
  `start_date` date NOT NULL COMMENT '开始日期',
  `end_date` date NOT NULL COMMENT '结束日期',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:过期 1:有效',
  `payment_amount` decimal(10,2) NOT NULL COMMENT '支付金额',
  `payment_method` varchar(20) DEFAULT NULL COMMENT '支付方式',
  `order_no` varchar(64) DEFAULT NULL COMMENT '订单号',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_plan_id` (`plan_id`),
  KEY `idx_status` (`status`),
  KEY `idx_end_date` (`end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户会员记录表';

-- ----------------------------
-- 分类表
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `parent_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '父分类ID',
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  `slug` varchar(50) NOT NULL COMMENT '分类别名',
  `description` text COMMENT '分类描述',
  `icon` varchar(255) DEFAULT NULL COMMENT '分类图标',
  `image` varchar(255) DEFAULT NULL COMMENT '分类图片',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:隐藏 1:显示',
  `type` varchar(20) NOT NULL DEFAULT 'general' COMMENT '分类类型',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分类表';

-- ----------------------------
-- 中药材表
-- ----------------------------
DROP TABLE IF EXISTS `herbs`;
CREATE TABLE `herbs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '中药材ID',
  `name` varchar(100) NOT NULL COMMENT '中药材名称',
  `pinyin` varchar(200) DEFAULT NULL COMMENT '拼音',
  `english_name` varchar(200) DEFAULT NULL COMMENT '英文名',
  `alias` text COMMENT '别名',
  `category_id` int(11) unsigned DEFAULT NULL COMMENT '分类ID',
  `nature` varchar(20) DEFAULT NULL COMMENT '性味：寒、热、温、凉、平',
  `flavor` varchar(50) DEFAULT NULL COMMENT '味：酸、苦、甘、辛、咸',
  `meridian` varchar(100) DEFAULT NULL COMMENT '归经',
  `efficacy` text COMMENT '功效',
  `indication` text COMMENT '主治',
  `usage_dosage` text COMMENT '用法用量',
  `contraindication` text COMMENT '禁忌',
  `chemical_composition` text COMMENT '化学成分',
  `pharmacological_action` text COMMENT '药理作用',
  `clinical_application` text COMMENT '临床应用',
  `processing_method` text COMMENT '炮制方法',
  `storage_method` text COMMENT '贮藏方法',
  `image_url` varchar(255) DEFAULT NULL COMMENT '图片URL',
  `source` varchar(200) DEFAULT NULL COMMENT '来源',
  `harvest_time` varchar(100) DEFAULT NULL COMMENT '采收时间',
  `view_count` int(11) NOT NULL DEFAULT 0 COMMENT '浏览次数',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:下架 1:上架',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_nature` (`nature`),
  KEY `idx_status` (`status`),
  KEY `idx_view_count` (`view_count`),
  FULLTEXT KEY `ft_search` (`name`,`pinyin`,`alias`,`efficacy`,`indication`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='中药材表';

-- ----------------------------
-- 方剂表
-- ----------------------------
DROP TABLE IF EXISTS `formulas`;
CREATE TABLE `formulas` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '方剂ID',
  `name` varchar(100) NOT NULL COMMENT '方剂名称',
  `pinyin` varchar(200) DEFAULT NULL COMMENT '拼音',
  `english_name` varchar(200) DEFAULT NULL COMMENT '英文名',
  `alias` text COMMENT '别名',
  `category_id` int(11) unsigned DEFAULT NULL COMMENT '分类ID',
  `source` varchar(200) DEFAULT NULL COMMENT '出处',
  `composition` text COMMENT '组成',
  `usage_dosage` text COMMENT '用法用量',
  `efficacy` text COMMENT '功效',
  `indication` text COMMENT '主治',
  `pathogenesis` text COMMENT '病机',
  `prescription_analysis` text COMMENT '方解',
  `clinical_application` text COMMENT '临床应用',
  `modern_research` text COMMENT '现代研究',
  `precautions` text COMMENT '注意事项',
  `similar_formulas` text COMMENT '类似方剂',
  `view_count` int(11) NOT NULL DEFAULT 0 COMMENT '浏览次数',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:下架 1:上架',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_status` (`status`),
  KEY `idx_view_count` (`view_count`),
  FULLTEXT KEY `ft_search` (`name`,`pinyin`,`alias`,`efficacy`,`indication`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='方剂表';

-- ----------------------------
-- 穴位表
-- ----------------------------
DROP TABLE IF EXISTS `acupoints`;
CREATE TABLE `acupoints` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '穴位ID',
  `name` varchar(50) NOT NULL COMMENT '穴位名称',
  `pinyin` varchar(100) DEFAULT NULL COMMENT '拼音',
  `english_name` varchar(100) DEFAULT NULL COMMENT '英文名',
  `code` varchar(20) DEFAULT NULL COMMENT '穴位代码',
  `meridian` varchar(50) DEFAULT NULL COMMENT '所属经络',
  `location` text COMMENT '定位',
  `anatomy` text COMMENT '解剖',
  `function` text COMMENT '功能主治',
  `needle_method` text COMMENT '针刺方法',
  `moxibustion_method` text COMMENT '艾灸方法',
  `clinical_application` text COMMENT '临床应用',
  `precautions` text COMMENT '注意事项',
  `image_url` varchar(255) DEFAULT NULL COMMENT '图片URL',
  `view_count` int(11) NOT NULL DEFAULT 0 COMMENT '浏览次数',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:下架 1:上架',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_meridian` (`meridian`),
  KEY `idx_status` (`status`),
  KEY `idx_view_count` (`view_count`),
  FULLTEXT KEY `ft_search` (`name`,`pinyin`,`function`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='穴位表';

-- ----------------------------
-- 文章表
-- ----------------------------
DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `title` varchar(200) NOT NULL COMMENT '文章标题',
  `slug` varchar(200) DEFAULT NULL COMMENT '文章别名',
  `summary` text COMMENT '文章摘要',
  `content` longtext COMMENT '文章内容',
  `cover_image` varchar(255) DEFAULT NULL COMMENT '封面图片',
  `category_id` int(11) unsigned DEFAULT NULL COMMENT '分类ID',
  `author_id` bigint(20) unsigned NOT NULL COMMENT '作者ID',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:草稿 1:已发布 2:已下架',
  `is_featured` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否推荐',
  `is_top` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否置顶',
  `view_count` int(11) NOT NULL DEFAULT 0 COMMENT '浏览次数',
  `like_count` int(11) NOT NULL DEFAULT 0 COMMENT '点赞次数',
  `comment_count` int(11) NOT NULL DEFAULT 0 COMMENT '评论次数',
  `share_count` int(11) NOT NULL DEFAULT 0 COMMENT '分享次数',
  `published_at` datetime DEFAULT NULL COMMENT '发布时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_author_id` (`author_id`),
  KEY `idx_status` (`status`),
  KEY `idx_published_at` (`published_at`),
  KEY `idx_view_count` (`view_count`),
  FULLTEXT KEY `ft_search` (`title`,`summary`,`content`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='文章表';

-- ----------------------------
-- 测试题库表
-- ----------------------------
DROP TABLE IF EXISTS `quiz_questions`;
CREATE TABLE `quiz_questions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '题目ID',
  `category_id` int(11) unsigned DEFAULT NULL COMMENT '分类ID',
  `type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '题型 1:单选 2:多选 3:判断 4:填空',
  `question` text NOT NULL COMMENT '题目内容',
  `options` json DEFAULT NULL COMMENT '选项（JSON格式）',
  `correct_answer` text NOT NULL COMMENT '正确答案',
  `explanation` text COMMENT '解析',
  `difficulty` tinyint(1) NOT NULL DEFAULT 1 COMMENT '难度 1:易 2:中 3:难',
  `points` int(11) NOT NULL DEFAULT 1 COMMENT '分值',
  `use_count` int(11) NOT NULL DEFAULT 0 COMMENT '使用次数',
  `correct_rate` decimal(5,2) DEFAULT 0.00 COMMENT '正确率',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:禁用 1:启用',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_type` (`type`),
  KEY `idx_difficulty` (`difficulty`),
  KEY `idx_status` (`status`),
  FULLTEXT KEY `ft_question` (`question`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='测试题库表';

-- ----------------------------
-- 测试记录表
-- ----------------------------
DROP TABLE IF EXISTS `quiz_records`;
CREATE TABLE `quiz_records` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '用户ID（游客为NULL）',
  `session_id` varchar(64) DEFAULT NULL COMMENT '会话ID（用于游客）',
  `category_id` int(11) unsigned DEFAULT NULL COMMENT '分类ID',
  `total_questions` int(11) NOT NULL COMMENT '总题数',
  `correct_answers` int(11) NOT NULL DEFAULT 0 COMMENT '正确题数',
  `score` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT '得分',
  `time_spent` int(11) NOT NULL DEFAULT 0 COMMENT '用时（秒）',
  `answers` json DEFAULT NULL COMMENT '答题记录（JSON格式）',
  `completed_at` datetime DEFAULT NULL COMMENT '完成时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_score` (`score`),
  KEY `idx_completed_at` (`completed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='测试记录表';

-- ----------------------------
-- 学习资源表
-- ----------------------------
DROP TABLE IF EXISTS `learning_resources`;
CREATE TABLE `learning_resources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '资源ID',
  `title` varchar(200) NOT NULL COMMENT '资源标题',
  `description` text COMMENT '资源描述',
  `type` varchar(20) NOT NULL COMMENT '资源类型：video,audio,pdf,ppt,doc',
  `file_url` varchar(500) DEFAULT NULL COMMENT '文件URL',
  `file_size` bigint(20) DEFAULT NULL COMMENT '文件大小（字节）',
  `duration` int(11) DEFAULT NULL COMMENT '时长（秒）',
  `category_id` int(11) unsigned DEFAULT NULL COMMENT '分类ID',
  `author_id` bigint(20) unsigned DEFAULT NULL COMMENT '上传者ID',
  `is_free` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否免费',
  `required_level` tinyint(1) NOT NULL DEFAULT 1 COMMENT '所需会员等级',
  `download_count` int(11) NOT NULL DEFAULT 0 COMMENT '下载次数',
  `view_count` int(11) NOT NULL DEFAULT 0 COMMENT '浏览次数',
  `rating` decimal(3,2) DEFAULT 0.00 COMMENT '评分',
  `rating_count` int(11) NOT NULL DEFAULT 0 COMMENT '评分人数',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:下架 1:上架',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_author_id` (`author_id`),
  KEY `idx_is_free` (`is_free`),
  KEY `idx_status` (`status`),
  FULLTEXT KEY `ft_search` (`title`,`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='学习资源表';

-- ----------------------------
-- 评论表
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `target_type` varchar(20) NOT NULL COMMENT '目标类型：article,resource,herb,formula,acupoint',
  `target_id` bigint(20) unsigned NOT NULL COMMENT '目标ID',
  `parent_id` bigint(20) unsigned DEFAULT NULL COMMENT '父评论ID',
  `content` text NOT NULL COMMENT '评论内容',
  `rating` tinyint(1) DEFAULT NULL COMMENT '评分（1-5）',
  `like_count` int(11) NOT NULL DEFAULT 0 COMMENT '点赞次数',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 0:隐藏 1:显示',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_target` (`target_type`,`target_id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评论表';

-- ----------------------------
-- 用户收藏表
-- ----------------------------
DROP TABLE IF EXISTS `user_favorites`;
CREATE TABLE `user_favorites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '收藏ID',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `target_type` varchar(20) NOT NULL COMMENT '收藏类型：article,resource,herb,formula,acupoint',
  `target_id` bigint(20) unsigned NOT NULL COMMENT '目标ID',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_target` (`user_id`,`target_type`,`target_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_target` (`target_type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户收藏表';

-- ----------------------------
-- 学习进度表
-- ----------------------------
DROP TABLE IF EXISTS `learning_progress`;
CREATE TABLE `learning_progress` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '进度ID',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `resource_id` bigint(20) unsigned NOT NULL COMMENT '资源ID',
  `progress_percent` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT '进度百分比',
  `last_position` int(11) DEFAULT NULL COMMENT '最后播放位置（秒）',
  `completed_at` datetime DEFAULT NULL COMMENT '完成时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_resource` (`user_id`,`resource_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='学习进度表';

-- ----------------------------
-- 系统配置表
-- ----------------------------
DROP TABLE IF EXISTS `system_configs`;
CREATE TABLE `system_configs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `key` varchar(100) NOT NULL COMMENT '配置键',
  `value` text COMMENT '配置值',
  `description` varchar(255) DEFAULT NULL COMMENT '配置描述',
  `type` varchar(20) NOT NULL DEFAULT 'string' COMMENT '数据类型',
  `group` varchar(50) DEFAULT 'general' COMMENT '配置分组',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_key` (`key`),
  KEY `idx_group` (`group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统配置表';

-- ----------------------------
-- 操作日志表
-- ----------------------------
DROP TABLE IF EXISTS `operation_logs`;
CREATE TABLE `operation_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '操作用户ID',
  `action` varchar(50) NOT NULL COMMENT '操作动作',
  `resource_type` varchar(20) DEFAULT NULL COMMENT '资源类型',
  `resource_id` bigint(20) unsigned DEFAULT NULL COMMENT '资源ID',
  `description` text COMMENT '操作描述',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IP地址',
  `user_agent` text COMMENT '用户代理',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_resource` (`resource_type`,`resource_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作日志表';

SET FOREIGN_KEY_CHECKS = 1;