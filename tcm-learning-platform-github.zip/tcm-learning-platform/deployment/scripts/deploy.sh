#!/bin/bash

# 中医学习网站自动部署脚本
# 适用于 CentOS 7.9 + 宝塔面板环境

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查是否为root用户
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "请使用root用户运行此脚本"
        exit 1
    fi
}

# 检查系统版本
check_system() {
    if ! grep -q "CentOS Linux release 7" /etc/redhat-release 2>/dev/null; then
        log_warning "当前系统不是CentOS 7，可能存在兼容性问题"
    fi
}

# 检查宝塔面板
check_bt_panel() {
    if ! command -v bt &> /dev/null; then
        log_error "未检测到宝塔面板，请先安装宝塔面板"
        log_info "安装命令: yum install -y wget && wget -O install.sh http://download.bt.cn/install/install_6.0.sh && sh install.sh"
        exit 1
    fi
}

# 配置变量
PROJECT_NAME="tcm-learning"
PROJECT_ROOT="/www/wwwroot/${PROJECT_NAME}"
BACKUP_DIR="/www/backup/${PROJECT_NAME}"
LOG_DIR="/www/wwwroot/${PROJECT_NAME}/logs"

# 数据库配置（请根据实际情况修改）
DB_NAME="tcm_learning"
DB_USER="tcm_user"
DB_PASS="tcm_123456"  # 请修改为强密码

# 创建必要目录
create_directories() {
    log_info "创建项目目录结构..."
    
    mkdir -p ${PROJECT_ROOT}/{frontend,backend,database,nginx,scripts,logs,uploads}
    mkdir -p ${BACKUP_DIR}
    mkdir -p ${LOG_DIR}
    
    log_success "目录结构创建完成"
}

# 检查并安装Python依赖
install_python_deps() {
    log_info "检查Python环境..."
    
    if ! command -v python3 &> /dev/null; then
        log_info "安装Python3..."
        yum install -y python3 python3-pip python3-devel
    fi
    
    if ! command -v pip3 &> /dev/null; then
        log_info "安装pip3..."
        yum install -y python3-pip
    fi
    
    # 升级pip
    pip3 install --upgrade pip
    
    log_success "Python环境检查完成"
}

# 创建Python虚拟环境
setup_python_venv() {
    log_info "创建Python虚拟环境..."
    
    cd ${PROJECT_ROOT}/backend
    
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        log_success "虚拟环境创建完成"
    else
        log_info "虚拟环境已存在"
    fi
    
    # 激活虚拟环境并安装依赖
    source venv/bin/activate
    
    if [ -f "requirements.txt" ]; then
        log_info "安装Python依赖包..."
        pip install -r requirements.txt
        log_success "Python依赖安装完成"
    else
        log_warning "未找到requirements.txt文件"
    fi
}

# 配置数据库
setup_database() {
    log_info "配置数据库..."
    
    # 检查MySQL服务
    if ! systemctl is-active --quiet mysqld; then
        log_error "MySQL服务未运行，请先启动MySQL服务"
        log_info "可以在宝塔面板中启动MySQL服务"
        return 1
    fi
    
    # 创建数据库和用户（如果不存在）
    mysql -u root -p -e "
        CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
        CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
        GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';
        FLUSH PRIVILEGES;
    " 2>/dev/null || log_warning "数据库配置可能需要手动完成"
    
    # 导入数据库结构
    if [ -f "${PROJECT_ROOT}/database/schema.sql" ]; then
        log_info "导入数据库结构..."
        mysql -u ${DB_USER} -p${DB_PASS} ${DB_NAME} < ${PROJECT_ROOT}/database/schema.sql
        log_success "数据库结构导入完成"
    fi
    
    # 导入初始数据
    if [ -f "${PROJECT_ROOT}/database/init_data.sql" ]; then
        log_info "导入初始数据..."
        mysql -u ${DB_USER} -p${DB_PASS} ${DB_NAME} < ${PROJECT_ROOT}/database/init_data.sql
        log_success "初始数据导入完成"
    fi
}

# 配置后端服务
setup_backend() {
    log_info "配置后端服务..."
    
    cd ${PROJECT_ROOT}/backend
    
    # 创建配置文件
    if [ ! -f "config.py" ] && [ -f "config.example.py" ]; then
        cp config.example.py config.py
        
        # 替换配置参数
        sed -i "s/your-secret-key-here/$(openssl rand -hex 32)/g" config.py
        sed -i "s/your_db_password/${DB_PASS}/g" config.py
        sed -i "s/your_db_name/${DB_NAME}/g" config.py
        sed -i "s/your_db_user/${DB_USER}/g" config.py
        
        log_success "配置文件创建完成"
    fi
    
    # 设置文件权限
    chown -R www:www ${PROJECT_ROOT}/backend
    chmod -R 755 ${PROJECT_ROOT}/backend
}

# 安装和配置PM2
setup_pm2() {
    log_info "配置PM2进程管理器..."
    
    if ! command -v pm2 &> /dev/null; then
        log_info "安装PM2..."
        npm install -g pm2
    fi
    
    cd ${PROJECT_ROOT}/backend
    
    # 创建PM2配置文件
    cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'tcm-learning-api',
    script: 'venv/bin/python',
    args: 'app.py',
    cwd: '${PROJECT_ROOT}/backend',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      PORT: 5000,
      FLASK_ENV: 'production'
    },
    error_file: '${LOG_DIR}/api_error.log',
    out_file: '${LOG_DIR}/api_out.log',
    log_file: '${LOG_DIR}/api_combined.log',
    time: true
  }]
};
EOF
    
    log_success "PM2配置完成"
}

# 配置前端
setup_frontend() {
    log_info "配置前端静态文件..."
    
    # 设置前端文件权限
    if [ -d "${PROJECT_ROOT}/frontend" ]; then
        chown -R www:www ${PROJECT_ROOT}/frontend
        chmod -R 755 ${PROJECT_ROOT}/frontend
        log_success "前端文件权限设置完成"
    fi
}

# 配置Nginx（生成配置文件）
setup_nginx() {
    log_info "生成Nginx配置..."
    
    cat > ${PROJECT_ROOT}/nginx/tcm-learning.conf << 'EOF'
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;
    
    # 重定向到HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com www.your-domain.com;
    
    # SSL证书配置（请修改为实际路径）
    ssl_certificate /www/server/panel/vhost/cert/your-domain.com/fullchain.pem;
    ssl_certificate_key /www/server/panel/vhost/cert/your-domain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
    ssl_prefer_server_ciphers on;
    
    # 网站根目录
    root /www/wwwroot/tcm-learning/frontend;
    index index.html;
    
    # 日志文件
    access_log /www/wwwroot/tcm-learning/logs/access.log;
    error_log /www/wwwroot/tcm-learning/logs/error.log;
    
    # 启用Gzip压缩
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml
        application/rss+xml
        application/atom+xml
        image/svg+xml;
    
    # 静态文件缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        add_header Vary Accept-Encoding;
        access_log off;
    }
    
    # API代理
    location /api/ {
        proxy_pass http://127.0.0.1:5000/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # CORS headers
        add_header Access-Control-Allow-Origin $http_origin always;
        add_header Access-Control-Allow-Credentials true always;
        add_header Access-Control-Allow-Methods 'GET, POST, PUT, DELETE, OPTIONS' always;
        add_header Access-Control-Allow-Headers 'DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Authorization' always;
        
        if ($request_method = 'OPTIONS') {
            return 204;
        }
    }
    
    # 文件上传
    location /uploads/ {
        alias /www/wwwroot/tcm-learning/uploads/;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }
    
    # SPA路由支持
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # 安全头部
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline' 'unsafe-eval'" always;
    
    # 隐藏服务器信息
    server_tokens off;
}
EOF
    
    log_success "Nginx配置文件生成完成"
    log_warning "请根据实际域名修改 ${PROJECT_ROOT}/nginx/tcm-learning.conf"
}

# 设置日志轮转
setup_logrotate() {
    log_info "配置日志轮转..."
    
    cat > /etc/logrotate.d/tcm-learning << EOF
${LOG_DIR}/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 www www
    postrotate
        # 重启相关服务以重新打开日志文件
        pm2 reload tcm-learning-api || true
        systemctl reload nginx || true
    endscript
}
EOF
    
    log_success "日志轮转配置完成"
}

# 创建系统服务脚本
create_service_scripts() {
    log_info "创建服务管理脚本..."
    
    # 启动脚本
    cat > ${PROJECT_ROOT}/scripts/start.sh << 'EOF'
#!/bin/bash
echo "启动中医学习平台服务..."

# 启动后端API
cd /www/wwwroot/tcm-learning/backend
pm2 start ecosystem.config.js

# 检查服务状态
sleep 3
pm2 status

echo "服务启动完成！"
EOF

    # 停止脚本
    cat > ${PROJECT_ROOT}/scripts/stop.sh << 'EOF'
#!/bin/bash
echo "停止中医学习平台服务..."

# 停止后端API
pm2 stop tcm-learning-api

echo "服务停止完成！"
EOF

    # 重启脚本
    cat > ${PROJECT_ROOT}/scripts/restart.sh << 'EOF'
#!/bin/bash
echo "重启中医学习平台服务..."

# 重启后端API
cd /www/wwwroot/tcm-learning/backend
pm2 restart ecosystem.config.js

echo "服务重启完成！"
EOF

    # 状态检查脚本
    cat > ${PROJECT_ROOT}/scripts/status.sh << 'EOF'
#!/bin/bash
echo "=== 中医学习平台服务状态 ==="

echo "1. PM2进程状态:"
pm2 status

echo ""
echo "2. 后端API健康检查:"
curl -s http://localhost:5000/api/health || echo "API服务异常"

echo ""
echo "3. 数据库连接检查:"
mysql -u tcm_user -ptcm_123456 -e "SELECT 1" tcm_learning 2>/dev/null && echo "数据库连接正常" || echo "数据库连接异常"

echo ""
echo "4. Nginx状态:"
systemctl is-active nginx

echo ""
echo "5. 磁盘使用情况:"
df -h /www/wwwroot/tcm-learning

echo ""
echo "6. 内存使用情况:"
free -h
EOF

    # 备份脚本
    cat > ${PROJECT_ROOT}/scripts/backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/www/backup/tcm-learning"
DATE=$(date +%Y%m%d_%H%M%S)

echo "开始备份中医学习平台..."

# 创建备份目录
mkdir -p ${BACKUP_DIR}

# 备份数据库
echo "备份数据库..."
mysqldump -u tcm_user -ptcm_123456 tcm_learning > ${BACKUP_DIR}/database_${DATE}.sql

# 备份上传文件
echo "备份上传文件..."
tar -czf ${BACKUP_DIR}/uploads_${DATE}.tar.gz -C /www/wwwroot/tcm-learning uploads/

# 清理旧备份（保留7天）
find ${BACKUP_DIR} -name "*.sql" -mtime +7 -delete
find ${BACKUP_DIR} -name "*.tar.gz" -mtime +7 -delete

echo "备份完成！备份文件保存在: ${BACKUP_DIR}"
EOF

    # 设置执行权限
    chmod +x ${PROJECT_ROOT}/scripts/*.sh
    
    log_success "服务管理脚本创建完成"
}

# 设置定时任务
setup_crontab() {
    log_info "设置定时任务..."
    
    # 添加定时备份任务（每天凌晨2点备份）
    (crontab -l 2>/dev/null; echo "0 2 * * * ${PROJECT_ROOT}/scripts/backup.sh >/dev/null 2>&1") | crontab -
    
    # 添加日志清理任务（每周日凌晨清理）
    (crontab -l 2>/dev/null; echo "0 3 * * 0 /usr/sbin/logrotate /etc/logrotate.d/tcm-learning -f >/dev/null 2>&1") | crontab -
    
    log_success "定时任务设置完成"
}

# 启动服务
start_services() {
    log_info "启动服务..."
    
    # 启动后端API
    cd ${PROJECT_ROOT}/backend
    pm2 start ecosystem.config.js
    pm2 save
    
    # 设置PM2开机启动
    pm2 startup systemd -u root --hp /root
    
    log_success "服务启动完成"
}

# 安全加固
security_hardening() {
    log_info "安全加固..."
    
    # 设置文件权限
    chown -R www:www ${PROJECT_ROOT}
    chmod -R 755 ${PROJECT_ROOT}
    chmod 600 ${PROJECT_ROOT}/backend/config.py
    
    # 设置上传目录权限
    mkdir -p ${PROJECT_ROOT}/uploads
    chown www:www ${PROJECT_ROOT}/uploads
    chmod 755 ${PROJECT_ROOT}/uploads
    
    log_success "安全加固完成"
}

# 性能优化
performance_optimization() {
    log_info "性能优化..."
    
    # 系统参数优化
    cat >> /etc/sysctl.conf << EOF

# TCM Learning Platform Optimization
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 5000
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_tw_recycle = 1
EOF
    
    sysctl -p
    
    # 增加文件描述符限制
    cat >> /etc/security/limits.conf << EOF
www soft nofile 65535
www hard nofile 65535
EOF
    
    log_success "性能优化完成"
}

# 部署后检查
post_deploy_check() {
    log_info "部署后检查..."
    
    # 检查服务状态
    sleep 5
    
    if pm2 list | grep -q "tcm-learning-api.*online"; then
        log_success "后端API服务运行正常"
    else
        log_error "后端API服务异常"
        pm2 logs tcm-learning-api --lines 20
    fi
    
    # 检查端口监听
    if netstat -tlnp | grep -q ":5000.*LISTEN"; then
        log_success "API端口5000监听正常"
    else
        log_error "API端口5000未监听"
    fi
    
    # 检查数据库连接
    if mysql -u ${DB_USER} -p${DB_PASS} -e "SELECT 1" ${DB_NAME} 2>/dev/null; then
        log_success "数据库连接正常"
    else
        log_error "数据库连接异常"
    fi
}

# 显示部署信息
show_deploy_info() {
    log_success "=== 部署完成 ==="
    echo ""
    echo "项目路径: ${PROJECT_ROOT}"
    echo "日志路径: ${LOG_DIR}"
    echo "备份路径: ${BACKUP_DIR}"
    echo ""
    echo "数据库信息:"
    echo "  数据库名: ${DB_NAME}"
    echo "  用户名: ${DB_USER}"
    echo "  密码: ${DB_PASS}"
    echo ""
    echo "服务管理命令:"
    echo "  启动服务: ${PROJECT_ROOT}/scripts/start.sh"
    echo "  停止服务: ${PROJECT_ROOT}/scripts/stop.sh"
    echo "  重启服务: ${PROJECT_ROOT}/scripts/restart.sh"
    echo "  查看状态: ${PROJECT_ROOT}/scripts/status.sh"
    echo "  备份数据: ${PROJECT_ROOT}/scripts/backup.sh"
    echo ""
    echo "下一步操作:"
    echo "1. 在宝塔面板中创建网站，根目录设置为: ${PROJECT_ROOT}/frontend"
    echo "2. 配置域名和SSL证书"
    echo "3. 导入Nginx配置: ${PROJECT_ROOT}/nginx/tcm-learning.conf"
    echo "4. 修改配置文件中的域名信息"
    echo "5. 重启Nginx服务"
    echo ""
    log_warning "请记录好数据库密码等重要信息！"
}

# 主函数
main() {
    log_info "开始部署中医学习网站..."
    
    # 基础检查
    check_root
    check_system
    check_bt_panel
    
    # 部署步骤
    create_directories
    install_python_deps
    setup_python_venv
    setup_database
    setup_backend
    setup_pm2
    setup_frontend
    setup_nginx
    setup_logrotate
    create_service_scripts
    setup_crontab
    start_services
    security_hardening
    performance_optimization
    post_deploy_check
    show_deploy_info
    
    log_success "部署完成！"
}

# 错误处理
trap 'log_error "部署过程中发生错误，请检查日志"; exit 1' ERR

# 执行主函数
main "$@"
