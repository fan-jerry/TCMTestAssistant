#!/bin/bash

# 中医学习平台服务启动脚本

set -e

# 颜色定义
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

PROJECT_ROOT="/www/wwwroot/tcm-learning"
LOG_DIR="${PROJECT_ROOT}/logs"

echo -e "${BLUE}正在启动中医学习平台服务...${NC}"

# 检查项目目录
if [ ! -d "$PROJECT_ROOT" ]; then
    echo -e "${RED}错误：项目目录不存在 $PROJECT_ROOT${NC}"
    exit 1
fi

# 确保日志目录存在
mkdir -p "$LOG_DIR"

# 进入后端目录
cd "${PROJECT_ROOT}/backend"

# 检查虚拟环境
if [ ! -d "venv" ]; then
    echo -e "${RED}错误：Python虚拟环境不存在，请先运行部署脚本${NC}"
    exit 1
fi

# 激活虚拟环境
source venv/bin/activate

# 检查配置文件
if [ ! -f "config.py" ]; then
    echo -e "${RED}错误：配置文件 config.py 不存在${NC}"
    exit 1
fi

# 检查PM2配置文件
if [ ! -f "ecosystem.config.js" ]; then
    echo -e "${RED}错误：PM2配置文件不存在${NC}"
    exit 1
fi

# 启动后端API服务
echo -e "${BLUE}启动后端API服务...${NC}"
pm2 start ecosystem.config.js

# 等待服务启动
sleep 3

# 检查服务状态
if pm2 list | grep -q "tcm-learning-api.*online"; then
    echo -e "${GREEN}✓ 后端API服务启动成功${NC}"
else
    echo -e "${RED}✗ 后端API服务启动失败${NC}"
    pm2 logs tcm-learning-api --lines 10
    exit 1
fi

# 保存PM2配置
pm2 save

# 检查端口监听
if netstat -tlnp 2>/dev/null | grep -q ":5000.*LISTEN"; then
    echo -e "${GREEN}✓ API端口5000监听正常${NC}"
else
    echo -e "${RED}✗ API端口5000未监听${NC}"
fi

# 测试API健康检查
echo -e "${BLUE}测试API健康检查...${NC}"
sleep 2
if curl -s http://localhost:5000/api/health >/dev/null 2>&1; then
    echo -e "${GREEN}✓ API健康检查通过${NC}"
else
    echo -e "${RED}✗ API健康检查失败${NC}"
fi

# 显示服务状态
echo ""
echo -e "${BLUE}=== 服务状态 ===${NC}"
pm2 status

echo ""
echo -e "${GREEN}中医学习平台服务启动完成！${NC}"
echo ""
echo "访问信息："
echo "  前端地址: http://your-domain.com"
echo "  API地址: http://your-domain.com/api"
echo "  API健康检查: http://your-domain.com/api/health"
echo ""
echo "管理命令："
echo "  查看状态: ${PROJECT_ROOT}/scripts/status.sh"
echo "  停止服务: ${PROJECT_ROOT}/scripts/stop.sh"
echo "  重启服务: ${PROJECT_ROOT}/scripts/restart.sh"
echo "  查看日志: pm2 logs tcm-learning-api"
echo ""
