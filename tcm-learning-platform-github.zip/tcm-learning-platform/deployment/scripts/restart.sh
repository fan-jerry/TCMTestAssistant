#!/bin/bash

# 中医学习平台服务重启脚本

set -e

# 颜色定义
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

PROJECT_ROOT="/www/wwwroot/tcm-learning"

echo -e "${BLUE}正在重启中医学习平台服务...${NC}"

# 进入后端目录
cd "${PROJECT_ROOT}/backend"

# 检查PM2配置文件
if [ ! -f "ecosystem.config.js" ]; then
    echo -e "${RED}错误：PM2配置文件不存在${NC}"
    exit 1
fi

# 重启后端API服务
echo -e "${BLUE}重启后端API服务...${NC}"

if pm2 list | grep -q "tcm-learning-api"; then
    # 如果服务存在，重启它
    pm2 restart ecosystem.config.js
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ 后端API服务重启成功${NC}"
    else
        echo -e "${RED}✗ 后端API服务重启失败${NC}"
        pm2 logs tcm-learning-api --lines 10
        exit 1
    fi
else
    # 如果服务不存在，启动它
    echo -e "${BLUE}服务未运行，正在启动...${NC}"
    source venv/bin/activate
    pm2 start ecosystem.config.js
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ 后端API服务启动成功${NC}"
    else
        echo -e "${RED}✗ 后端API服务启动失败${NC}"
        pm2 logs tcm-learning-api --lines 10
        exit 1
    fi
fi

# 等待服务完全启动
echo -e "${BLUE}等待服务完全启动...${NC}"
sleep 5

# 检查服务状态
if pm2 list | grep -q "tcm-learning-api.*online"; then
    echo -e "${GREEN}✓ 后端API服务运行正常${NC}"
else
    echo -e "${RED}✗ 后端API服务异常${NC}"
    pm2 logs tcm-learning-api --lines 20
    exit 1
fi

# 保存PM2配置
pm2 save

# 检查端口监听
if netstat -tlnp 2>/dev/null | grep -q ":5000.*LISTEN"; then
    echo -e "${GREEN}✓ API端口5000监听正常${NC}"
else
    echo -e "${RED}✗ API端口5000未监听${NC}"
fi

# 测试API健康检查
echo -e "${BLUE}测试API健康检查...${NC}"
if curl -s http://localhost:5000/api/health >/dev/null 2>&1; then
    echo -e "${GREEN}✓ API健康检查通过${NC}"
else
    echo -e "${RED}✗ API健康检查失败${NC}"
fi

# 显示服务状态
echo ""
echo -e "${BLUE}=== 服务状态 ===${NC}"
pm2 status

echo ""
echo -e "${GREEN}中医学习平台服务重启完成！${NC}"
echo ""
echo "访问信息："
echo "  前端地址: http://your-domain.com"
echo "  API地址: http://your-domain.com/api"
echo "  API健康检查: http://your-domain.com/api/health"
echo ""
