#!/bin/bash

# 中医学习平台服务停止脚本

set -e

# 颜色定义
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}正在停止中医学习平台服务...${NC}"

# 停止后端API服务
echo -e "${BLUE}停止后端API服务...${NC}"

if pm2 list | grep -q "tcm-learning-api"; then
    pm2 stop tcm-learning-api
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ 后端API服务已停止${NC}"
    else
        echo -e "${RED}✗ 停止后端API服务失败${NC}"
        exit 1
    fi
else
    echo -e "${YELLOW}⚠ 后端API服务未运行${NC}"
fi

# 检查进程是否完全停止
echo -e "${BLUE}检查服务状态...${NC}"
sleep 2

if pm2 list | grep -q "tcm-learning-api.*stopped"; then
    echo -e "${GREEN}✓ 所有服务已完全停止${NC}"
elif pm2 list | grep -q "tcm-learning-api.*online"; then
    echo -e "${RED}✗ 部分服务仍在运行${NC}"
    pm2 status
    exit 1
else
    echo -e "${GREEN}✓ 服务停止确认${NC}"
fi

# 显示最终状态
echo ""
echo -e "${BLUE}=== 服务状态 ===${NC}"
pm2 status

echo ""
echo -e "${GREEN}中医学习平台服务已停止！${NC}"
echo ""
echo "重新启动服务: /www/wwwroot/tcm-learning/scripts/start.sh"
echo ""
