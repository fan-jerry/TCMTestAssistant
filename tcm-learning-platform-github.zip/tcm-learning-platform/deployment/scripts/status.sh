#!/bin/bash

# 中医学习平台服务状态检查脚本

# 颜色定义
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

PROJECT_ROOT="/www/wwwroot/tcm-learning"

echo -e "${BLUE}=== 中医学习平台服务状态检查 ===${NC}"
echo ""

# 1. 检查PM2进程状态
echo -e "${BLUE}1. PM2进程状态:${NC}"
if command -v pm2 >/dev/null 2>&1; then
    pm2 status
    echo ""
    
    # 检查具体服务状态
    if pm2 list | grep -q "tcm-learning-api.*online"; then
        echo -e "${GREEN}✓ 后端API服务运行正常${NC}"
    elif pm2 list | grep -q "tcm-learning-api.*stopped"; then
        echo -e "${RED}✗ 后端API服务已停止${NC}"
    elif pm2 list | grep -q "tcm-learning-api.*error"; then
        echo -e "${RED}✗ 后端API服务运行异常${NC}"
    else
        echo -e "${YELLOW}⚠ 后端API服务未找到${NC}"
    fi
else\n    echo -e "${RED}✗ PM2未安装或不可用${NC}"
fi

echo ""

# 2. 检查端口监听状态
echo -e "${BLUE}2. 端口监听状态:${NC}"
if netstat -tlnp 2>/dev/null | grep -q ":5000.*LISTEN"; then
    echo -e "${GREEN}✓ API端口5000监听正常${NC}"
    netstat -tlnp 2>/dev/null | grep ":5000.*LISTEN"
else
    echo -e "${RED}✗ API端口5000未监听${NC}"
fi

echo ""

# 3. 检查API健康状态
echo -e "${BLUE}3. API健康检查:${NC}"
if curl -s -m 5 http://localhost:5000/api/health >/dev/null 2>&1; then
    echo -e "${GREEN}✓ API服务健康检查通过${NC}"
    # 显示详细信息
    api_response=$(curl -s -m 5 http://localhost:5000/api/health 2>/dev/null || echo "请求失败")
    echo "   响应: $api_response"
else
    echo -e "${RED}✗ API服务健康检查失败${NC}"
fi

echo ""

# 4. 检查数据库连接
echo -e "${BLUE}4. 数据库连接检查:${NC}"
if command -v mysql >/dev/null 2>&1; then
    if mysql -u tcm_user -ptcm_123456 -e "SELECT 1" tcm_learning 2>/dev/null; then
        echo -e "${GREEN}✓ 数据库连接正常${NC}"
    else
        echo -e "${RED}✗ 数据库连接失败${NC}"
    fi
else
    echo -e "${YELLOW}⚠ MySQL客户端未安装${NC}"
fi

echo ""

# 5. 检查Nginx状态
echo -e "${BLUE}5. Nginx服务状态:${NC}"
if systemctl is-active --quiet nginx 2>/dev/null; then
    echo -e "${GREEN}✓ Nginx服务运行正常${NC}"
elif systemctl is-enabled --quiet nginx 2>/dev/null; then
    echo -e "${YELLOW}⚠ Nginx服务已安装但未运行${NC}"
else
    echo -e "${RED}✗ Nginx服务未安装或不可用${NC}"
fi

echo ""

# 6. 检查磁盘使用情况
echo -e "${BLUE}6. 磁盘使用情况:${NC}"
if [ -d "$PROJECT_ROOT" ]; then
    df -h "$PROJECT_ROOT" | grep -v "Filesystem"
    echo ""
    
    # 检查日志文件大小
    if [ -d "${PROJECT_ROOT}/logs" ]; then
        log_size=$(du -sh "${PROJECT_ROOT}/logs" 2>/dev/null | cut -f1)
        echo "   日志目录大小: $log_size"
    fi
    
    # 检查上传文件大小
    if [ -d "${PROJECT_ROOT}/uploads" ]; then
        upload_size=$(du -sh "${PROJECT_ROOT}/uploads" 2>/dev/null | cut -f1)
        echo "   上传目录大小: $upload_size"
    fi
else
    echo -e "${RED}✗ 项目目录不存在: $PROJECT_ROOT${NC}"
fi

echo ""

# 7. 检查内存使用情况
echo -e "${BLUE}7. 内存使用情况:${NC}"
free -h

echo ""

# 8. 检查系统负载
echo -e "${BLUE}8. 系统负载:${NC}"
uptime

echo ""

# 9. 检查最近的错误日志
echo -e "${BLUE}9. 最近的错误日志:${NC}"
if [ -f "${PROJECT_ROOT}/logs/api_error.log" ]; then
    error_count=$(tail -n 100 "${PROJECT_ROOT}/logs/api_error.log" 2>/dev/null | wc -l)
    if [ "$error_count" -gt 0 ]; then
        echo -e "${YELLOW}⚠ 发现 $error_count 条最近的错误日志${NC}"
        echo "   最新错误日志:"
        tail -n 5 "${PROJECT_ROOT}/logs/api_error.log" 2>/dev/null | sed 's/^/   /'
    else
        echo -e "${GREEN}✓ 暂无错误日志${NC}"
    fi
else
    echo -e "${YELLOW}⚠ 错误日志文件不存在${NC}"
fi

echo ""

# 10. 提供操作建议
echo -e "${BLUE}10. 操作建议:${NC}"
if ! pm2 list | grep -q "tcm-learning-api.*online"; then
    echo -e "${YELLOW}   建议启动服务: ${PROJECT_ROOT}/scripts/start.sh${NC}"
fi

if ! curl -s -m 5 http://localhost:5000/api/health >/dev/null 2>&1; then
    echo -e "${YELLOW}   建议检查API服务: pm2 logs tcm-learning-api${NC}"
fi

if ! systemctl is-active --quiet nginx 2>/dev/null; then
    echo -e "${YELLOW}   建议启动Nginx: systemctl start nginx${NC}"
fi

echo ""
echo -e "${BLUE}=== 状态检查完成 ===${NC}"
