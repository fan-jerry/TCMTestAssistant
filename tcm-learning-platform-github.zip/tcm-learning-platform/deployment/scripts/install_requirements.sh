#!/bin/bash

# 宝塔面板环境依赖安装脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查并安装宝塔面板软件
install_bt_software() {
    log_info "检查宝塔面板软件安装状态..."
    
    # 检查Nginx
    if ! bt list | grep -q "nginx.*运行中"; then
        log_warning "Nginx未安装或未运行，请在宝塔面板中安装并启动Nginx"
    else
        log_success "Nginx运行正常"
    fi
    
    # 检查MySQL
    if ! bt list | grep -q "mysql.*运行中"; then
        log_warning "MySQL未安装或未运行，请在宝塔面板中安装并启动MySQL"
    else
        log_success "MySQL运行正常"
    fi
    
    # 检查Python
    if ! bt list | grep -q "python.*已安装"; then
        log_warning "Python项目管理器未安装，请在宝塔面板软件商店中安装"
    else
        log_success "Python项目管理器已安装"
    fi
    
    # 检查PM2
    if ! bt list | grep -q "pm2.*已安装"; then
        log_warning "PM2管理器未安装，请在宝塔面板软件商店中安装"
    else
        log_success "PM2管理器已安装"
    fi
}

# 安装系统依赖
install_system_deps() {
    log_info "安装系统依赖包..."
    
    yum update -y
    yum install -y epel-release
    yum install -y \
        python3 \
        python3-pip \
        python3-devel \
        gcc \
        gcc-c++ \
        make \
        mysql-devel \
        openssl-devel \
        libffi-devel \
        zlib-devel \
        bzip2-devel \
        readline-devel \
        sqlite-devel \
        wget \
        curl \
        git \
        unzip \
        supervisor \
        htop \
        iotop \
        nethogs \
        tree
    
    log_success "系统依赖安装完成"
}

# 安装Node.js和npm（用于PM2）
install_nodejs() {
    log_info "检查Node.js环境..."
    
    if ! command -v node &> /dev/null; then
        log_info "安装Node.js..."
        curl -sL https://rpm.nodesource.com/setup_16.x | bash -
        yum install -y nodejs
    fi
    
    if ! command -v npm &> /dev/null; then
        log_error "npm未安装"
        exit 1
    fi
    
    # 安装PM2
    if ! command -v pm2 &> /dev/null; then
        log_info "安装PM2..."
        npm install -g pm2
    fi
    
    log_success "Node.js环境检查完成"
}

# 优化Python环境
optimize_python() {
    log_info "优化Python环境..."
    
    # 升级pip
    pip3 install --upgrade pip setuptools wheel
    
    # 安装常用Python包
    pip3 install --upgrade \
        virtualenv \
        virtualenvwrapper \
        supervisor \
        gunicorn \
        uwsgi
    
    log_success "Python环境优化完成"
}

# 配置防火墙
configure_firewall() {
    log_info "配置防火墙..."
    
    # 检查firewalld状态
    if systemctl is-active --quiet firewalld; then
        # 开放必要端口
        firewall-cmd --permanent --add-service=http
        firewall-cmd --permanent --add-service=https
        firewall-cmd --permanent --add-port=5000/tcp  # API端口
        firewall-cmd --permanent --add-port=8888/tcp  # 宝塔面板
        firewall-cmd --reload
        log_success "防火墙配置完成"
    else
        log_warning "firewalld未运行，请手动配置防火墙"
    fi
}

# 优化系统参数
optimize_system() {
    log_info "优化系统参数..."
    
    # 内核参数优化
    cat >> /etc/sysctl.conf << EOF

# TCM Learning Platform System Optimization
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 5000
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_keepalive_time = 1200
net.ipv4.ip_local_port_range = 10000 65000
net.core.rmem_default = 262144
net.core.rmem_max = 16777216
net.core.wmem_default = 262144
net.core.wmem_max = 16777216
vm.swappiness = 10
EOF
    
    sysctl -p
    
    # 文件描述符限制
    cat >> /etc/security/limits.conf << EOF

# TCM Learning Platform File Descriptor Limits
* soft nofile 65535
* hard nofile 65535
root soft nofile 65535
root hard nofile 65535
www soft nofile 65535
www hard nofile 65535
EOF
    
    log_success "系统参数优化完成"
}

# 安装监控工具
install_monitoring() {
    log_info "安装监控工具..."
    
    # 安装htop
    if ! command -v htop &> /dev/null; then
        yum install -y htop
    fi
    
    # 安装iotop
    if ! command -v iotop &> /dev/null; then
        yum install -y iotop
    fi
    
    # 安装nethogs
    if ! command -v nethogs &> /dev/null; then
        yum install -y nethogs
    fi
    
    log_success "监控工具安装完成"
}

# 创建必要的用户和组
create_users() {
    log_info "检查用户和组..."
    
    # 检查www用户（宝塔面板默认用户）
    if ! id -u www &>/dev/null; then
        log_warning "www用户不存在，将创建www用户"
        useradd -r -s /bin/false www
    else
        log_success "www用户已存在"
    fi
}

# 创建必要目录
create_directories() {
    log_info "创建必要目录..."
    
    mkdir -p /www/wwwroot
    mkdir -p /www/backup
    mkdir -p /www/logs
    mkdir -p /var/log/tcm-learning
    
    chown -R www:www /www/wwwroot
    chown -R www:www /www/backup
    chown -R www:www /www/logs
    
    log_success "目录创建完成"
}

# 主函数
main() {
    log_info "开始安装中医学习网站部署环境..."
    
    # 检查是否为root用户
    if [[ $EUID -ne 0 ]]; then
        log_error "请使用root用户运行此脚本"
        exit 1
    fi
    
    # 执行安装步骤
    install_bt_software
    install_system_deps
    install_nodejs
    optimize_python
    configure_firewall
    optimize_system
    install_monitoring
    create_users
    create_directories
    
    log_success "环境安装完成！"
    echo ""
    echo "下一步操作："
    echo "1. 在宝塔面板中安装并启动 Nginx、MySQL、Python项目管理器、PM2管理器"
    echo "2. 运行部署脚本: ./deploy.sh"
    echo "3. 配置域名和SSL证书"
    echo ""
}

# 执行主函数
main "$@"
